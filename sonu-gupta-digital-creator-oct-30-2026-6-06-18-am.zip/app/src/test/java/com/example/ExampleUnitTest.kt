package com.example

import com.example.utils.AudioEngine
import com.example.utils.FileUtil
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.max
import kotlin.math.min

class ExampleUnitTest {
    @Test
    fun testDurationFormatting() {
        assertEquals("00:05", FileUtil.formatDuration(5000L))
        assertEquals("01:30", FileUtil.formatDuration(90000L))
        assertEquals("01:05:20", FileUtil.formatDuration(3920000L))
    }

    @Test
    fun testLongPodcastDurationFormatting() {
        // 45 minutes podcast
        val ms45 = 45 * 60 * 1000L
        assertEquals("45:00", FileUtil.formatDuration(ms45))
        val hindi = FileUtil.formatDurationHindi(ms45)
        assertTrue(hindi.contains("45 मिनट"))
    }

    @Test
    fun testHindiDurationFormatting() {
        val formatted = FileUtil.formatDurationHindi(65000L) // 1 min 5 sec
        assertTrue(formatted.contains("1 मिनट"))
        assertTrue(formatted.contains("5 सेकंड"))
    }

    @Test
    fun testFileSizeFormatting() {
        assertEquals("1.0 KB", FileUtil.formatFileSize(1024L))
        assertEquals("1.0 MB", FileUtil.formatFileSize(1024L * 1024L))
    }

    @Test
    fun testAudioGainClamping() {
        val sample: Short = 20000
        val amplified = (sample * 2.0f).toInt().coerceIn(-32768, 32767).toShort()
        assertEquals(32767.toShort(), amplified)

        val quiet = (sample * 0.5f).toInt().coerceIn(-32768, 32767).toShort()
        assertEquals(10000.toShort(), quiet)
    }

    @Test
    fun testMiddleCutByteOffsets() {
        val bytesPerSec = 44100 * 2 // 88200 bytes/sec
        val cutStartMs = 2000L
        val cutEndMs = 5000L
        val startByte = (cutStartMs * bytesPerSec / 1000L) / 2 * 2
        val endByte = (cutEndMs * bytesPerSec / 1000L) / 2 * 2
        assertEquals(176400L, startByte)
        assertEquals(441000L, endByte)
        assertTrue(endByte > startByte)
    }
}
