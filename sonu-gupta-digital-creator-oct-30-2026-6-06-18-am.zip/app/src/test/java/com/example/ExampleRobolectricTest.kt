package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("सोनू गुप्ता डिजिटल क्रिएटर", appName)
  }

  @Test
  fun `34 minute story duration formatting in English and Hindi`() {
    val thirtyFourMinMs = 34 * 60 * 1000L // 2,040,000 ms
    val formatted = com.example.utils.FileUtil.formatDuration(thirtyFourMinMs)
    val formattedHindi = com.example.utils.FileUtil.formatDurationHindi(thirtyFourMinMs)
    assertEquals("34:00", formatted)
    assertEquals("34 मिनट 0 सेकंड", formattedHindi)

    // Test specific timestamps mentioned in story:
    // 02:30 chaiwala
    val chaiwalaMs = (2 * 60 + 30) * 1000L
    assertEquals("02:30", com.example.utils.FileUtil.formatDuration(chaiwalaMs))
    assertEquals("2 मिनट 30 सेकंड", com.example.utils.FileUtil.formatDurationHindi(chaiwalaMs))

    // 15:00 horror event
    val horrorMs = 15 * 60 * 1000L
    assertEquals("15:00", com.example.utils.FileUtil.formatDuration(horrorMs))
    assertEquals("15 मिनट 0 सेकंड", com.example.utils.FileUtil.formatDurationHindi(horrorMs))
  }

  @Test
  fun `timed photo data intervals and ordering`() {
    val dummyFile = java.io.File("/tmp/dummy.jpg")
    val photo1 = com.example.utils.TimedPhotoData(file = dummyFile, startMs = 150000L, endMs = 225000L, label = "चायवाला")
    val photo2 = com.example.utils.TimedPhotoData(file = dummyFile, startMs = 255000L, endMs = 300000L, label = "चाय बनाई")

    val list = listOf(photo2, photo1).sortedBy { it.startMs }
    assertEquals("चायवाला", list[0].label)
    assertEquals(150000L, list[0].startMs)
    assertEquals(225000L, list[0].endMs)
  }

  @Test
  fun `video clip config with volume muting for Veo 3 clips`() {
    val dummyVideo = java.io.File("/tmp/veo3_clip.mp4")
    val clipMuted = com.example.utils.VideoClipConfig(file = dummyVideo, volume = 0f, label = "म्यूट क्लिप")
    val clipNormal = com.example.utils.VideoClipConfig(file = dummyVideo, volume = 1.0f, label = "सामान्य क्लिप")

    assertEquals(0f, clipMuted.volume)
    assertEquals(1.0f, clipNormal.volume)
  }
}
