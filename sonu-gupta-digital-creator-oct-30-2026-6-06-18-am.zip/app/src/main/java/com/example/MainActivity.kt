package com.example

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.utils.HapticAndSoundUtil
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    viewModel: MainViewModel = viewModel()
) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

    var showWelcomeDialog by remember {
        val prefs = context.getSharedPreferences("sg_creator_prefs", Context.MODE_PRIVATE)
        val shown = prefs.getBoolean("welcome_shown", false)
        mutableStateOf(!shown)
    }

    // Intercept back button if in a sub-screen
    BackHandler(enabled = currentScreen != AppScreen.MainMenu) {
        viewModel.navigateBack()
    }

    val screenTitle = when (currentScreen) {
        AppScreen.MainMenu -> "सोनू गुप्ता डिजिटल क्रिएटर"
        AppScreen.AudioEditorMenu -> "ऑडियो एडिटर"
        AppScreen.AudioRecorderTool -> "ऑडियो रिकॉर्डर"
        AppScreen.AudioRecordWithMusicTool -> "म्यूजिक के साथ ऑडियो रिकॉर्ड करें"
        AppScreen.AudioTrimTool -> "ऑडियो काटें (Trim)"
        AppScreen.AudioTrimStartEndTool -> "ऑडियो की शुरुआत, बीच या अंत काटें"
        AppScreen.AudioMergeTool -> "ऑडियो जोड़ें (Merge)"
        AppScreen.AudioMixMusicTool -> "रिकॉर्ड की गई ऑडियो में म्यूजिक जोड़ें"
        AppScreen.AudioAutoDuckingTool -> "ऑटो-डकिंग (बोलते समय म्यूजिक कम करें)"
        AppScreen.AudioSoundEffectsTool -> "साउंड इफेक्ट जोड़ें"
        AppScreen.AudioGainControlTool -> "ऑडियो का वॉल्यूम नियंत्रित करें"
        AppScreen.AudioVoiceModulationTool -> "आवाज़ बदलें और इको"
        AppScreen.AudioNoiseReductionTool -> "शोर कम करें (Noise Gate)"
        AppScreen.AudioExtractFromVideoTool -> "वीडियो से ऑडियो निकालें"
        AppScreen.AudioWithPhotosVideoTool -> "ऑडियो में फोटो लगाकर वीडियो बनाएँ"
        AppScreen.VideoEditorMenu -> "वीडियो एडिटर"
        AppScreen.VideoTrimTool -> "वीडियो काटें (Trim)"
        AppScreen.VideoRecordWithMusicTool -> "म्यूजिक के साथ वीडियो रिकॉर्ड करें"
        AppScreen.VideoMergeTool -> "वीडियो जोड़ें"
        AppScreen.VideoAddMusicTool -> "वीडियो में म्यूजिक जोड़ें"
        AppScreen.VideoAddSfxTool -> "वीडियो में साउंड इफेक्ट जोड़ें"
        AppScreen.VideoVolumeControlTool -> "वीडियो की मूल आवाज़ नियंत्रित करें"
        AppScreen.PhotoSlideshowTool -> "फोटो स्लाइड शो वीडियो बनाएँ"
        AppScreen.AudioWithPhotosVideoTool -> "ऑडियो में फोटो लगाकर वीडियो बनाएँ"
        AppScreen.VideoOverlayPhotosTool -> "वीडियो में सही समय पर फोटो लगाएँ"
        AppScreen.VideoClipsMergeTool -> "वीडियो क्लिप जोड़कर वीडियो बनाएँ"
        AppScreen.PhotosToVideoTool -> "फोटो स्लाइड शो वीडियो बनाएँ"
        AppScreen.NewProjectWorkspace -> "नया प्रोजेक्ट कार्यक्षेत्र"
        AppScreen.MyProjects -> "मेरे प्रोजेक्ट"
        AppScreen.SavedFiles -> "सेव की गई फाइलें"
        AppScreen.Settings -> "सेटिंग (Settings)"
        AppScreen.HelpAccessibility -> "सहायता और गाइड"
        else -> "सोनू गुप्ता डिजिटल क्रिएटर"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = screenTitle,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                },
                navigationIcon = {
                    if (currentScreen != AppScreen.MainMenu) {
                        IconButton(
                            onClick = {
                                HapticAndSoundUtil.vibrate(context, 25)
                                viewModel.navigateBack()
                            },
                            modifier = Modifier.semantics {
                                contentDescription = "वापस जाएँ (Back)"
                            }
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = null
                            )
                        }
                    }
                },
                actions = {
                    if (currentScreen == AppScreen.MainMenu) {
                        IconButton(
                            onClick = { viewModel.navigateTo(AppScreen.SavedFiles) },
                            modifier = Modifier.semantics { contentDescription = "सेव की गई फाइलें खोलें" }
                        ) {
                            Icon(Icons.Default.Folder, contentDescription = null)
                        }

                        IconButton(
                            onClick = { viewModel.navigateTo(AppScreen.Settings) },
                            modifier = Modifier.semantics { contentDescription = "सेटिंग खोलें" }
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = null)
                        }

                        IconButton(
                            onClick = { viewModel.navigateTo(AppScreen.HelpAccessibility) },
                            modifier = Modifier.semantics { contentDescription = "सहायता और TalkBack गाइड खोलें" }
                        ) {
                            Icon(Icons.Default.HelpOutline, contentDescription = null)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface,
                    navigationIconContentColor = MaterialTheme.colorScheme.onSurface,
                    actionIconContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.MainMenu -> MainMenuScreen(viewModel)
                AppScreen.AudioEditorMenu -> AudioEditorMenuScreen(viewModel)
                AppScreen.AudioRecorderTool -> AudioRecorderToolScreen(viewModel)
                AppScreen.AudioRecordWithMusicTool -> AudioRecordWithMusicToolScreen(viewModel)
                AppScreen.AudioTrimTool -> AudioTrimToolScreen(viewModel)
                AppScreen.AudioTrimStartEndTool -> AudioTrimStartEndToolScreen(viewModel)
                AppScreen.AudioMergeTool -> AudioMergeToolScreen(viewModel)
                AppScreen.AudioMixMusicTool -> AudioMixMusicToolScreen(viewModel)
                AppScreen.AudioAutoDuckingTool -> AudioAutoDuckingToolScreen(viewModel)
                AppScreen.AudioSoundEffectsTool -> AudioSoundEffectsToolScreen(viewModel)
                AppScreen.AudioGainControlTool -> AudioGainControlToolScreen(viewModel)
                AppScreen.AudioVoiceModulationTool -> AudioVoiceModulationToolScreen(viewModel)
                AppScreen.AudioNoiseReductionTool -> AudioNoiseReductionToolScreen(viewModel)
                AppScreen.AudioExtractFromVideoTool -> AudioExtractFromVideoToolScreen(viewModel)
                AppScreen.AudioWithPhotosVideoTool -> AudioWithPhotosVideoToolScreen(viewModel)
                AppScreen.VideoEditorMenu -> VideoEditorMenuScreen(viewModel)
                AppScreen.VideoTrimTool -> VideoTrimToolScreen(viewModel)
                AppScreen.VideoRecordWithMusicTool -> VideoRecordWithMusicToolScreen(viewModel)
                AppScreen.VideoMergeTool -> VideoClipsMergeToolScreen(viewModel)
                AppScreen.VideoAddMusicTool -> VideoAddMusicToolScreen(viewModel)
                AppScreen.VideoAddSfxTool -> VideoAddSfxToolScreen(viewModel)
                AppScreen.VideoVolumeControlTool -> VideoVolumeControlToolScreen(viewModel)
                AppScreen.PhotoSlideshowTool -> PhotosToVideoToolScreen(viewModel)
                AppScreen.VideoOverlayPhotosTool -> VideoOverlayPhotosToolScreen(viewModel)
                AppScreen.VideoClipsMergeTool -> VideoClipsMergeToolScreen(viewModel)
                AppScreen.PhotosToVideoTool -> PhotosToVideoToolScreen(viewModel)
                AppScreen.NewProjectWorkspace -> NewProjectScreen(viewModel)
                AppScreen.MyProjects -> MyProjectsScreen(viewModel)
                AppScreen.SavedFiles -> SavedFilesScreen(viewModel)
                AppScreen.Settings -> SettingsScreen(viewModel)
                AppScreen.HelpAccessibility -> HelpAccessibilityScreen()
                else -> MainMenuScreen(viewModel)
            }
        }
    }

    if (showWelcomeDialog) {
        AlertDialog(
            onDismissRequest = {
                showWelcomeDialog = false
                context.getSharedPreferences("sg_creator_prefs", Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean("welcome_shown", true)
                    .apply()
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.Campaign,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "सोनू गुप्ता डिजिटल क्रिएटर में आपका स्वागत है!",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "यह ऐप विशेष रूप से कहानीकारों, पॉडकास्टरों और नेत्रहीन डिजिटल रचनाकारों के लिए तैयार किया गया है।\n\n• TalkBack से 100% सुलभ\n• ऑडियो रिकॉर्डिंग, सटीक कटिंग एवं ऑटो-डकिंग\n• फोटो एवं ऑडियो से वीडियो निर्माण\n• सभी कार्य स्थानीय फोन पर, पूर्ण सुरक्षा के साथ।",
                    style = MaterialTheme.typography.bodyMedium,
                    lineHeight = 22.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showWelcomeDialog = false
                        context.getSharedPreferences("sg_creator_prefs", Context.MODE_PRIVATE)
                            .edit()
                            .putBoolean("welcome_shown", true)
                            .apply()
                        HapticAndSoundUtil.announceForAccessibility(context, "सोनू गुप्ता डिजिटल क्रिएटर मुख्य स्क्रीन तैयार है")
                    },
                    modifier = Modifier.semantics { contentDescription = "शुरू करें बटन दबाएँ" }
                ) {
                    Text("शुरू करें")
                }
            }
        )
    }
}
