package com.example.utils

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

object AudioEngine {

    val sampleRate = 44100
    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT
    private val bytesPerSample = 2 // 16-bit mono = 2 bytes per sample

    // Recording State
    private var audioRecord: AudioRecord? = null
    private var isRecording = false
    private var isPaused = false
    private var recordingThread: Thread? = null

    val currentAmplitude = MutableStateFlow(0f)
    val recordingDurationMs = MutableStateFlow(0L)

    @SuppressLint("MissingPermission")
    fun startRecording(outputFile: File, onDurationUpdate: (Long) -> Unit = {}) {
        val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        val bufferSize = max(minBufferSize, 4096)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            channelConfig,
            audioFormat,
            bufferSize
        )

        isRecording = true
        isPaused = false
        recordingDurationMs.value = 0L

        val pcmTemp = File(outputFile.parentFile, "${outputFile.name}.pcm")

        audioRecord?.startRecording()

        recordingThread = Thread {
            val buffer = ShortArray(bufferSize / 2)
            var totalSamples = 0L
            val pcmOut = FileOutputStream(pcmTemp)

            val startTime = System.currentTimeMillis()
            var pausedDuration = 0L
            var pauseStartTime = 0L

            try {
                while (isRecording) {
                    if (isPaused) {
                        if (pauseStartTime == 0L) pauseStartTime = System.currentTimeMillis()
                        Thread.sleep(50)
                        continue
                    } else if (pauseStartTime > 0L) {
                        pausedDuration += (System.currentTimeMillis() - pauseStartTime)
                        pauseStartTime = 0L
                    }

                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        // Calculate peak amplitude
                        var maxAmp = 0
                        val byteBuf = ByteBuffer.allocate(read * 2).order(ByteOrder.LITTLE_ENDIAN)
                        for (i in 0 until read) {
                            val sample = buffer[i]
                            if (abs(sample.toInt()) > maxAmp) {
                                maxAmp = abs(sample.toInt())
                            }
                            byteBuf.putShort(sample)
                        }
                        currentAmplitude.value = (maxAmp / 32767f).coerceIn(0f, 1f)
                        pcmOut.write(byteBuf.array(), 0, read * 2)
                        totalSamples += read

                        val elapsed = System.currentTimeMillis() - startTime - pausedDuration
                        recordingDurationMs.value = elapsed
                        onDurationUpdate(elapsed)
                    }
                }
            } catch (_: Exception) {
            } finally {
                pcmOut.flush()
                pcmOut.close()
                currentAmplitude.value = 0f
            }

            // Convert PCM to WAV
            pcmToWav(pcmTemp, outputFile, sampleRate, 1, 16)
            pcmTemp.delete()
        }
        recordingThread?.start()
    }

    fun pauseRecording() {
        isPaused = true
    }

    fun resumeRecording() {
        isPaused = false
    }

    fun isRecordingActive(): Boolean = isRecording
    fun isRecordingPaused(): Boolean = isPaused

    fun stopRecording() {
        isRecording = false
        isPaused = false
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {
        }
        audioRecord = null
        recordingThread?.join(2000)
        recordingThread = null
    }

    // Write standard 44-byte WAV header
    fun writeWavHeader(
        out: FileOutputStream,
        totalAudioLen: Long,
        totalDataLen: Long,
        longSampleRate: Long,
        channels: Int,
        byteRate: Long
    ) {
        val header = ByteArray(44)
        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalDataLen and 0xff).toByte()
        header[5] = (totalDataLen shr 8 and 0xff).toByte()
        header[6] = (totalDataLen shr 16 and 0xff).toByte()
        header[7] = (totalDataLen shr 24 and 0xff).toByte()
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16 // 16 for PCM format
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1 // Linear PCM
        header[21] = 0
        header[22] = channels.toByte()
        header[23] = 0
        header[24] = (longSampleRate and 0xff).toByte()
        header[25] = (longSampleRate shr 8 and 0xff).toByte()
        header[26] = (longSampleRate shr 16 and 0xff).toByte()
        header[27] = (longSampleRate shr 24 and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = (byteRate shr 8 and 0xff).toByte()
        header[30] = (byteRate shr 16 and 0xff).toByte()
        header[31] = (byteRate shr 24 and 0xff).toByte()
        header[32] = (channels * 16 / 8).toByte() // block align
        header[33] = 0
        header[34] = 16 // bits per sample
        header[35] = 0
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (totalAudioLen and 0xff).toByte()
        header[41] = (totalAudioLen shr 8 and 0xff).toByte()
        header[42] = (totalAudioLen shr 16 and 0xff).toByte()
        header[43] = (totalAudioLen shr 24 and 0xff).toByte()
        out.write(header, 0, 44)
    }

    fun pcmToWav(pcmFile: File, wavFile: File, sampleRate: Int, channels: Int, bitsPerSample: Int) {
        val totalAudioLen = pcmFile.length()
        val totalDataLen = totalAudioLen + 36
        val byteRate = (sampleRate * channels * bitsPerSample / 8).toLong()

        val inStream = FileInputStream(pcmFile)
        val outStream = FileOutputStream(wavFile)
        writeWavHeader(outStream, totalAudioLen, totalDataLen, sampleRate.toLong(), channels, byteRate)

        val buffer = ByteArray(4096)
        var bytesRead: Int
        while (inStream.read(buffer).also { bytesRead = it } != -1) {
            outStream.write(buffer, 0, bytesRead)
        }
        inStream.close()
        outStream.flush()
        outStream.close()
    }

    // Audio Trimming: streams PCM without blowing up memory on long recordings
    suspend fun trimWav(
        inputFile: File,
        outputFile: File,
        startMs: Long,
        endMs: Long,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val bytesPerSecond = sampleRate * bytesPerSample // 44100 * 2 = 88200 bytes/sec
            val startByte = (startMs * bytesPerSecond / 1000L) / 2 * 2
            val endByte = (endMs * bytesPerSecond / 1000L) / 2 * 2
            val targetBytes = max(0L, endByte - startByte)

            FileInputStream(inputFile).use { inStream ->
                // Skip WAV header (44 bytes)
                inStream.skip(44)
                inStream.skip(startByte)

                FileOutputStream(outputFile).use { outStream ->
                    writeWavHeader(
                        outStream,
                        targetBytes,
                        targetBytes + 36,
                        sampleRate.toLong(),
                        1,
                        bytesPerSecond.toLong()
                    )

                    val buffer = ByteArray(8192)
                    var written = 0L
                    while (written < targetBytes) {
                        val toRead = min(buffer.size.toLong(), targetBytes - written).toInt()
                        val read = inStream.read(buffer, 0, toRead)
                        if (read <= 0) break
                        outStream.write(buffer, 0, read)
                        written += read
                        val progress = ((written.toDouble() / targetBytes) * 100).toInt().coerceIn(0, 100)
                        onProgress(progress)
                    }
                    outStream.flush()
                }
            }
            onProgress(100)
            true
        } catch (e: Exception) {
            false
        }
    }

    // Join / Concatenate multiple WAV files
    suspend fun mergeWavs(
        inputFiles: List<File>,
        outputFile: File,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            var totalAudioLen = 0L
            for (file in inputFiles) {
                if (file.exists() && file.length() > 44) {
                    totalAudioLen += (file.length() - 44)
                }
            }

            val byteRate = (sampleRate * 1 * 16 / 8).toLong()
            FileOutputStream(outputFile).use { outStream ->
                writeWavHeader(outStream, totalAudioLen, totalAudioLen + 36, sampleRate.toLong(), 1, byteRate)

                var processedBytes = 0L
                val buffer = ByteArray(8192)

                for (file in inputFiles) {
                    if (!file.exists()) continue
                    FileInputStream(file).use { inStream ->
                        inStream.skip(44) // Skip header
                        var read: Int
                        while (inStream.read(buffer).also { read = it } != -1) {
                            outStream.write(buffer, 0, read)
                            processedBytes += read
                            if (totalAudioLen > 0) {
                                val progress = ((processedBytes.toDouble() / totalAudioLen) * 100).toInt().coerceIn(0, 99)
                                onProgress(progress)
                            }
                        }
                    }
                }
                outStream.flush()
            }
            onProgress(100)
            true
        } catch (e: Exception) {
            false
        }
    }

    // Mix Voice + Music with volume, start offset, duration, fade in/out
    suspend fun mixVoiceWithMusic(
        voiceFile: File,
        musicFile: File,
        outputFile: File,
        voiceVolume: Float,
        musicVolume: Float,
        musicStartMs: Long,
        musicDurationMs: Long,
        fadeInMs: Long = 1500L,
        fadeOutMs: Long = 1500L,
        loopMusic: Boolean = false,
        repeatCount: Int = 1,
        repeatUntilEnd: Boolean = true,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val voiceLength = if (voiceFile.exists()) voiceFile.length() - 44 else 0L
            if (voiceLength <= 0) return@withContext false

            val bytesPerSecond = sampleRate * bytesPerSample
            val musicStartByte = (musicStartMs * bytesPerSecond / 1000L) / 2 * 2

            // Read Music PCM into memory for flawless looping and no stream-closed issues
            val musicPcm = if (musicFile.exists()) {
                val raw = musicFile.readBytes()
                if (raw.size > 44) raw.copyOfRange(44, raw.size) else null
            } else null

            val maxMusicBytes: Long = if (musicPcm != null && musicPcm.isNotEmpty()) {
                if (loopMusic) {
                    if (repeatUntilEnd) {
                        if (musicDurationMs > 0) (musicDurationMs * bytesPerSecond / 1000L) / 2 * 2 else voiceLength
                    } else {
                        minOf(
                            if (musicDurationMs > 0) (musicDurationMs * bytesPerSecond / 1000L) / 2 * 2 else voiceLength,
                            (musicPcm.size.toLong() * repeatCount) / 2 * 2
                        )
                    }
                } else {
                    minOf(
                        if (musicDurationMs > 0) (musicDurationMs * bytesPerSecond / 1000L) / 2 * 2 else voiceLength,
                        musicPcm.size.toLong() / 2 * 2
                    )
                }
            } else 0L

            val totalOutputBytes = voiceLength
            val byteRate = bytesPerSecond.toLong()

            FileOutputStream(outputFile).use { outStream ->
                writeWavHeader(outStream, totalOutputBytes, totalOutputBytes + 36, sampleRate.toLong(), 1, byteRate)

                val voiceIn = FileInputStream(voiceFile).apply { skip(44) }

                val voiceBuf = ByteArray(4096)
                val outBuf = ByteArray(4096)
                var currentBytePos = 0L

                val fadeInBytes = (fadeInMs * bytesPerSecond / 1000L)
                val fadeOutBytes = (fadeOutMs * bytesPerSecond / 1000L)

                var vRead: Int
                while (voiceIn.read(voiceBuf).also { vRead = it } != -1) {
                    val samplesCount = vRead / 2

                    for (i in 0 until samplesCount) {
                        val vLow = voiceBuf[i * 2].toInt() and 0xFF
                        val vHigh = voiceBuf[i * 2 + 1].toInt()
                        val voiceSample = ((vHigh shl 8) or vLow).toShort()

                        val samplePos = currentBytePos + (i * 2)
                        var musicSample: Short = 0

                        if (samplePos >= musicStartByte && samplePos < (musicStartByte + maxMusicBytes) && musicPcm != null && musicPcm.size >= 2) {
                            val relMusicPos = samplePos - musicStartByte
                            // Calculate fade multiplier
                            var fadeMultiplier = 1.0f
                            if (fadeInBytes > 0 && relMusicPos < fadeInBytes) {
                                fadeMultiplier = (relMusicPos.toFloat() / fadeInBytes).coerceIn(0f, 1f)
                            } else if (fadeOutBytes > 0 && relMusicPos > (maxMusicBytes - fadeOutBytes)) {
                                val remaining = maxMusicBytes - relMusicPos
                                fadeMultiplier = (remaining.toFloat() / fadeOutBytes).coerceIn(0f, 1f)
                            }

                            val pcmOffset = ((relMusicPos % musicPcm.size) / 2 * 2).toInt()
                            if (pcmOffset + 1 < musicPcm.size) {
                                val mB1 = musicPcm[pcmOffset].toInt() and 0xFF
                                val mB2 = musicPcm[pcmOffset + 1].toInt()
                                val mRaw = ((mB2 shl 8) or mB1).toShort()
                                musicSample = (mRaw * fadeMultiplier).toInt().toShort()
                            }
                        }

                        // Mix samples
                        val mixed = (voiceSample * voiceVolume + musicSample * musicVolume).toInt().coerceIn(-32768, 32767)
                        outBuf[i * 2] = (mixed and 0xFF).toByte()
                        outBuf[i * 2 + 1] = ((mixed shr 8) and 0xFF).toByte()
                    }

                    outStream.write(outBuf, 0, vRead)
                    currentBytePos += vRead
                    val progress = ((currentBytePos.toDouble() / totalOutputBytes) * 100).toInt().coerceIn(0, 99)
                    onProgress(progress)
                }

                voiceIn.close()
                outStream.flush()
            }
            onProgress(100)
            true
        } catch (e: Exception) {
            false
        }
    }

    // Auto-Ducking: Smoothly lowers background music volume when user voice is active
    suspend fun applyAutoDucking(
        voiceFile: File,
        musicFile: File,
        outputFile: File,
        voiceVolume: Float = 1.0f,
        musicVolume: Float = 0.8f,
        duckLevelPercent: Float = 25f, // music drops to 25% during speech
        sensitivityPercent: Float = 30f, // threshold of voice detection
        attackSpeedMs: Long = 80L, // how fast music dips
        releaseSpeedMs: Long = 600L, // how fast music restores
        loopMusic: Boolean = true,
        repeatCount: Int = 1,
        repeatUntilEnd: Boolean = true,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val voiceLength = if (voiceFile.exists()) voiceFile.length() - 44 else 0L
            if (voiceLength <= 0) return@withContext false

            val bytesPerSecond = sampleRate * bytesPerSample
            val duckMultiplier = (duckLevelPercent / 100f).coerceIn(0.05f, 0.9f)
            val thresholdRms = ((100f - sensitivityPercent) / 100f * 12000f).coerceIn(500f, 15000f)

            val attackRate = 1.0f / (attackSpeedMs * sampleRate / 1000f)
            val releaseRate = 1.0f / (releaseSpeedMs * sampleRate / 1000f)

            // Read Music PCM into memory for safe, seamless looping
            val musicPcm = if (musicFile.exists()) {
                val raw = musicFile.readBytes()
                if (raw.size > 44) raw.copyOfRange(44, raw.size) else null
            } else null

            val maxMusicBytes: Long = if (musicPcm != null && musicPcm.isNotEmpty()) {
                if (loopMusic) {
                    if (repeatUntilEnd) voiceLength else minOf(voiceLength, (musicPcm.size.toLong() * repeatCount) / 2 * 2)
                } else {
                    minOf(voiceLength, musicPcm.size.toLong() / 2 * 2)
                }
            } else 0L

            FileOutputStream(outputFile).use { outStream ->
                writeWavHeader(outStream, voiceLength, voiceLength + 36, sampleRate.toLong(), 1, bytesPerSecond.toLong())

                val voiceIn = FileInputStream(voiceFile).apply { skip(44) }

                val buffer = ByteArray(2048)
                val outBuf = ByteArray(2048)
                var currentMusicGain = 1.0f
                var processed = 0L

                var read: Int
                while (voiceIn.read(buffer).also { read = it } != -1) {
                    val samples = read / 2

                    // Calculate RMS of this block to determine voice presence
                    var sumSquares = 0.0
                    for (i in 0 until samples) {
                        val low = buffer[i * 2].toInt() and 0xFF
                        val high = buffer[i * 2 + 1].toInt()
                        val s = ((high shl 8) or low).toShort()
                        sumSquares += (s * s)
                    }
                    val blockRms = sqrt(sumSquares / samples)
                    val isSpeaking = blockRms > thresholdRms
                    val targetGain = if (isSpeaking) duckMultiplier else 1.0f

                    for (i in 0 until samples) {
                        val low = buffer[i * 2].toInt() and 0xFF
                        val high = buffer[i * 2 + 1].toInt()
                        val voiceSample = ((high shl 8) or low).toShort()

                        // Smoothly move current gain toward target gain
                        if (currentMusicGain > targetGain) {
                            currentMusicGain = max(targetGain, currentMusicGain - attackRate)
                        } else if (currentMusicGain < targetGain) {
                            currentMusicGain = min(targetGain, currentMusicGain + releaseRate)
                        }

                        val samplePos = processed + (i * 2)
                        var musicSample: Short = 0
                        if (musicPcm != null && musicPcm.size >= 2 && samplePos < maxMusicBytes) {
                            val pcmOffset = ((samplePos % musicPcm.size) / 2 * 2).toInt()
                            if (pcmOffset + 1 < musicPcm.size) {
                                val mb1 = musicPcm[pcmOffset].toInt() and 0xFF
                                val mb2 = musicPcm[pcmOffset + 1].toInt()
                                val rawM = ((mb2 shl 8) or mb1).toShort()
                                musicSample = (rawM * currentMusicGain).toInt().toShort()
                            }
                        }

                        val mixed = (voiceSample * voiceVolume + musicSample * musicVolume).toInt().coerceIn(-32768, 32767)
                        outBuf[i * 2] = (mixed and 0xFF).toByte()
                        outBuf[i * 2 + 1] = ((mixed shr 8) and 0xFF).toByte()
                    }

                    outStream.write(outBuf, 0, read)
                    processed += read
                    val progress = ((processed.toDouble() / voiceLength) * 100).toInt().coerceIn(0, 99)
                    onProgress(progress)
                }

                voiceIn.close()
                outStream.flush()
            }
            onProgress(100)
            true
        } catch (e: Exception) {
            false
        }
    }

    // Apply Sound Effects at exact timestamps with repeat and interval support
    suspend fun applySoundEffects(
        mainAudio: File,
        sfxFile: File,
        outputFile: File,
        offsetMs: Long,
        durationMs: Long,
        sfxVolume: Float,
        repeatSfx: Boolean = false,
        repeatCount: Int = 1,
        repeatUntilEnd: Boolean = false,
        repeatIntervalMs: Long = 0L,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val mainLen = mainAudio.length() - 44
            if (mainLen <= 0) return@withContext false

            val bytesPerSecond = sampleRate * bytesPerSample
            val startByte = (offsetMs * bytesPerSecond / 1000L) / 2 * 2
            val intervalBytes = (repeatIntervalMs * bytesPerSecond / 1000L) / 2 * 2

            val sfxPcm = if (sfxFile.exists()) {
                val raw = sfxFile.readBytes()
                if (raw.size > 44) raw.copyOfRange(44, raw.size) else null
            } else null

            val sfxPcmLen = sfxPcm?.size?.toLong() ?: 0L
            val singleSfxDurationBytes = if (durationMs > 0) minOf(sfxPcmLen, (durationMs * bytesPerSecond / 1000L) / 2 * 2) else sfxPcmLen
            val repeatPeriodBytes = singleSfxDurationBytes + intervalBytes

            FileOutputStream(outputFile).use { outStream ->
                writeWavHeader(outStream, mainLen, mainLen + 36, sampleRate.toLong(), 1, bytesPerSecond.toLong())

                val mainIn = FileInputStream(mainAudio).apply { skip(44) }

                val buffer = ByteArray(4096)
                val outBuf = ByteArray(4096)
                var currentPos = 0L

                var read: Int
                while (mainIn.read(buffer).also { read = it } != -1) {
                    val samples = read / 2

                    for (i in 0 until samples) {
                        val low = buffer[i * 2].toInt() and 0xFF
                        val high = buffer[i * 2 + 1].toInt()
                        val mainSample = ((high shl 8) or low).toShort()

                        val samplePos = currentPos + (i * 2)
                        var sfxSample: Short = 0

                        if (sfxPcm != null && sfxPcm.size >= 2 && samplePos >= startByte) {
                            val relPos = samplePos - startByte
                            val isWithinRepeats = if (repeatSfx) {
                                if (repeatUntilEnd) {
                                    true
                                } else {
                                    relPos < (repeatCount * repeatPeriodBytes)
                                }
                            } else {
                                relPos < singleSfxDurationBytes
                            }

                            if (isWithinRepeats && repeatPeriodBytes > 0) {
                                val posInPeriod = relPos % repeatPeriodBytes
                                if (posInPeriod < singleSfxDurationBytes) {
                                    val sfxOffset = (posInPeriod % sfxPcm.size).toInt() / 2 * 2
                                    if (sfxOffset + 1 < sfxPcm.size) {
                                        val b1 = sfxPcm[sfxOffset].toInt() and 0xFF
                                        val b2 = sfxPcm[sfxOffset + 1].toInt()
                                        val raw = ((b2 shl 8) or b1).toShort()
                                        sfxSample = (raw * sfxVolume).toInt().toShort()
                                    }
                                }
                            }
                        }

                        val mixed = (mainSample + sfxSample).coerceIn(-32768, 32767)
                        outBuf[i * 2] = (mixed and 0xFF).toByte()
                        outBuf[i * 2 + 1] = ((mixed shr 8) and 0xFF).toByte()
                    }

                    outStream.write(outBuf, 0, read)
                    currentPos += read
                    val progress = ((currentPos.toDouble() / mainLen) * 100).toInt().coerceIn(0, 99)
                    onProgress(progress)
                }

                mainIn.close()
                outStream.flush()
            }
            onProgress(100)
            true
        } catch (e: Exception) {
            false
        }
    }

    // Voice Pitch & Effects: Child / Deep / Robot / Echo / Reverb / Noise Reduction
    enum class VoiceEffect {
        NORMAL,
        CHILD,
        DEEP,
        ROBOT,
        ECHO,
        NOISE_GATE
    }

    suspend fun applyVoiceEffect(
        inputFile: File,
        outputFile: File,
        effect: VoiceEffect,
        intensity: Float = 1.0f,
        echoDelayMs: Int = 220,
        echoDecay: Float = 0.45f,
        noiseThreshold: Float = 500f,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val inputLen = inputFile.length() - 44
            if (inputLen <= 0) return@withContext false

            val bytesPerSecond = sampleRate * bytesPerSample

            when (effect) {
                VoiceEffect.NORMAL -> {
                    // Direct stream copy
                    inputFile.copyTo(outputFile, overwrite = true)
                    onProgress(100)
                    return@withContext true
                }

                VoiceEffect.ECHO -> {
                    // Delay buffer
                    val delaySamples = (echoDelayMs * sampleRate / 1000)
                    val delayBuffer = ShortArray(delaySamples)
                    var delayIndex = 0

                    FileOutputStream(outputFile).use { outStream ->
                        writeWavHeader(outStream, inputLen, inputLen + 36, sampleRate.toLong(), 1, bytesPerSecond.toLong())
                        val inStream = FileInputStream(inputFile).apply { skip(44) }

                        val buffer = ByteArray(4096)
                        val outBuf = ByteArray(4096)
                        var processed = 0L

                        var read: Int
                        while (inStream.read(buffer).also { read = it } != -1) {
                            val samples = read / 2
                            for (i in 0 until samples) {
                                val low = buffer[i * 2].toInt() and 0xFF
                                val high = buffer[i * 2 + 1].toInt()
                                val sample = ((high shl 8) or low).toShort()

                                val echoSample = delayBuffer[delayIndex]
                                val outSample = (sample + echoSample * echoDecay * intensity).toInt().coerceIn(-32768, 32767).toShort()

                                delayBuffer[delayIndex] = outSample
                                delayIndex = (delayIndex + 1) % delaySamples

                                outBuf[i * 2] = (outSample.toInt() and 0xFF).toByte()
                                outBuf[i * 2 + 1] = ((outSample.toInt() shr 8) and 0xFF).toByte()
                            }
                            outStream.write(outBuf, 0, read)
                            processed += read
                            val p = ((processed.toDouble() / inputLen) * 100).toInt().coerceIn(0, 99)
                            onProgress(p)
                        }
                        inStream.close()
                        outStream.flush()
                    }
                    onProgress(100)
                    return@withContext true
                }

                VoiceEffect.ROBOT -> {
                    var sampleIdx = 0L
                    val modFreq = 50.0 // 50 Hz robotic modulation

                    FileOutputStream(outputFile).use { outStream ->
                        writeWavHeader(outStream, inputLen, inputLen + 36, sampleRate.toLong(), 1, bytesPerSecond.toLong())
                        val inStream = FileInputStream(inputFile).apply { skip(44) }

                        val buffer = ByteArray(4096)
                        val outBuf = ByteArray(4096)
                        var processed = 0L

                        var read: Int
                        while (inStream.read(buffer).also { read = it } != -1) {
                            val samples = read / 2
                            for (i in 0 until samples) {
                                val low = buffer[i * 2].toInt() and 0xFF
                                val high = buffer[i * 2 + 1].toInt()
                                val sample = ((high shl 8) or low).toShort()

                                val carrier = sin(2.0 * Math.PI * modFreq * sampleIdx / sampleRate)
                                val robotSample = (sample * (0.3 + 0.7 * abs(carrier)) * intensity + sample * (1f - intensity)).toInt().coerceIn(-32768, 32767).toShort()

                                outBuf[i * 2] = (robotSample.toInt() and 0xFF).toByte()
                                outBuf[i * 2 + 1] = ((robotSample.toInt() shr 8) and 0xFF).toByte()
                                sampleIdx++
                            }
                            outStream.write(outBuf, 0, read)
                            processed += read
                            val p = ((processed.toDouble() / inputLen) * 100).toInt().coerceIn(0, 99)
                            onProgress(p)
                        }
                        inStream.close()
                        outStream.flush()
                    }
                    onProgress(100)
                    return@withContext true
                }

                VoiceEffect.NOISE_GATE -> {
                    // Smooth noise gate: below threshold attenuation
                    FileOutputStream(outputFile).use { outStream ->
                        writeWavHeader(outStream, inputLen, inputLen + 36, sampleRate.toLong(), 1, bytesPerSecond.toLong())
                        val inStream = FileInputStream(inputFile).apply { skip(44) }

                        val buffer = ByteArray(4096)
                        val outBuf = ByteArray(4096)
                        var processed = 0L

                        var read: Int
                        while (inStream.read(buffer).also { read = it } != -1) {
                            val samples = read / 2
                            for (i in 0 until samples) {
                                val low = buffer[i * 2].toInt() and 0xFF
                                val high = buffer[i * 2 + 1].toInt()
                                val sample = ((high shl 8) or low).toShort()

                                val amp = abs(sample.toInt())
                                val cleanSample = if (amp < noiseThreshold * intensity) {
                                    // Smoothly suppress
                                    val factor = (amp.toFloat() / (noiseThreshold * intensity)).coerceIn(0f, 1f)
                                    (sample * factor * factor).toInt().toShort()
                                } else {
                                    sample
                                }

                                outBuf[i * 2] = (cleanSample.toInt() and 0xFF).toByte()
                                outBuf[i * 2 + 1] = ((cleanSample.toInt() shr 8) and 0xFF).toByte()
                            }
                            outStream.write(outBuf, 0, read)
                            processed += read
                            val p = ((processed.toDouble() / inputLen) * 100).toInt().coerceIn(0, 99)
                            onProgress(p)
                        }
                        inStream.close()
                        outStream.flush()
                    }
                    onProgress(100)
                    return@withContext true
                }

                VoiceEffect.CHILD, VoiceEffect.DEEP -> {
                    // Resampling pitch shifting
                    val speedFactor = if (effect == VoiceEffect.CHILD) 1.35f else 0.78f
                    val targetLen = (inputLen / speedFactor).toLong() / 2 * 2

                    FileOutputStream(outputFile).use { outStream ->
                        writeWavHeader(outStream, targetLen, targetLen + 36, sampleRate.toLong(), 1, bytesPerSecond.toLong())

                        // Read source into memory in chunks or handle with interpolation
                        val inStream = FileInputStream(inputFile).apply { skip(44) }
                        val rawBytes = inStream.readBytes()
                        inStream.close()

                        val inSamples = ShortArray(rawBytes.size / 2)
                        for (i in inSamples.indices) {
                            val low = rawBytes[i * 2].toInt() and 0xFF
                            val high = rawBytes[i * 2 + 1].toInt()
                            inSamples[i] = ((high shl 8) or low).toShort()
                        }

                        val outSamplesCount = (inSamples.size / speedFactor).toInt()
                        val outBuf = ByteArray(4096)
                        var bufIdx = 0

                        for (i in 0 until outSamplesCount) {
                            val srcPos = i * speedFactor
                            val idx0 = srcPos.toInt().coerceIn(0, inSamples.size - 1)
                            val idx1 = min(idx0 + 1, inSamples.size - 1)
                            val fraction = srcPos - idx0

                            val s0 = inSamples[idx0]
                            val s1 = inSamples[idx1]
                            val interp = (s0 * (1.0 - fraction) + s1 * fraction).toInt().toShort()

                            outBuf[bufIdx++] = (interp.toInt() and 0xFF).toByte()
                            outBuf[bufIdx++] = ((interp.toInt() shr 8) and 0xFF).toByte()

                            if (bufIdx >= outBuf.size) {
                                outStream.write(outBuf, 0, bufIdx)
                                bufIdx = 0
                            }

                            if (i % 20000 == 0) {
                                val p = ((i.toDouble() / outSamplesCount) * 100).toInt().coerceIn(0, 99)
                                onProgress(p)
                            }
                        }
                        if (bufIdx > 0) {
                            outStream.write(outBuf, 0, bufIdx)
                        }
                        outStream.flush()
                    }
                    onProgress(100)
                    return@withContext true
                }
            }
        } catch (e: Exception) {
            false
        }
    }

    // Extract audio from video file to M4A / AAC using MediaExtractor & MediaMuxer
    suspend fun extractAudioFromVideo(
        videoFile: File,
        outputAudioFile: File,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(videoFile.absolutePath)
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = format
                    break
                }
            }

            if (audioTrackIndex == -1 || audioFormat == null) {
                // No audio track found
                return@withContext false
            }

            extractor.selectTrack(audioTrackIndex)
            val durationUs = if (audioFormat.containsKey(MediaFormat.KEY_DURATION)) {
                audioFormat.getLong(MediaFormat.KEY_DURATION)
            } else 1L

            muxer = MediaMuxer(outputAudioFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxerTrack = muxer.addTrack(audioFormat)
            muxer.start()

            val maxBufferSize = if (audioFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                audioFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
            } else 64 * 1024

            val buffer = ByteBuffer.allocate(maxBufferSize)
            val bufferInfo = MediaCodec.BufferInfo()

            while (true) {
                bufferInfo.offset = 0
                bufferInfo.size = extractor.readSampleData(buffer, 0)
                if (bufferInfo.size < 0) {
                    break
                }
                bufferInfo.presentationTimeUs = extractor.sampleTime
                bufferInfo.flags = extractor.sampleFlags

                muxer.writeSampleData(muxerTrack, buffer, bufferInfo)

                if (durationUs > 0) {
                    val p = ((bufferInfo.presentationTimeUs.toDouble() / durationUs) * 100).toInt().coerceIn(0, 99)
                    onProgress(p)
                }

                extractor.advance()
            }

            onProgress(100)
            true
        } catch (e: Exception) {
            false
        } finally {
            try {
                extractor.release()
                muxer?.stop()
                muxer?.release()
            } catch (_: Exception) {
            }
        }
    }

    // Adjust overall volume/gain of a WAV file
    suspend fun adjustAudioVolume(
        inputFile: File,
        outputFile: File,
        volumeFactor: Float,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val inputLen = inputFile.length() - 44
            if (inputLen <= 0) return@withContext false

            val bytesPerSecond = sampleRate * bytesPerSample
            FileOutputStream(outputFile).use { outStream ->
                writeWavHeader(outStream, inputLen, inputLen + 36, sampleRate.toLong(), 1, bytesPerSecond.toLong())
                FileInputStream(inputFile).use { inStream ->
                    inStream.skip(44)
                    val buffer = ByteArray(4096)
                    val outBuf = ByteArray(4096)
                    var processed = 0L
                    var read: Int

                    while (inStream.read(buffer).also { read = it } != -1) {
                        val samples = read / 2
                        for (i in 0 until samples) {
                            val low = buffer[i * 2].toInt() and 0xFF
                            val high = buffer[i * 2 + 1].toInt()
                            val sample = ((high shl 8) or low).toShort()
                            val adjusted = (sample * volumeFactor).toInt().coerceIn(-32768, 32767).toShort()
                            outBuf[i * 2] = (adjusted.toInt() and 0xFF).toByte()
                            outBuf[i * 2 + 1] = ((adjusted.toInt() shr 8) and 0xFF).toByte()
                        }
                        outStream.write(outBuf, 0, read)
                        processed += read
                        val p = ((processed.toDouble() / inputLen) * 100).toInt().coerceIn(0, 99)
                        onProgress(p)
                    }
                    outStream.flush()
                }
            }
            onProgress(100)
            true
        } catch (e: Exception) {
            false
        }
    }

    // Cut a middle section from WAV (removes cutStartMs to cutEndMs, retains 0..cutStartMs and cutEndMs..end)
    suspend fun cutMiddleWav(
        inputFile: File,
        outputFile: File,
        cutStartMs: Long,
        cutEndMs: Long,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val totalBytes = inputFile.length() - 44
            if (totalBytes <= 0) return@withContext false

            val bytesPerSecond = sampleRate * bytesPerSample
            val cutStartByte = (cutStartMs * bytesPerSecond / 1000L) / 2 * 2
            val cutEndByte = min(totalBytes, (cutEndMs * bytesPerSecond / 1000L) / 2 * 2)
            val cutDurationBytes = max(0L, cutEndByte - cutStartByte)
            val outputBytes = max(0L, totalBytes - cutDurationBytes)

            FileOutputStream(outputFile).use { outStream ->
                writeWavHeader(outStream, outputBytes, outputBytes + 36, sampleRate.toLong(), 1, bytesPerSecond.toLong())
                FileInputStream(inputFile).use { inStream ->
                    inStream.skip(44)
                    val buffer = ByteArray(4096)
                    var currentPos = 0L
                    var written = 0L

                    var read: Int
                    while (inStream.read(buffer).also { read = it } != -1) {
                        val chunkStart = currentPos
                        val chunkEnd = currentPos + read

                        if (chunkEnd <= cutStartByte || chunkStart >= cutEndByte) {
                            // Entire chunk is outside the cut zone -> write as-is
                            outStream.write(buffer, 0, read)
                            written += read
                        } else {
                            // Chunk overlaps with cut zone -> write sample by sample outside cut
                            for (i in 0 until (read / 2)) {
                                val samplePos = currentPos + (i * 2)
                                if (samplePos < cutStartByte || samplePos >= cutEndByte) {
                                    outStream.write(buffer[i * 2].toInt())
                                    outStream.write(buffer[i * 2 + 1].toInt())
                                    written += 2
                                }
                            }
                        }

                        currentPos += read
                        if (outputBytes > 0) {
                            val p = ((written.toDouble() / outputBytes) * 100).toInt().coerceIn(0, 99)
                            onProgress(p)
                        }
                    }
                    outStream.flush()
                }
            }
            onProgress(100)
            true
        } catch (e: Exception) {
            false
        }
    }
}
