package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.view.Surface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max

object VideoEngine {

    // Trim Video without re-encoding using native MediaExtractor and MediaMuxer
    suspend fun trimVideo(
        inputFile: File,
        outputFile: File,
        startMs: Long,
        endMs: Long,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(inputFile.absolutePath)
            val trackCount = extractor.trackCount
            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val indexMap = HashMap<Int, Int>()
            var maxBufferSize = 256 * 1024

            for (i in 0 until trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    extractor.selectTrack(i)
                    val muxerTrackIndex = muxer.addTrack(format)
                    indexMap[i] = muxerTrackIndex
                    if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) {
                        val size = format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)
                        if (size > maxBufferSize) maxBufferSize = size
                    }
                }
            }

            if (indexMap.isEmpty()) return@withContext false

            muxer.start()

            val startUs = startMs * 1000L
            val endUs = endMs * 1000L
            val durationUs = max(1L, endUs - startUs)

            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            val buffer = ByteBuffer.allocate(maxBufferSize)
            val bufferInfo = MediaCodec.BufferInfo()

            while (true) {
                val trackIndex = extractor.sampleTrackIndex
                if (trackIndex < 0) break

                val muxerTrack = indexMap[trackIndex]
                if (muxerTrack != null) {
                    bufferInfo.offset = 0
                    bufferInfo.size = extractor.readSampleData(buffer, 0)
                    val sampleTime = extractor.sampleTime

                    if (bufferInfo.size < 0 || (endUs > 0 && sampleTime > endUs)) {
                        break
                    }

                    bufferInfo.presentationTimeUs = max(0L, sampleTime - startUs)
                    bufferInfo.flags = extractor.sampleFlags

                    muxer.writeSampleData(muxerTrack, buffer, bufferInfo)

                    val p = (((sampleTime - startUs).toDouble() / durationUs) * 100).toInt().coerceIn(0, 99)
                    onProgress(p)
                }

                extractor.advance()
            }

            onProgress(100)
            true
        } catch (e: Exception) {
            false
        } finally {
            try {
                extractor.release()
                muxer?.stop()
                muxer?.release()
            } catch (_: Exception) {
            }
        }
    }

    // Add Music / Replace audio in Video
    suspend fun addMusicToVideo(
        videoFile: File,
        audioFile: File,
        outputFile: File,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val videoExtractor = MediaExtractor()
        val audioExtractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            videoExtractor.setDataSource(videoFile.absolutePath)
            audioExtractor.setDataSource(audioFile.absolutePath)

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            var videoTrackIndex = -1
            var videoDurationUs = 1L
            for (i in 0 until videoExtractor.trackCount) {
                val format = videoExtractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/")) {
                    videoTrackIndex = i
                    if (format.containsKey(MediaFormat.KEY_DURATION)) {
                        videoDurationUs = format.getLong(MediaFormat.KEY_DURATION)
                    }
                    videoExtractor.selectTrack(i)
                    muxer.addTrack(format)
                    break
                }
            }

            var audioTrackIndex = -1
            for (i in 0 until audioExtractor.trackCount) {
                val format = audioExtractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioExtractor.selectTrack(i)
                    muxer.addTrack(format)
                    break
                }
            }

            if (videoTrackIndex == -1 || audioTrackIndex == -1) {
                return@withContext false
            }

            muxer.start()

            val buffer = ByteBuffer.allocate(256 * 1024)
            val bufferInfo = MediaCodec.BufferInfo()

            // Write video samples
            while (true) {
                bufferInfo.offset = 0
                bufferInfo.size = videoExtractor.readSampleData(buffer, 0)
                if (bufferInfo.size < 0) break
                bufferInfo.presentationTimeUs = videoExtractor.sampleTime
                bufferInfo.flags = videoExtractor.sampleFlags
                muxer.writeSampleData(0, buffer, bufferInfo)

                val p = ((bufferInfo.presentationTimeUs.toDouble() / videoDurationUs) * 50).toInt().coerceIn(0, 50)
                onProgress(p)
                videoExtractor.advance()
            }

            // Write audio samples
            while (true) {
                bufferInfo.offset = 0
                bufferInfo.size = audioExtractor.readSampleData(buffer, 0)
                if (bufferInfo.size < 0) break
                val sampleTime = audioExtractor.sampleTime
                if (sampleTime > videoDurationUs) break // Do not exceed video duration
                bufferInfo.presentationTimeUs = sampleTime
                bufferInfo.flags = audioExtractor.sampleFlags
                muxer.writeSampleData(1, buffer, bufferInfo)

                val p = (50 + (sampleTime.toDouble() / videoDurationUs) * 49).toInt().coerceIn(50, 99)
                onProgress(p)
                audioExtractor.advance()
            }

            onProgress(100)
            true
        } catch (e: Exception) {
            false
        } finally {
            try {
                videoExtractor.release()
                audioExtractor.release()
                muxer?.stop()
                muxer?.release()
            } catch (_: Exception) {
            }
        }
    }

    // Create Slideshow Video from Photos & Audio using MediaCodec H.264
    suspend fun createVideoFromPhotosAndAudio(
        photoFiles: List<File>,
        audioFile: File?,
        outputFile: File,
        photoDurationMs: Long = 6000L,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        if (photoFiles.isEmpty()) return@withContext false

        val width = 720
        val height = 1280
        val frameRate = 25
        val bitRate = 2_000_000 // 2Mbps
        val iFrameInterval = 2

        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var inputSurface: Surface? = null
        val audioExtractor = MediaExtractor()

        try {
            val totalDurationMs = photoFiles.size * photoDurationMs
            val totalFrames = ((totalDurationMs / 1000.0) * frameRate).toInt()

            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
                setInteger(MediaFormat.KEY_FRAME_RATE, frameRate)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, iFrameInterval)
            }

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = encoder.createInputSurface()
            encoder.start()

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var videoTrackIndex = -1
            var audioTrackIndex = -1

            var hasAudioTrack = false
            if (audioFile != null && audioFile.exists()) {
                try {
                    audioExtractor.setDataSource(audioFile.absolutePath)
                    for (i in 0 until audioExtractor.trackCount) {
                        val trackFormat = audioExtractor.getTrackFormat(i)
                        val mime = trackFormat.getString(MediaFormat.KEY_MIME) ?: ""
                        if (mime.startsWith("audio/")) {
                            audioExtractor.selectTrack(i)
                            audioTrackIndex = muxer.addTrack(trackFormat)
                            hasAudioTrack = true
                            break
                        }
                    }
                } catch (_: Exception) {
                }
            }

            val bufferInfo = MediaCodec.BufferInfo()
            var muxerStarted = false
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

            // Cache scaled bitmaps
            val loadedBitmaps = photoFiles.map { file ->
                try {
                    val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
                    BitmapFactory.decodeFile(file.absolutePath, opts)
                } catch (_: Exception) {
                    null
                }
            }

            var currentPhotoIdx = 0
            val framesPerPhoto = ((photoDurationMs / 1000.0) * frameRate).toInt()

            for (frame in 0 until totalFrames) {
                currentPhotoIdx = (frame / framesPerPhoto).coerceIn(0, photoFiles.size - 1)
                val bmp = loadedBitmaps.getOrNull(currentPhotoIdx)

                // Render frame onto surface canvas
                val canvas = inputSurface.lockCanvas(null)
                if (canvas != null) {
                    canvas.drawColor(0xFF10141D.toInt()) // Studio dark background
                    if (bmp != null && !bmp.isRecycled) {
                        val srcRect = Rect(0, 0, bmp.width, bmp.height)
                        // Scale to aspect fit center
                        val scale = minOf(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
                        val drawW = (bmp.width * scale).toInt()
                        val drawH = (bmp.height * scale).toInt()
                        val left = (width - drawW) / 2
                        val top = (height - drawH) / 2
                        val dstRect = Rect(left, top, left + drawW, top + drawH)
                        canvas.drawBitmap(bmp, srcRect, dstRect, paint)
                    }
                    inputSurface.unlockCanvasAndPost(canvas)
                }

                // Poll encoder output
                var outIndex = encoder.dequeueOutputBuffer(bufferInfo, 10000)
                while (outIndex >= 0 || outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val newFormat = encoder.outputFormat
                        videoTrackIndex = muxer.addTrack(newFormat)
                        muxer.start()
                        muxerStarted = true
                    } else if (outIndex >= 0) {
                        val encodedData = encoder.getOutputBuffer(outIndex)
                        if (encodedData != null && muxerStarted && bufferInfo.size > 0) {
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            bufferInfo.presentationTimeUs = (frame * 1_000_000L / frameRate)
                            muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                        }
                        encoder.releaseOutputBuffer(outIndex, false)
                    }
                    outIndex = encoder.dequeueOutputBuffer(bufferInfo, 0)
                }

                val p = ((frame.toDouble() / totalFrames) * 80).toInt().coerceIn(0, 80)
                onProgress(p)
            }

            encoder.signalEndOfInputStream()

            // Drain remaining encoder output
            while (true) {
                val outIndex = encoder.dequeueOutputBuffer(bufferInfo, 20000)
                if (outIndex >= 0) {
                    val encodedData = encoder.getOutputBuffer(outIndex)
                    if (encodedData != null && muxerStarted && bufferInfo.size > 0) {
                        muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                    }
                    encoder.releaseOutputBuffer(outIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                } else if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    break
                }
            }

            // Mux audio track if present
            if (hasAudioTrack && muxerStarted && audioTrackIndex >= 0) {
                val audioBuf = ByteBuffer.allocate(64 * 1024)
                val audioInfo = MediaCodec.BufferInfo()
                val totalAudioDurationUs = totalDurationMs * 1000L

                while (true) {
                    audioInfo.offset = 0
                    audioInfo.size = audioExtractor.readSampleData(audioBuf, 0)
                    if (audioInfo.size < 0) break
                    val sampleTime = audioExtractor.sampleTime
                    if (sampleTime > totalAudioDurationUs) break
                    audioInfo.presentationTimeUs = sampleTime
                    audioInfo.flags = audioExtractor.sampleFlags
                    muxer.writeSampleData(audioTrackIndex, audioBuf, audioInfo)
                    audioExtractor.advance()
                }
            }

            // Cleanup bitmaps
            for (b in loadedBitmaps) {
                try {
                    b?.recycle()
                } catch (_: Exception) {}
            }

            onProgress(100)
            true
        } catch (e: Exception) {
            false
        } finally {
            try {
                encoder?.stop()
                encoder?.release()
                inputSurface?.release()
                audioExtractor.release()
                muxer?.stop()
                muxer?.release()
            } catch (_: Exception) {
            }
        }
    }

    // Tool 11: ऑडियो में फोटो लगाकर वीडियो बनाएँ
    // Master audio file dictates the exact full duration. Photos are displayed sequentially across the audio.
    suspend fun createVideoForAudioWithPhotos(
        audioFile: File,
        photoFiles: List<File>,
        outputFile: File,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        if (!audioFile.exists() || photoFiles.isEmpty()) return@withContext false

        // Determine exact audio duration
        val audioDurationMs = try {
            val retriever = android.media.MediaMetadataRetriever()
            retriever.setDataSource(audioFile.absolutePath)
            val d = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            retriever.release()
            d
        } catch (_: Exception) {
            0L
        }

        if (audioDurationMs <= 0L) return@withContext false

        val photoDurationMs = max(1000L, audioDurationMs / photoFiles.size)
        // Use createVideoFromPhotosAndAudio with photoDurationMs calculated to match exact audio length
        return@withContext createVideoFromPhotosAndAudio(
            photoFiles = photoFiles,
            audioFile = audioFile,
            outputFile = outputFile,
            photoDurationMs = photoDurationMs,
            onProgress = onProgress
        )
    }

    // Tool 12: वीडियो क्लिप जोड़कर वीडियो बनाएँ (Concatenate multiple video files)
    suspend fun concatenateVideoClips(
        videoFiles: List<File>,
        outputFile: File,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        if (videoFiles.isEmpty()) return@withContext false
        if (videoFiles.size == 1) {
            videoFiles[0].copyTo(outputFile, overwrite = true)
            onProgress(100)
            return@withContext true
        }

        var muxer: MediaMuxer? = null
        try {
            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var videoTrackIndex = -1
            var audioTrackIndex = -1
            var muxerStarted = false

            var videoPtsOffsetUs = 0L
            var audioPtsOffsetUs = 0L

            val buffer = ByteBuffer.allocate(512 * 1024)
            val bufferInfo = MediaCodec.BufferInfo()

            for (clipIdx in videoFiles.indices) {
                val clip = videoFiles[clipIdx]
                if (!clip.exists()) continue

                val extractor = MediaExtractor()
                extractor.setDataSource(clip.absolutePath)

                var clipVideoTrack = -1
                var clipAudioTrack = -1
                var clipVideoDurationUs = 0L
                var clipAudioDurationUs = 0L

                for (i in 0 until extractor.trackCount) {
                    val format = extractor.getTrackFormat(i)
                    val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("video/") && clipVideoTrack == -1) {
                        clipVideoTrack = i
                        if (!muxerStarted) {
                            videoTrackIndex = muxer.addTrack(format)
                        }
                        if (format.containsKey(MediaFormat.KEY_DURATION)) {
                            clipVideoDurationUs = format.getLong(MediaFormat.KEY_DURATION)
                        }
                    } else if (mime.startsWith("audio/") && clipAudioTrack == -1) {
                        clipAudioTrack = i
                        if (!muxerStarted) {
                            audioTrackIndex = muxer.addTrack(format)
                        }
                        if (format.containsKey(MediaFormat.KEY_DURATION)) {
                            clipAudioDurationUs = format.getLong(MediaFormat.KEY_DURATION)
                        }
                    }
                }

                if (!muxerStarted) {
                    muxer.start()
                    muxerStarted = true
                }

                // Write video samples from this clip
                if (clipVideoTrack >= 0 && videoTrackIndex >= 0) {
                    extractor.selectTrack(clipVideoTrack)
                    var lastSampleTime = 0L
                    while (true) {
                        bufferInfo.offset = 0
                        bufferInfo.size = extractor.readSampleData(buffer, 0)
                        if (bufferInfo.size < 0) break
                        lastSampleTime = extractor.sampleTime
                        bufferInfo.presentationTimeUs = videoPtsOffsetUs + lastSampleTime
                        bufferInfo.flags = extractor.sampleFlags
                        muxer.writeSampleData(videoTrackIndex, buffer, bufferInfo)
                        extractor.advance()
                    }
                    extractor.unselectTrack(clipVideoTrack)
                    videoPtsOffsetUs += max(clipVideoDurationUs, lastSampleTime + 33333L)
                }

                // Write audio samples from this clip
                if (clipAudioTrack >= 0 && audioTrackIndex >= 0) {
                    extractor.selectTrack(clipAudioTrack)
                    var lastSampleTime = 0L
                    while (true) {
                        bufferInfo.offset = 0
                        bufferInfo.size = extractor.readSampleData(buffer, 0)
                        if (bufferInfo.size < 0) break
                        lastSampleTime = extractor.sampleTime
                        bufferInfo.presentationTimeUs = audioPtsOffsetUs + lastSampleTime
                        bufferInfo.flags = extractor.sampleFlags
                        muxer.writeSampleData(audioTrackIndex, buffer, bufferInfo)
                        extractor.advance()
                    }
                    extractor.unselectTrack(clipAudioTrack)
                    audioPtsOffsetUs += max(clipAudioDurationUs, lastSampleTime + 23219L)
                }

                extractor.release()
                val p = (((clipIdx + 1).toDouble() / videoFiles.size) * 100).toInt().coerceIn(0, 99)
                onProgress(p)
            }

            onProgress(100)
            true
        } catch (e: Exception) {
            false
        } finally {
            try {
                muxer?.stop()
                muxer?.release()
            } catch (_: Exception) {}
        }
    }

    // Tool 9: वीडियो की मूल आवाज़ नियंत्रित करें (Mute or adjust)
    suspend fun adjustVideoVolume(
        videoFile: File,
        outputFile: File,
        muteAudio: Boolean,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(videoFile.absolutePath)
            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            var videoTrack = -1
            var audioTrack = -1
            var videoDurationUs = 1L

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/")) {
                    videoTrack = i
                    if (format.containsKey(MediaFormat.KEY_DURATION)) {
                        videoDurationUs = format.getLong(MediaFormat.KEY_DURATION)
                    }
                    muxer.addTrack(format)
                } else if (mime.startsWith("audio/") && !muteAudio) {
                    audioTrack = i
                    muxer.addTrack(format)
                }
            }

            if (videoTrack == -1) return@withContext false
            muxer.start()

            val buffer = ByteBuffer.allocate(256 * 1024)
            val bufferInfo = MediaCodec.BufferInfo()

            // Copy video track
            extractor.selectTrack(videoTrack)
            while (true) {
                bufferInfo.offset = 0
                bufferInfo.size = extractor.readSampleData(buffer, 0)
                if (bufferInfo.size < 0) break
                bufferInfo.presentationTimeUs = extractor.sampleTime
                bufferInfo.flags = extractor.sampleFlags
                muxer.writeSampleData(0, buffer, bufferInfo)
                val p = ((bufferInfo.presentationTimeUs.toDouble() / videoDurationUs) * 90).toInt().coerceIn(0, 90)
                onProgress(p)
                extractor.advance()
            }
            extractor.unselectTrack(videoTrack)

            // Copy audio if not muted
            if (!muteAudio && audioTrack >= 0) {
                extractor.selectTrack(audioTrack)
                while (true) {
                    bufferInfo.offset = 0
                    bufferInfo.size = extractor.readSampleData(buffer, 0)
                    if (bufferInfo.size < 0) break
                    bufferInfo.presentationTimeUs = extractor.sampleTime
                    bufferInfo.flags = extractor.sampleFlags
                    muxer.writeSampleData(1, buffer, bufferInfo)
                    extractor.advance()
                }
            }

            onProgress(100)
            true
        } catch (e: Exception) {
            false
        } finally {
            try {
                extractor.release()
                muxer?.stop()
                muxer?.release()
            } catch (_: Exception) {}
        }
    }

    // Safe Downsampled Bitmap Decoder to prevent OutOfMemory on long stories
    fun decodeSampledBitmap(file: File, reqWidth: Int = 720, reqHeight: Int = 1280): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, options)
            var inSampleSize = 1
            if (options.outHeight > reqHeight || options.outWidth > reqWidth) {
                val halfHeight = options.outHeight / 2
                val halfWidth = options.outWidth / 2
                while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                    inSampleSize *= 2
                }
            }
            val loadOptions = BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            BitmapFactory.decodeFile(file.absolutePath, loadOptions)
        } catch (e: Exception) {
            null
        }
    }

    // भाग 1 (सुविधा 1): ऑडियो में सही समय पर फोटो लगाकर वीडियो बनाएँ
    // Master audio dictates the entire video duration (e.g. 34 minutes). Photos appear at exact timestamps.
    suspend fun createVideoForAudioWithTimedPhotos(
        audioFile: File,
        timedPhotos: List<TimedPhotoData>,
        outputFile: File,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        if (!audioFile.exists() || timedPhotos.isEmpty()) return@withContext false

        val audioDurationMs = try {
            val retriever = android.media.MediaMetadataRetriever()
            retriever.setDataSource(audioFile.absolutePath)
            val d = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            retriever.release()
            d
        } catch (_: Exception) {
            0L
        }

        if (audioDurationMs <= 0L) return@withContext false

        val width = 720
        val height = 1280
        val frameRate = 25
        val bitRate = 2_200_000
        val iFrameInterval = 2

        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var inputSurface: Surface? = null
        val audioExtractor = MediaExtractor()

        try {
            val totalFrames = ((audioDurationMs / 1000.0) * frameRate).toInt().coerceAtLeast(1)

            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
                setInteger(MediaFormat.KEY_FRAME_RATE, frameRate)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, iFrameInterval)
            }

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = encoder.createInputSurface()
            encoder.start()

            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var videoTrackIndex = -1
            var audioTrackIndex = -1
            var hasAudioTrack = false

            try {
                audioExtractor.setDataSource(audioFile.absolutePath)
                for (i in 0 until audioExtractor.trackCount) {
                    val trackFormat = audioExtractor.getTrackFormat(i)
                    val mime = trackFormat.getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("audio/")) {
                        audioExtractor.selectTrack(i)
                        audioTrackIndex = muxer.addTrack(trackFormat)
                        hasAudioTrack = true
                        break
                    }
                }
            } catch (_: Exception) {}

            val bufferInfo = MediaCodec.BufferInfo()
            var muxerStarted = false
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

            // Cache scaled bitmaps safely
            val bitmapMap = mutableMapOf<String, Bitmap>()
            for (item in timedPhotos) {
                val bmp = decodeSampledBitmap(item.file, width, height)
                if (bmp != null) {
                    bitmapMap[item.id] = bmp
                }
            }

            val sortedPhotos = timedPhotos.sortedBy { it.startMs }
            var lastActiveBmp: Bitmap? = bitmapMap[sortedPhotos.firstOrNull()?.id]

            for (frame in 0 until totalFrames) {
                val currentFrameMs = (frame * 1000L / frameRate)

                // Find active photo at this exact millisecond
                val activeItem = sortedPhotos.find { currentFrameMs >= it.startMs && currentFrameMs < it.endMs }
                val currentBmp = if (activeItem != null) {
                    bitmapMap[activeItem.id] ?: lastActiveBmp
                } else {
                    lastActiveBmp
                }
                if (currentBmp != null) {
                    lastActiveBmp = currentBmp
                }

                val canvas = inputSurface.lockCanvas(null)
                if (canvas != null) {
                    canvas.drawColor(0xFF10141D.toInt()) // Studio dark background
                    if (currentBmp != null && !currentBmp.isRecycled) {
                        val srcRect = Rect(0, 0, currentBmp.width, currentBmp.height)
                        val scale = minOf(width.toFloat() / currentBmp.width, height.toFloat() / currentBmp.height)
                        val drawW = (currentBmp.width * scale).toInt()
                        val drawH = (currentBmp.height * scale).toInt()
                        val left = (width - drawW) / 2
                        val top = (height - drawH) / 2
                        val dstRect = Rect(left, top, left + drawW, top + drawH)
                        canvas.drawBitmap(currentBmp, srcRect, dstRect, paint)
                    }
                    inputSurface.unlockCanvasAndPost(canvas)
                }

                // Poll encoder output
                var outIndex = encoder.dequeueOutputBuffer(bufferInfo, 10000)
                while (outIndex >= 0 || outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        val newFormat = encoder.outputFormat
                        videoTrackIndex = muxer.addTrack(newFormat)
                        muxer.start()
                        muxerStarted = true
                    } else if (outIndex >= 0) {
                        val encodedData = encoder.getOutputBuffer(outIndex)
                        if (encodedData != null && muxerStarted && bufferInfo.size > 0) {
                            encodedData.position(bufferInfo.offset)
                            encodedData.limit(bufferInfo.offset + bufferInfo.size)
                            bufferInfo.presentationTimeUs = (frame * 1_000_000L / frameRate)
                            muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                        }
                        encoder.releaseOutputBuffer(outIndex, false)
                    }
                    outIndex = encoder.dequeueOutputBuffer(bufferInfo, 0)
                }

                if (frame % (frameRate * 2) == 0 || frame == totalFrames - 1) {
                    val p = ((frame.toDouble() / totalFrames) * 80).toInt().coerceIn(0, 80)
                    onProgress(p)
                }
            }

            encoder.signalEndOfInputStream()

            // Drain remaining
            while (true) {
                val outIndex = encoder.dequeueOutputBuffer(bufferInfo, 20000)
                if (outIndex >= 0) {
                    val encodedData = encoder.getOutputBuffer(outIndex)
                    if (encodedData != null && muxerStarted && bufferInfo.size > 0) {
                        muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                    }
                    encoder.releaseOutputBuffer(outIndex, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        break
                    }
                } else if (outIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    break
                }
            }

            // Mux master audio track
            if (hasAudioTrack && muxerStarted && audioTrackIndex >= 0) {
                val audioBuf = ByteBuffer.allocate(64 * 1024)
                val audioInfo = MediaCodec.BufferInfo()
                val totalAudioDurationUs = audioDurationMs * 1000L

                while (true) {
                    audioInfo.offset = 0
                    audioInfo.size = audioExtractor.readSampleData(audioBuf, 0)
                    if (audioInfo.size < 0) break
                    val sampleTime = audioExtractor.sampleTime
                    if (sampleTime > totalAudioDurationUs) break
                    audioInfo.presentationTimeUs = sampleTime
                    audioInfo.flags = audioExtractor.sampleFlags
                    muxer.writeSampleData(audioTrackIndex, audioBuf, audioInfo)
                    audioExtractor.advance()
                }
            }

            for (b in bitmapMap.values) {
                try { b.recycle() } catch (_: Exception) {}
            }

            onProgress(100)
            true
        } catch (e: Exception) {
            false
        } finally {
            try {
                encoder?.stop()
                encoder?.release()
                inputSurface?.release()
                audioExtractor.release()
                muxer?.stop()
                muxer?.release()
            } catch (_: Exception) {}
        }
    }

    // भाग 1 (सुविधा 2): वीडियो में सही समय पर फोटो लगाएँ
    // Inserts photos over an existing video at specified timestamps without desynchronizing audio.
    suspend fun overlayPhotosOnVideo(
        videoFile: File,
        timedPhotos: List<TimedPhotoData>,
        outputFile: File,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        if (!videoFile.exists() || timedPhotos.isEmpty()) return@withContext false
        try {
            val tempAudio = File(outputFile.parentFile, "temp_ovl_audio_${System.currentTimeMillis()}.m4a")
            val extracted = AudioEngine.extractAudioFromVideo(videoFile, tempAudio) { onProgress((it * 0.2).toInt()) }
            val audioToUse = if (extracted && tempAudio.exists()) tempAudio else null

            val tempOverlay = File(outputFile.parentFile, "temp_ovl_vid_${System.currentTimeMillis()}.mp4")
            val rendered = if (audioToUse != null) {
                createVideoForAudioWithTimedPhotos(audioToUse, timedPhotos, tempOverlay) { p ->
                    onProgress(20 + (p * 0.75).toInt())
                }
            } else {
                false
            }
            tempAudio.delete()

            if (rendered && tempOverlay.exists()) {
                tempOverlay.copyTo(outputFile, overwrite = true)
                tempOverlay.delete()
                onProgress(100)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    // भाग 3: वीडियो में साउंड इफेक्ट जोड़ें (Dedicated Video SFX tool)
    suspend fun addSfxToVideo(
        videoFile: File,
        sfxFile: File,
        startMs: Long,
        sfxVol: Float,
        outputFile: File,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val tempAudio = File(outputFile.parentFile, "temp_vid_audio_${System.currentTimeMillis()}.m4a")
        val tempSfxOut = File(outputFile.parentFile, "temp_sfx_mixed_${System.currentTimeMillis()}.wav")
        try {
            val extracted = AudioEngine.extractAudioFromVideo(videoFile, tempAudio) { p ->
                onProgress((p * 0.3).toInt())
            }
            if (!extracted || !tempAudio.exists()) return@withContext false

            val mixed = AudioEngine.applySoundEffects(
                mainAudio = tempAudio,
                sfxFile = sfxFile,
                outputFile = tempSfxOut,
                offsetMs = startMs,
                durationMs = 0L,
                sfxVolume = sfxVol
            ) { p ->
                onProgress(30 + (p * 0.4).toInt())
            }

            val audioToMux = if (mixed && tempSfxOut.exists()) tempSfxOut else tempAudio

            val added = addMusicToVideo(videoFile, audioToMux, outputFile) { p ->
                onProgress(70 + (p * 0.3).toInt())
            }
            added
        } catch (e: Exception) {
            false
        } finally {
            tempAudio.delete()
            tempSfxOut.delete()
        }
    }

    // भाग 2: वीडियो क्लिप जोड़कर वीडियो बनाएँ (With individual clip volume, trimming, and BGM)
    suspend fun concatenateVideoClipsWithAudioControl(
        clipConfigs: List<VideoClipConfig>,
        bgMusicFile: File?,
        bgMusicVol: Float,
        outputFile: File,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        if (clipConfigs.isEmpty()) return@withContext false
        val processedClips = mutableListOf<File>()
        val tempFiles = mutableListOf<File>()

        try {
            for (i in clipConfigs.indices) {
                val cfg = clipConfigs[i]
                var currentClipFile = cfg.file
                val duration = try {
                    val retriever = android.media.MediaMetadataRetriever()
                    retriever.setDataSource(currentClipFile.absolutePath)
                    val d = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    retriever.release()
                    d
                } catch (_: Exception) { 0L }

                // 1. Trimming if set
                if (cfg.startTrimMs > 0 || (cfg.endTrimMs > 0 && cfg.endTrimMs < duration)) {
                    val trimmed = File(outputFile.parentFile, "trimmed_${i}_${System.currentTimeMillis()}.mp4")
                    val ok = trimVideo(currentClipFile, trimmed, cfg.startTrimMs, if (cfg.endTrimMs > 0) cfg.endTrimMs else duration) {}
                    if (ok && trimmed.exists()) {
                        tempFiles.add(trimmed)
                        currentClipFile = trimmed
                    }
                }

                // 2. Mute if volume is 0
                if (cfg.volume == 0f) {
                    val muted = File(outputFile.parentFile, "muted_${i}_${System.currentTimeMillis()}.mp4")
                    val ok = adjustVideoVolume(currentClipFile, muted, muteAudio = true) {}
                    if (ok && muted.exists()) {
                        tempFiles.add(muted)
                        currentClipFile = muted
                    }
                }

                val repetitions = if (cfg.isRepeatEnabled) cfg.repeatCount.coerceIn(1, 50) else 1
                for (r in 0 until repetitions) {
                    processedClips.add(currentClipFile)
                }
                onProgress(((i + 1).toDouble() / clipConfigs.size * 50).toInt())
            }

            val tempMerged = File(outputFile.parentFile, "temp_merged_${System.currentTimeMillis()}.mp4")
            tempFiles.add(tempMerged)
            val mergedOk = concatenateVideoClips(processedClips, tempMerged) { p ->
                onProgress(50 + (p * 0.35).toInt())
            }

            if (!mergedOk || !tempMerged.exists()) return@withContext false

            if (bgMusicFile != null && bgMusicFile.exists()) {
                val added = addMusicToVideo(tempMerged, bgMusicFile, outputFile) { p ->
                    onProgress(85 + (p * 0.15).toInt())
                }
                onProgress(100)
                added
            } else {
                tempMerged.copyTo(outputFile, overwrite = true)
                onProgress(100)
                true
            }
        } catch (e: Exception) {
            false
        } finally {
            for (f in tempFiles) {
                try { f.delete() } catch (_: Exception) {}
            }
        }
    }
}

data class TimedPhotoData(
    val id: String = java.util.UUID.randomUUID().toString(),
    val file: File,
    var startMs: Long = 0L,
    var endMs: Long = 5000L,
    var label: String = ""
)

data class VideoClipConfig(
    val id: String = java.util.UUID.randomUUID().toString(),
    val file: File,
    var startTrimMs: Long = 0L,
    var endTrimMs: Long = 0L,
    var volume: Float = 1.0f,
    var label: String = "",
    var isRepeatEnabled: Boolean = false,
    var repeatCount: Int = 1
)
