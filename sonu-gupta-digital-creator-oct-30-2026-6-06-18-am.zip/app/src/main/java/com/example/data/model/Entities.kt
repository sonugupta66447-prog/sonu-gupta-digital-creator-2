package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val title: String,
    val projectType: String, // "AUDIO", "VIDEO", "HYBRID"
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val totalDurationMs: Long = 0L,
    val outputFilePath: String? = null,
    val description: String = ""
)

@Entity(tableName = "media_clips")
data class MediaClipEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val clipType: String, // "PHOTO", "VIDEO", "AUDIO_VOICE", "AUDIO_MUSIC", "AUDIO_SFX"
    val filePath: String,
    val title: String,
    val orderIndex: Int,
    val durationMs: Long,
    val startOffsetMs: Long = 0L,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = durationMs,
    val volume: Float = 1.0f,
    val extraNote: String = ""
)

@Entity(tableName = "saved_files")
data class SavedFileEntity(
    @PrimaryKey val id: String,
    val fileName: String,
    val filePath: String,
    val mediaType: String, // "AUDIO", "VIDEO"
    val format: String, // "WAV", "MP4", "AAC"
    val durationMs: Long,
    val fileSizeBytes: Long,
    val createdAt: Long = System.currentTimeMillis()
)
