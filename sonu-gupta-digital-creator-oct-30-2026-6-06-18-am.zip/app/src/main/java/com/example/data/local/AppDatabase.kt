package com.example.data.local

import androidx.room.*
import com.example.data.model.MediaClipEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.SavedFileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :projectId LIMIT 1")
    suspend fun getProjectById(projectId: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity)

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Delete
    suspend fun deleteProject(project: ProjectEntity)

    @Query("SELECT * FROM media_clips WHERE projectId = :projectId ORDER BY orderIndex ASC")
    fun getClipsForProject(projectId: String): Flow<List<MediaClipEntity>>

    @Query("SELECT * FROM media_clips WHERE projectId = :projectId ORDER BY orderIndex ASC")
    suspend fun getClipsForProjectSync(projectId: String): List<MediaClipEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClips(clips: List<MediaClipEntity>)

    @Query("DELETE FROM media_clips WHERE projectId = :projectId")
    suspend fun deleteClipsForProject(projectId: String)

    @Query("SELECT * FROM saved_files ORDER BY createdAt DESC")
    fun getAllSavedFiles(): Flow<List<SavedFileEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedFile(savedFile: SavedFileEntity)

    @Delete
    suspend fun deleteSavedFile(savedFile: SavedFileEntity)

    @Query("DELETE FROM saved_files WHERE id = :id")
    suspend fun deleteSavedFileById(id: String)
}

@Database(entities = [ProjectEntity::class, MediaClipEntity::class, SavedFileEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
}
