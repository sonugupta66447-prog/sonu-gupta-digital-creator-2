package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.utils.AudioEngine
import com.example.utils.FileUtil
import com.example.utils.HapticAndSoundUtil
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MainViewModel
import java.io.File

@Composable
fun AudioEditorMenuScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedAudio by viewModel.selectedAudioFile.collectAsStateWithLifecycle()

    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "PickedAudio", "wav")
            if (copied != null) {
                viewModel.selectedAudioFile.value = copied
                HapticAndSoundUtil.announceForAccessibility(context, "ऑडियो फाइल चुनी गई: ${copied.name}")
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Active Selected Audio Header
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (selectedAudio != null) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (selectedAudio != null) "वर्तमान सक्रिय ऑडियो: ${selectedAudio?.name}" else "कोई ऑडियो फाइल नहीं चुनी गई है",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    if (selectedAudio != null) {
                        val dur = FileUtil.getMediaDuration(context, selectedAudio!!)
                        Text(
                            text = "अवधि: ${FileUtil.formatDuration(dur)} (${FileUtil.formatDurationHindi(dur)})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AccessibleButton(
                            text = "फोन से ऑडियो चुनें",
                            icon = Icons.Default.FolderOpen,
                            onClick = { audioPicker.launch("audio/*") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Active Audio Player preview if available
        if (selectedAudio != null) {
            item {
                AudioPlayerCard(
                    audioFile = selectedAudio,
                    title = "वर्तमान ऑडियो सुनें (Preview)"
                )
            }
        }

        item {
            Text(
                text = "ऑडियो टूल सूची (Audio Tools)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
            )
        }

        // 1. Audio Recorder
        item {
            AudioToolItem(
                number = "1",
                title = "ऑडियो रिकॉर्डर",
                desc = "माइक्रोफोन से उच्च गुणवत्ता में लाइव आवाज़ रिकॉर्ड करें",
                icon = Icons.Default.Mic,
                onClick = { viewModel.navigateTo(AppScreen.AudioRecorderTool) }
            )
        }

        // 2. Record with Music
        item {
            AudioToolItem(
                number = "2",
                title = "म्यूजिक के साथ ऑडियो रिकॉर्ड करें",
                desc = "पहले बैकग्राउंड म्यूजिक चुनें, फिर म्यूजिक सुनते हुए अपनी आवाज़ रिकॉर्ड करें",
                icon = Icons.Default.QueueMusic,
                onClick = { viewModel.navigateTo(AppScreen.AudioRecordWithMusicTool) }
            )
        }

        // 3. Background Voice Recorder
        item {
            AudioToolItem(
                number = "3",
                title = "बैकग्राउंड वॉयस रिकॉर्डर",
                desc = "ऐप को बैकग्राउंड में रखकर भी निर्बाध ऑडियो रिकॉर्डिंग जारी रखें",
                icon = Icons.Default.Headphones,
                onClick = { viewModel.navigateTo(AppScreen.AudioRecorderTool) }
            )
        }

        // 4. Add Audio
        item {
            AudioToolItem(
                number = "4",
                title = "फोन से ऑडियो फ़ाइल जोड़ें",
                desc = "डिवाइस स्टोरेज से कोई भी ऑडियो फ़ाइल चुनें और लोड करें",
                icon = Icons.Default.FolderOpen,
                onClick = { audioPicker.launch("audio/*") }
            )
        }

        // 5. Audio Trim & Cut
        item {
            AudioToolItem(
                number = "5",
                title = "ऑडियो काटें (Trim Audio)",
                desc = "ऑडियो की शुरुआत और समाप्ति निर्धारित करके अनावश्यक भाग हटाएँ",
                icon = Icons.Default.ContentCut,
                onClick = { viewModel.navigateTo(AppScreen.AudioTrimTool) }
            )
        }

        // 6. Audio Merge
        item {
            AudioToolItem(
                number = "6",
                title = "ऑडियो जोड़ें (Merge Audios)",
                desc = "कई ऑडियो फाइलें क्रम में जोड़कर एक लंबी फाइल बनाएँ",
                icon = Icons.Default.CallMerge,
                onClick = { viewModel.navigateTo(AppScreen.AudioMergeTool) }
            )
        }

        // 7. Mix Voice with Music ("रिकॉर्ड की गई ऑडियो में म्यूजिक जोड़ें")
        item {
            AudioToolItem(
                number = "7",
                title = "रिकॉर्ड की गई ऑडियो में म्यूजिक जोड़ें",
                desc = "अपनी रिकॉर्ड की हुई कहानी, पॉडकास्ट या दूसरी ऑडियो में बैकग्राउंड म्यूजिक जोड़ें। म्यूजिक की आवाज़ और अवधि अपनी जरूरत के अनुसार तय करें और तैयार ऑडियो को सेव करें।",
                icon = Icons.Default.MusicNote,
                onClick = { viewModel.navigateTo(AppScreen.AudioMixMusicTool) }
            )
        }

        // 8. Auto-Ducking
        item {
            AudioToolItem(
                number = "8",
                title = "बोलते समय बैकग्राउंड म्यूजिक की आवाज़ कम करें (Auto-Ducking)",
                desc = "बोलने पर म्यूजिक अपने आप धीमा हो और रुकने पर वापस सामान्य स्तर पर आए",
                icon = Icons.Default.VolumeDown,
                onClick = { viewModel.navigateTo(AppScreen.AudioAutoDuckingTool) }
            )
        }

        // 9. Sound Effects
        item {
            AudioToolItem(
                number = "9",
                title = "साउंड इफेक्ट जोड़ें",
                desc = "घंटी, हुश, कदमों की आवाज़ या कस्टम इफेक्ट सटीक समय पर लगाएँ",
                icon = Icons.Default.GraphicEq,
                onClick = { viewModel.navigateTo(AppScreen.AudioSoundEffectsTool) }
            )
        }

        // 10. Volume Gain
        item {
            AudioToolItem(
                number = "10",
                title = "ऑडियो का वॉल्यूम नियंत्रित करें",
                desc = "ऑडियो की आवाज़ को बढ़ाएँ (Boost) या घटाएँ (10% से 250%)",
                icon = Icons.Default.VolumeUp,
                onClick = { viewModel.navigateTo(AppScreen.AudioGainControlTool) }
            )
        }

        // 11. Voice Modulation & Pitch
        item {
            AudioToolItem(
                number = "11",
                title = "आवाज़ बदलें (Voice Effects)",
                desc = "बच्चों जैसी आवाज़ (Child), भारी आवाज़ (Deep), और रोबोटिक आवाज़",
                icon = Icons.Default.RecordVoiceOver,
                onClick = { viewModel.navigateTo(AppScreen.AudioVoiceModulationTool) }
            )
        }

        // 12. Echo & Reverb
        item {
            AudioToolItem(
                number = "12",
                title = "आवाज़ की गूँज और इको नियंत्रित करें",
                desc = "ध्वनि में प्राकृतिक गूँज, इको और हॉल प्रभाव लगाएँ",
                icon = Icons.Default.SurroundSound,
                onClick = { viewModel.navigateTo(AppScreen.AudioVoiceModulationTool) }
            )
        }

        // 13. Noise Reduction
        item {
            AudioToolItem(
                number = "13",
                title = "ऑडियो से शोर कम करें (Noise Reduction)",
                desc = "बैकग्राउंड हम और हल्का शोर साफ़ करें",
                icon = Icons.Default.CleaningServices,
                onClick = { viewModel.navigateTo(AppScreen.AudioNoiseReductionTool) }
            )
        }

        // 14. Cut Middle
        item {
            AudioToolItem(
                number = "14",
                title = "ऑडियो की शुरुआत, बीच या अंत काटें",
                desc = "ऑडियो के बीच का अनावश्यक हिस्सा हटाकर बाकी जोड़ें",
                icon = Icons.Default.ContentCut,
                onClick = { viewModel.navigateTo(AppScreen.AudioTrimStartEndTool) }
            )
        }

        // 15. Extract Audio from Video
        item {
            AudioToolItem(
                number = "15",
                title = "वीडियो से ऑडियो निकालें",
                desc = "किसी भी वीडियो फाइल से उसका पूरा ऑडियो ट्रैक अलग करें",
                icon = Icons.Default.Audiotrack,
                onClick = { viewModel.navigateTo(AppScreen.AudioExtractFromVideoTool) }
            )
        }

        // 16. Audio to Video with Photos
        item {
            AudioToolItem(
                number = "16",
                title = "ऑडियो में फोटो लगाकर वीडियो बनाएँ",
                desc = "पूरी ऑडियो कहानी या पॉडकास्ट की अवधि के अनुसार फोटो लगाकर वीडियो बनाएँ",
                icon = Icons.Default.MovieCreation,
                onClick = { viewModel.navigateTo(AppScreen.AudioWithPhotosVideoTool) }
            )
        }

        // 17. Projects
        item {
            AudioToolItem(
                number = "17",
                title = "ऑडियो प्रोजेक्ट सुरक्षित करें एवं मेरे प्रोजेक्ट",
                desc = "सुरक्षित रखे गए संपादन योग्य प्रोजेक्ट्स देखें और खोलें",
                icon = Icons.Default.FolderSpecial,
                onClick = { viewModel.navigateTo(AppScreen.MyProjects) }
            )
        }
    }
}

@Composable
fun AudioToolItem(
    number: String,
    title: String,
    desc: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 64.dp)
            .clickable {
                HapticAndSoundUtil.vibrate(context, 25)
                onClick()
            }
            .semantics {
                contentDescription = "$number. $title. $desc"
                role = Role.Button
            },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = desc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = Icons.Default.ArrowForwardIos,
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
        }
    }
}
