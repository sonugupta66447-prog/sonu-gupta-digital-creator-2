package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StudioDarkBg = Color(0xFF0F172A) // Slate 900
val StudioSurfaceDark = Color(0xFF1E293B) // Slate 800
val StudioSurfaceVariantDark = Color(0xFF334155) // Slate 700

val StudioPrimaryAmber = Color(0xFFF59E0B) // Amber 500
val StudioPrimaryContainerDark = Color(0xFF451A03)
val StudioOnPrimaryDark = Color(0xFF000000)

val StudioSecondaryCyan = Color(0xFF06B6D4) // Cyan 500
val StudioAccentRed = Color(0xFFEF4444) // Recording Red

val StudioLightBg = Color(0xFFF8FAFC) // Slate 50
val StudioSurfaceLight = Color(0xFFFFFFFF)
val StudioSurfaceVariantLight = Color(0xFFE2E8F0) // Slate 200

val StudioPrimaryLight = Color(0xFFD97706) // Amber 600
val StudioOnPrimaryLight = Color(0xFFFFFFFF)
