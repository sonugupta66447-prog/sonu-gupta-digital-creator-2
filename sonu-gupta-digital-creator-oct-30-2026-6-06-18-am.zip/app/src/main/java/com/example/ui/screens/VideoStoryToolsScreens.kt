package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.utils.FileUtil
import com.example.utils.HapticAndSoundUtil
import com.example.utils.TimedPhotoData
import com.example.viewmodel.MainViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * भाग 1 (सुविधा 2): वीडियो में सही समय पर फोटो लगाएँ
 * Insert/Overlay photos over an existing video at specific timestamps without desynchronizing audio.
 */
@Composable
fun VideoOverlayPhotosToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val videoFile by viewModel.selectedVideoFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var overlayPhotos by remember { mutableStateOf<List<TimedPhotoData>>(emptyList()) }
    var currentPlaybackMs by remember { mutableLongStateOf(0L) }
    var outputVideo by remember { mutableStateOf<File?>(null) }
    var showTimeEditDialog by remember { mutableStateOf<TimedPhotoData?>(null) }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "BaseVideo", "mp4")
            viewModel.selectedVideoFile.value = copied
            HapticAndSoundUtil.announceForAccessibility(context, "मुख्य वीडियो चुना गया")
        }
    }

    val photoPickerForCurrentTime = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && videoFile != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "OverlayPhoto_${System.currentTimeMillis() % 1000}", "jpg")
            if (copied != null) {
                val dur = FileUtil.getMediaDuration(context, videoFile!!)
                val start = currentPlaybackMs
                val end = minOf(dur, currentPlaybackMs + 8000L) // Default 8s
                val newPhoto = TimedPhotoData(
                    file = copied,
                    startMs = start,
                    endMs = end,
                    label = "फोटो ${overlayPhotos.size + 1}"
                )
                overlayPhotos = overlayPhotos + newPhoto
                HapticAndSoundUtil.announceForAccessibility(
                    context,
                    "${newPhoto.label} समय ${FileUtil.formatDurationHindi(start)} पर जोड़ी गई"
                )
            }
        }
    }

    val manualPhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && videoFile != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "OverlayPhoto_${System.currentTimeMillis() % 1000}", "jpg")
            if (copied != null) {
                val dur = FileUtil.getMediaDuration(context, videoFile!!)
                val newPhoto = TimedPhotoData(
                    file = copied,
                    startMs = 0L,
                    endMs = minOf(dur, 6000L),
                    label = "फोटो ${overlayPhotos.size + 1}"
                )
                overlayPhotos = overlayPhotos + newPhoto
                showTimeEditDialog = newPhoto
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "वीडियो में सही समय पर फोटो लगाएँ",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "पहले से रिकॉर्ड किए गए वीडियो में किसी खास समय (जैसे चायवाला, बाजार का दृश्य, पात्र) पर फोटो दिखाएँ। वीडियो का मूल ऑडियो बिना रुकावट चलता रहेगा।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            AccessibleButton(
                text = if (videoFile != null) "वीडियो: ${videoFile?.name}" else "1. फोन से वीडियो चुनें",
                icon = Icons.Default.Movie,
                onClick = { videoPicker.launch("video/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (videoFile != null) {
            item {
                VideoPlayerCard(
                    videoFile = videoFile,
                    title = "वीडियो की जाँच करें (Preview & Seek)",
                    onPositionChanged = { pos -> currentPlaybackMs = pos }
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "वर्तमान प्लेबैक स्थिति: ${FileUtil.formatDuration(currentPlaybackMs)} (${FileUtil.formatDurationHindi(currentPlaybackMs)})",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "वीडियो चलाते समय जिस बिंदु पर फोटो लगानी हो, नीचे दिए गए बटन पर क्लिक करें।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AccessibleButton(
                        text = "वर्तमान समय पर फोटो लगाएँ",
                        icon = Icons.Default.AddPhotoAlternate,
                        onClick = { photoPickerForCurrentTime.launch("image/*") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = { manualPhotoPicker.launch("image/*") },
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 52.dp)
                            .semantics { contentDescription = "फोटो जोड़ें और समय दर्ज करें" }
                    ) {
                        Text("+ समय दर्ज करें", fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            if (overlayPhotos.isNotEmpty()) {
                item {
                    Text(
                        text = "जोड़ी गई फोटो सूची (${overlayPhotos.size}):",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                itemsIndexed(overlayPhotos) { idx, p ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "${idx + 1}.", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = p.label.ifBlank { p.file.name }, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "${FileUtil.formatDuration(p.startMs)} से ${FileUtil.formatDuration(p.endMs)} (अवधि: ${FileUtil.formatDurationHindi(p.endMs - p.startMs)})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            IconButton(onClick = { showTimeEditDialog = p }) {
                                Icon(Icons.Default.Edit, contentDescription = "${p.label} का समय बदलें")
                            }
                            IconButton(onClick = {
                                overlayPhotos = overlayPhotos.filter { it.id != p.id }
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "${p.label} हटाएँ", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }

                item {
                    RealProgressBarCard(
                        taskName = "वीडियो में फोटो जोड़ी जा रही है",
                        progressPercent = progress,
                        isProcessing = isProcessing
                    )
                }

                item {
                    AccessibleButton(
                        text = "वीडियो तैयार करें (MP4 सेव करें)",
                        icon = Icons.Default.CheckCircle,
                        onClick = {
                            viewModel.executeVideoOverlayPhotos(videoFile!!, overlayPhotos) { res ->
                                outputVideo = res
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isProcessing
                    )
                }

                if (outputVideo != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(text = "फोटो सहित वीडियो तैयार हो गया!", fontWeight = FontWeight.Bold)
                                Text(text = "फ़ाइल: ${outputVideo?.name}")
                                Text(text = "अवधि: ${FileUtil.formatDurationHindi(FileUtil.getMediaDuration(context, outputVideo!!))}")
                            }
                        }
                    }
                }
            }
        }
    }

    // Time edit dialog
    if (showTimeEditDialog != null) {
        val target = showTimeEditDialog!!
        val maxDur = if (videoFile != null) FileUtil.getMediaDuration(context, videoFile!!) else 3600000L
        var start by remember(target) { mutableLongStateOf(target.startMs) }
        var end by remember(target) { mutableLongStateOf(target.endMs) }
        var labelText by remember(target) { mutableStateOf(target.label) }

        AlertDialog(
            onDismissRequest = { showTimeEditDialog = null },
            title = { Text(text = "फोटो का समय निर्धारित करें", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = labelText,
                        onValueChange = { labelText = it },
                        label = { Text("फोटो का विवरण (उदा. चायवाला)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    AccurateTimePickerField(
                        title = "शुरुआत का समय (Start Time)",
                        currentMs = start,
                        maxMs = maxDur,
                        onTimeChange = { start = it }
                    )
                    AccurateTimePickerField(
                        title = "समाप्ति का समय (End Time)",
                        currentMs = end,
                        maxMs = maxDur,
                        onTimeChange = { end = it }
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val updated = overlayPhotos.map {
                        if (it.id == target.id) it.copy(startMs = start, endMs = maxOf(start + 1000L, end), label = labelText) else it
                    }
                    overlayPhotos = updated
                    showTimeEditDialog = null
                    HapticAndSoundUtil.announceForAccessibility(context, "समय सुरक्षित हुआ")
                }) {
                    Text("सहेजें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimeEditDialog = null }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}

/**
 * भाग 3: वीडियो में साउंड इफेक्ट जोड़ें (Dedicated Video SFX Tool)
 */
@Composable
fun VideoAddSfxToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val videoFile by viewModel.selectedVideoFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var chosenSfxFile by remember { mutableStateOf<File?>(null) }
    var sfxStartMs by remember { mutableLongStateOf(0L) }
    var sfxVolume by remember { mutableFloatStateOf(1.0f) }
    var isRepeatEnabled by remember { mutableStateOf(false) }
    var repeatUntilEnd by remember { mutableStateOf(false) }
    var repeatCount by remember { mutableIntStateOf(1) }
    var pauseMainVideo by remember { mutableStateOf(false) }
    var currentPlaybackMs by remember { mutableLongStateOf(0L) }
    var outputResult by remember { mutableStateOf<File?>(null) }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "SfxBaseVideo", "mp4")
            viewModel.selectedVideoFile.value = copied
        }
    }

    val sfxPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "PickedSfx", "wav")
            chosenSfxFile = copied
            HapticAndSoundUtil.announceForAccessibility(context, "साउंड इफेक्ट चुना गया: ${copied?.name}")
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "वीडियो में साउंड इफेक्ट जोड़ें",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "कहानी के दृश्य के अनुसार सही समय पर प्रभाव जोड़ें (उदा. 12:30 दरवाजा खुलना, 18:00 बारिश, 22:00 डरावनी ध्वनि)। वीडियो का मूल ऑडियो सुरक्षित रहेगा।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            AccessibleButton(
                text = if (videoFile != null) "वीडियो: ${videoFile?.name}" else "1. फोन से वीडियो चुनें",
                icon = Icons.Default.Movie,
                onClick = { videoPicker.launch("video/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (videoFile != null) {
            val totalDur = FileUtil.getMediaDuration(context, videoFile!!)

            item {
                VideoPlayerCard(
                    videoFile = videoFile,
                    title = "वीडियो चलाएँ और सही समय चुनें",
                    onPositionChanged = { pos -> currentPlaybackMs = pos }
                )
            }

            // Choose SFX
            item {
                AccessibleButton(
                    text = if (chosenSfxFile != null) "साउंड इफेक्ट: ${chosenSfxFile?.name}" else "2. फोन से साउंड इफेक्ट चुनें",
                    icon = Icons.Default.GraphicEq,
                    onClick = { sfxPicker.launch("audio/*") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Presets
            item {
                Text(
                    text = "या अंतर्निहित कहानी प्रभाव चुनें (Built-in Presets):",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            item {
                val sfxDir = File(context.filesDir, "sfx_presets")
                val presets = listOf(
                    "दरवाजा खुलना (Door Creak).wav",
                    "बारिश की आवाज़ (Rain Sound).wav",
                    "डरावनी ध्वनि (Horror Sound).wav",
                    "घंटी (Temple Bell).wav",
                    "नाटकीय प्रभाव (Whoosh).wav",
                    "तालियां (Applause).wav"
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    presets.chunked(2).forEach { row ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { presetName ->
                                val file = File(sfxDir, presetName)
                                OutlinedButton(
                                    onClick = {
                                        chosenSfxFile = file
                                        HapticAndSoundUtil.announceForAccessibility(context, "$presetName चुना गया")
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .semantics { contentDescription = "$presetName प्रभाव चुनें" }
                                ) {
                                    Text(presetName.substringBefore("."), fontSize = 12.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }

            if (chosenSfxFile != null) {
                item {
                    AudioPlayerCard(
                        audioFile = chosenSfxFile,
                        title = "साउंड इफेक्ट की जाँच करें"
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                sfxStartMs = currentPlaybackMs
                                HapticAndSoundUtil.announceForAccessibility(
                                    context,
                                    "साउंड इफेक्ट की शुरुआत वर्तमान समय ${FileUtil.formatDurationHindi(currentPlaybackMs)} पर सेट की गई"
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .defaultMinSize(minHeight = 48.dp)
                                .semantics { contentDescription = "वर्तमान प्लेबैक समय से SFX जोड़ें" }
                        ) {
                            Text("वर्तमान समय से जोड़ें")
                        }
                    }
                }

                item {
                    AccurateTimePickerField(
                        title = "साउंड इफेक्ट की शुरुआत का समय (Start Time)",
                        currentMs = sfxStartMs,
                        maxMs = totalDur,
                        onTimeChange = { sfxStartMs = it }
                    )
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(text = "साउंड इफेक्ट का वॉल्यूम: ${(sfxVolume * 100).toInt()}%", fontWeight = FontWeight.Bold)
                            Slider(
                                value = sfxVolume,
                                onValueChange = { sfxVolume = it },
                                valueRange = 0.1f..2.0f,
                                modifier = Modifier.semantics { contentDescription = "साउंड इफेक्ट वॉल्यूम: ${(sfxVolume * 100).toInt()} प्रतिशत" }
                            )
                        }
                    }
                }

                // Universal Repeat Section (Part 2)
                item {
                    RepeatControlSection(
                        mediaTitle = "इस साउंड इफेक्ट",
                        isRepeatEnabled = isRepeatEnabled,
                        onRepeatToggle = { isRepeatEnabled = it },
                        repeatUntilEnd = repeatUntilEnd,
                        onRepeatUntilEndChange = { repeatUntilEnd = it },
                        repeatCount = repeatCount,
                        onRepeatCountChange = { repeatCount = it }
                    )
                }

                // Video Freeze / Pause Option (Part 4.4)
                item {
                    val sfxDur = FileUtil.getMediaDuration(context, chosenSfxFile!!)
                    VideoFreezeOptionCard(
                        pauseMainVideo = pauseMainVideo,
                        onPauseMainVideoChange = { pauseMainVideo = it },
                        mainVideoDurationMs = totalDur,
                        addedContentDurationMs = sfxDur
                    )
                }

                item {
                    RealProgressBarCard(
                        taskName = "वीडियो में साउंड इफेक्ट मिक्स हो रहा है",
                        progressPercent = progress,
                        isProcessing = isProcessing
                    )
                }

                item {
                    AccessibleButton(
                        text = "साउंड इफेक्ट जोड़ें और वीडियो सेव करें",
                        icon = Icons.Default.Check,
                        onClick = {
                            viewModel.executeVideoAddSfx(videoFile!!, chosenSfxFile!!, sfxStartMs, sfxVolume) { res ->
                                outputResult = res
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isProcessing
                    )
                }

                if (outputResult != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(text = "साउंड इफेक्ट के साथ वीडियो सेव हुआ!", fontWeight = FontWeight.Bold)
                                Text(text = "फ़ाइल: ${outputResult?.name}")
                                Text(text = "अवधि: ${FileUtil.formatDurationHindi(FileUtil.getMediaDuration(context, outputResult!!))}")
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * भाग 5: म्यूजिक के साथ लाइव वीडियो रिकॉर्ड करें
 */
@Composable
fun VideoRecordWithMusicToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var musicFile by remember { mutableStateOf<File?>(null) }
    var recordedCameraVideo by remember { mutableStateOf<File?>(null) }
    var tempCameraFile by remember { mutableStateOf<File?>(null) }
    var musicVolume by remember { mutableFloatStateOf(0.4f) }
    var isRepeatEnabled by remember { mutableStateOf(true) }
    var repeatUntilEnd by remember { mutableStateOf(true) }
    var repeatCount by remember { mutableIntStateOf(1) }
    var finalResult by remember { mutableStateOf<File?>(null) }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo()) { success ->
        if (success && tempCameraFile != null && tempCameraFile!!.exists()) {
            recordedCameraVideo = tempCameraFile
            HapticAndSoundUtil.announceForAccessibility(context, "कैमरे से वीडियो रिकॉर्ड पूरा हुआ")
        }
    }

    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "LiveVideoMusic", "wav")
            musicFile = copied
            HapticAndSoundUtil.announceForAccessibility(context, "म्यूजिक चुना गया")
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "म्यूजिक के साथ वीडियो रिकॉर्ड करें",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "पहले बैकग्राउंड म्यूजिक चुनें, फिर कैमरा खोलकर वीडियो रिकॉर्ड करें। रिकॉर्डिंग के बाद म्यूजिक वीडियो में स्वतः मिक्स हो जाएगा।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            AccessibleButton(
                text = if (musicFile != null) "म्यूजिक: ${musicFile?.name}" else "1. फोन से बैकग्राउंड म्यूजिक चुनें",
                icon = Icons.Default.MusicNote,
                onClick = { musicPicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (musicFile == null) {
            item {
                val sfxDir = File(context.filesDir, "sfx_presets")
                val melody = File(sfxDir, "मधुर धुन (Ambient Melody).wav")
                OutlinedButton(
                    onClick = {
                        musicFile = melody
                        HapticAndSoundUtil.announceForAccessibility(context, "मधुर धुन प्रीसेट चुना गया")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .semantics { contentDescription = "मधुर धुन प्रीसेट म्यूजिक चुनें" }
                ) {
                    Text("मधुर धुन प्रीसेट म्यूजिक चुनें")
                }
            }
        } else {
            item {
                AudioPlayerCard(
                    audioFile = musicFile,
                    title = "म्यूजिक का पूर्वावलोकन (Preview)"
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "बैकग्राउंड म्यूजिक का वॉल्यूम: ${(musicVolume * 100).toInt()}%", fontWeight = FontWeight.SemiBold)
                        Slider(
                            value = musicVolume,
                            onValueChange = { musicVolume = it },
                            valueRange = 0.05f..1.0f,
                            modifier = Modifier.semantics { contentDescription = "म्यूजिक वॉल्यूम: ${(musicVolume * 100).toInt()} प्रतिशत" }
                        )
                    }
                }
            }

            // Universal Repeat Section (Part 2)
            item {
                RepeatControlSection(
                    mediaTitle = "इस बैकग्राउंड म्यूजिक",
                    isRepeatEnabled = isRepeatEnabled,
                    onRepeatToggle = { isRepeatEnabled = it },
                    repeatUntilEnd = repeatUntilEnd,
                    onRepeatUntilEndChange = { repeatUntilEnd = it },
                    repeatCount = repeatCount,
                    onRepeatCountChange = { repeatCount = it }
                )
            }

            item {
                AccessibleButton(
                    text = "2. कैमरा खोलें और वीडियो रिकॉर्ड करें",
                    icon = Icons.Default.Videocam,
                    onClick = {
                        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                        val file = File(FileUtil.getAppVideoDir(context), "CamRec_$timeStamp.mp4")
                        tempCameraFile = file
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                        cameraLauncher.launch(uri)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    containerColor = MaterialTheme.colorScheme.secondary
                )
            }

            if (recordedCameraVideo != null) {
                item {
                    VideoPlayerCard(
                        videoFile = recordedCameraVideo,
                        title = "रिकॉर्ड किए गए वीडियो की जाँच करें"
                    )
                }

                item {
                    RealProgressBarCard(
                        taskName = "म्यूजिक मिक्स करके अंतिम वीडियो बनाया जा रहा है",
                        progressPercent = progress,
                        isProcessing = isProcessing
                    )
                }

                item {
                    AccessibleButton(
                        text = "म्यूजिक मिलाकर अंतिम वीडियो सेव करें",
                        icon = Icons.Default.Save,
                        onClick = {
                            viewModel.executeVideoRecordWithMusic(recordedCameraVideo!!, musicFile!!, musicVolume) { res ->
                                finalResult = res
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isProcessing
                    )
                }

                if (finalResult != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(text = "तैयार वीडियो सेव हो गया!", fontWeight = FontWeight.Bold)
                                Text(text = "फ़ाइल: ${finalResult?.name}")
                                Text(text = "अवधि: ${FileUtil.formatDurationHindi(FileUtil.getMediaDuration(context, finalResult!!))}")
                            }
                        }
                    }
                }
            }
        }
    }
}
