package com.example.ui.components

import android.media.MediaPlayer
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.utils.FileUtil
import com.example.utils.HapticAndSoundUtil
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun AudioPlayerCard(
    audioFile: File?,
    title: String = "ऑडियो प्लेयर",
    modifier: Modifier = Modifier,
    onPositionChanged: ((Long) -> Unit)? = null
) {
    if (audioFile == null || !audioFile.exists()) return

    val context = LocalContext.current
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }

    // Init or reload MediaPlayer
    DisposableEffect(audioFile.absolutePath) {
        val player = MediaPlayer()
        try {
            player.setDataSource(audioFile.absolutePath)
            player.prepare()
            durationMs = player.duration.toLong()
            player.setOnCompletionListener {
                isPlaying = false
                currentPositionMs = 0L
                onPositionChanged?.invoke(0L)
                HapticAndSoundUtil.announceForAccessibility(context, "ऑडियो समाप्त हुआ")
            }
            mediaPlayer = player
        } catch (_: Exception) {
        }

        onDispose {
            try {
                player.stop()
                player.release()
            } catch (_: Exception) {}
            mediaPlayer = null
            isPlaying = false
        }
    }

    // Polling player position
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    val pos = it.currentPosition.toLong()
                    currentPositionMs = pos
                    onPositionChanged?.invoke(pos)
                }
            }
            delay(250)
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Audiotrack,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Time and Slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = FileUtil.formatDuration(currentPositionMs),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = FileUtil.formatDuration(durationMs),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Slider(
                value = if (durationMs > 0) currentPositionMs.toFloat() / durationMs else 0f,
                onValueChange = { frac ->
                    val targetMs = (frac * durationMs).toLong()
                    currentPositionMs = targetMs
                    mediaPlayer?.seekTo(targetMs.toInt())
                    onPositionChanged?.invoke(targetMs)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics {
                        contentDescription = "ऑडियो स्थिति: ${FileUtil.formatDurationHindi(currentPositionMs)}, कुल अवधि ${FileUtil.formatDurationHindi(durationMs)}"
                    }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Play / Pause Main Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val target = maxOf(0L, currentPositionMs - 10000L)
                        mediaPlayer?.seekTo(target.toInt())
                        currentPositionMs = target
                        onPositionChanged?.invoke(target)
                        HapticAndSoundUtil.announceForAccessibility(context, "10 सेकंड पीछे")
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .semantics { contentDescription = "10 सेकंड पीछे जाएँ" }
                ) {
                    Icon(
                        imageVector = Icons.Default.Replay10,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                FilledIconButton(
                    onClick = {
                        HapticAndSoundUtil.vibrate(context, 40)
                        mediaPlayer?.let { player ->
                            if (isPlaying) {
                                player.pause()
                                isPlaying = false
                                HapticAndSoundUtil.announceForAccessibility(context, "ऑडियो रुका (Pause)")
                            } else {
                                player.start()
                                isPlaying = true
                                HapticAndSoundUtil.announceForAccessibility(context, "ऑडियो चल रहा है (Play)")
                            }
                        }
                    },
                    modifier = Modifier
                        .size(60.dp)
                        .semantics {
                            contentDescription = if (isPlaying) "ऑडियो रोकें (Pause)" else "ऑडियो चलाएँ (Play)"
                        },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                IconButton(
                    onClick = {
                        val target = minOf(durationMs, currentPositionMs + 10000L)
                        mediaPlayer?.seekTo(target.toInt())
                        currentPositionMs = target
                        onPositionChanged?.invoke(target)
                        HapticAndSoundUtil.announceForAccessibility(context, "10 सेकंड आगे")
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .semantics { contentDescription = "10 सेकंड आगे जाएँ" }
                ) {
                    Icon(
                        imageVector = Icons.Default.Forward10,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Quick Seek Bar (5s, 10s, 1m, 5m)
            QuickSeekControls(
                currentMs = currentPositionMs,
                totalDurationMs = durationMs,
                onSeekTo = { seekMs ->
                    mediaPlayer?.seekTo(seekMs.toInt())
                    currentPositionMs = seekMs
                    onPositionChanged?.invoke(seekMs)
                }
            )
        }
    }
}
