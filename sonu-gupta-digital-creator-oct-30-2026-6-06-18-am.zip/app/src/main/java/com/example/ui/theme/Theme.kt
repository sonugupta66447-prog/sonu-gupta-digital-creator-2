package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = StudioPrimaryAmber,
    onPrimary = StudioOnPrimaryDark,
    primaryContainer = Color(0xFF2E1C0C),
    onPrimaryContainer = Color(0xFFFED7AA),
    secondary = StudioSecondaryCyan,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF164E63),
    onSecondaryContainer = Color(0xFFCFFAFE),
    background = StudioDarkBg,
    onBackground = Color(0xFFF1F5F9),
    surface = StudioSurfaceDark,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = StudioSurfaceVariantDark,
    onSurfaceVariant = Color(0xFFCBD5E1),
    error = StudioAccentRed,
    errorContainer = Color(0xFF450A0A),
    onErrorContainer = Color(0xFFFEE2E2)
)

private val LightColorScheme = lightColorScheme(
    primary = StudioPrimaryLight,
    onPrimary = StudioOnPrimaryLight,
    primaryContainer = Color(0xFFFEF3C7),
    onPrimaryContainer = Color(0xFF78350F),
    secondary = Color(0xFF0284C7),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF0369A1),
    background = StudioLightBg,
    onBackground = Color(0xFF0F172A),
    surface = StudioSurfaceLight,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = StudioSurfaceVariantLight,
    onSurfaceVariant = Color(0xFF334155),
    error = StudioAccentRed,
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = Color(0xFF991B1B)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep consistent high-contrast studio theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
