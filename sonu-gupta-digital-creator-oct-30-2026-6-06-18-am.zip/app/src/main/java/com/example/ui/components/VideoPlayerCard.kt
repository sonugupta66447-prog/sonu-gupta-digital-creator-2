package com.example.ui.components

import android.media.MediaPlayer
import android.net.Uri
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.utils.FileUtil
import com.example.utils.HapticAndSoundUtil
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun VideoPlayerCard(
    videoFile: File?,
    title: String = "वीडियो प्लेयर",
    modifier: Modifier = Modifier,
    onPositionChanged: ((Long) -> Unit)? = null
) {
    if (videoFile == null || !videoFile.exists()) return

    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var videoViewRef by remember { mutableStateOf<VideoView?>(null) }

    LaunchedEffect(videoFile.absolutePath) {
        val dur = FileUtil.getMediaDuration(context, videoFile)
        durationMs = dur
        currentPositionMs = 0L
        onPositionChanged?.invoke(0L)
    }

    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            videoViewRef?.let { vv ->
                if (vv.isPlaying) {
                    val pos = vv.currentPosition.toLong()
                    currentPositionMs = pos
                    onPositionChanged?.invoke(pos)
                }
            }
            delay(250)
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Videocam,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Video Preview Surface
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    factory = { ctx ->
                        VideoView(ctx).apply {
                            setVideoURI(Uri.fromFile(videoFile))
                            setOnPreparedListener { mp ->
                                durationMs = mp.duration.toLong()
                            }
                            setOnCompletionListener {
                                isPlaying = false
                                currentPositionMs = 0L
                                onPositionChanged?.invoke(0L)
                                HapticAndSoundUtil.announceForAccessibility(context, "वीडियो प्लेबैक समाप्त हुआ")
                            }
                            videoViewRef = this
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Time & Duration
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = FileUtil.formatDuration(currentPositionMs),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "${FileUtil.formatDuration(durationMs)} (${FileUtil.formatDurationHindi(durationMs)})",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Slider(
                value = if (durationMs > 0) currentPositionMs.toFloat() / durationMs else 0f,
                onValueChange = { frac ->
                    val targetMs = (frac * durationMs).toLong()
                    currentPositionMs = targetMs
                    videoViewRef?.seekTo(targetMs.toInt())
                    onPositionChanged?.invoke(targetMs)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics {
                        contentDescription = "वीडियो स्थिति: ${FileUtil.formatDurationHindi(currentPositionMs)}, कुल अवधि ${FileUtil.formatDurationHindi(durationMs)}"
                    }
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val target = maxOf(0L, currentPositionMs - 10000L)
                        videoViewRef?.seekTo(target.toInt())
                        currentPositionMs = target
                        onPositionChanged?.invoke(target)
                        HapticAndSoundUtil.announceForAccessibility(context, "10 सेकंड पीछे")
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .semantics { contentDescription = "10 सेकंड पीछे जाएँ" }
                ) {
                    Icon(
                        imageVector = Icons.Default.Replay10,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                FilledIconButton(
                    onClick = {
                        HapticAndSoundUtil.vibrate(context, 40)
                        videoViewRef?.let { vv ->
                            if (isPlaying) {
                                vv.pause()
                                isPlaying = false
                                HapticAndSoundUtil.announceForAccessibility(context, "वीडियो रोका गया")
                            } else {
                                vv.start()
                                isPlaying = true
                                HapticAndSoundUtil.announceForAccessibility(context, "वीडियो चल रहा है")
                            }
                        }
                    },
                    modifier = Modifier
                        .size(60.dp)
                        .semantics {
                            contentDescription = if (isPlaying) "वीडियो रोकें (Pause)" else "वीडियो चलाएँ (Play)"
                        },
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                IconButton(
                    onClick = {
                        val target = minOf(durationMs, currentPositionMs + 10000L)
                        videoViewRef?.seekTo(target.toInt())
                        currentPositionMs = target
                        onPositionChanged?.invoke(target)
                        HapticAndSoundUtil.announceForAccessibility(context, "10 सेकंड आगे")
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .semantics { contentDescription = "10 सेकंड आगे जाएँ" }
                ) {
                    Icon(
                        imageVector = Icons.Default.Forward10,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick seek buttons for TalkBack users
            QuickSeekControls(
                currentMs = currentPositionMs,
                totalDurationMs = durationMs,
                onSeekTo = { seekMs ->
                    videoViewRef?.seekTo(seekMs.toInt())
                    currentPositionMs = seekMs
                    onPositionChanged?.invoke(seekMs)
                }
            )
        }
    }
}
