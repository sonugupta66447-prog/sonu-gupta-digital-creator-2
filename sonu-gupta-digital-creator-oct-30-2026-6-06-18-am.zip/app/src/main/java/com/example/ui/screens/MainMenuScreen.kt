package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.utils.HapticAndSoundUtil
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MainViewModel

@Composable
fun MainMenuScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // App Studio Branding Banner
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics {
                        contentDescription = "सोनू गुप्ता डिजिटल क्रिएटर स्टूडियो में आपका स्वागत है। सम्पूर्ण ऑडियो एवं वीडियो निर्माण ऐप।"
                    }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_logo_1793274035821),
                        contentDescription = "सोनू गुप्ता डिजिटल क्रिएटर लोगो",
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = "सोनू गुप्ता डिजिटल क्रिएटर",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Sonu Gupta Digital Creator Studio",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "नेत्रहीन उपयोगकर्ताओं के लिए पूर्णतः सुलभ (TalkBack Ready)",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        // Section Title
        item {
            Text(
                text = "मुख्य कार्यक्षेत्र चुनें (Main Menu)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(start = 4.dp, top = 8.dp)
            )
        }

        // 1. Audio Editor
        item {
            MenuOptionCard(
                number = "1",
                title = "ऑडियो एडिटर (Audio Editor)",
                description = "रिकॉर्डर, कटिंग, म्यूजिक मिक्सिंग, ऑटो-डकिंग, इको, वॉइस इफेक्ट्स और वीडियो से ऑडियो निकालें",
                icon = Icons.Default.Mic,
                iconBg = Color(0xFFEF4444),
                onClick = {
                    HapticAndSoundUtil.announceForAccessibility(context, "ऑडियो एडिटर खोला गया")
                    viewModel.navigateTo(AppScreen.AudioEditorMenu)
                }
            )
        }

        // 2. Video Editor
        item {
            MenuOptionCard(
                number = "2",
                title = "वीडियो एडिटर (Video Editor)",
                description = "कैमरा रिकॉर्डिंग, स्क्रीन रिकॉर्डर, वीडियो कटिंग, फोटो से वीडियो और वीडियो में म्यूजिक जोड़ें",
                icon = Icons.Default.VideoCall,
                iconBg = Color(0xFF3B82F6),
                onClick = {
                    HapticAndSoundUtil.announceForAccessibility(context, "वीडियो एडिटर खोला गया")
                    viewModel.navigateTo(AppScreen.VideoEditorMenu)
                }
            )
        }

        // 3. New Project
        item {
            MenuOptionCard(
                number = "3",
                title = "नया प्रोजेक्ट (New Project)",
                description = "एक साथ कई फोटो, वीडियो क्लिप, अपनी आवाज, बैकग्राउंड म्यूजिक और साउंड इफेक्ट जोड़कर संपूर्ण प्रोजेक्ट बनाएँ",
                icon = Icons.Default.AddCircle,
                iconBg = Color(0xFF10B981),
                onClick = {
                    HapticAndSoundUtil.announceForAccessibility(context, "नया प्रोजेक्ट कार्यक्षेत्र खोला गया")
                    viewModel.createNewProject("नया प्रोजेक्ट ${System.currentTimeMillis() % 1000}")
                    viewModel.navigateTo(AppScreen.NewProjectWorkspace)
                }
            )
        }

        // 4. My Projects
        item {
            MenuOptionCard(
                number = "4",
                title = "मेरे प्रोजेक्ट (My Projects)",
                description = "सुरक्षित रखे गए संपादन योग्य प्रोजेक्ट्स देखें, दोबारा खोलें या पैकेज एक्सपोर्ट करें",
                icon = Icons.Default.FolderSpecial,
                iconBg = Color(0xFF8B5CF6),
                onClick = {
                    HapticAndSoundUtil.announceForAccessibility(context, "मेरे प्रोजेक्ट्स खोले गए")
                    viewModel.navigateTo(AppScreen.MyProjects)
                }
            )
        }

        // 5. Saved Files
        item {
            MenuOptionCard(
                number = "5",
                title = "सेव की गई फाइलें (Saved Files)",
                description = "तैयार ऑडियो एवं वीडियो फाइलें सुनें, चलाएँ, नाम बदलें और शेयर करें",
                icon = Icons.Default.LibraryMusic,
                iconBg = Color(0xFFF59E0B),
                onClick = {
                    HapticAndSoundUtil.announceForAccessibility(context, "सेव की गई फाइलें खोली गईं")
                    viewModel.navigateTo(AppScreen.SavedFiles)
                }
            )
        }

        // 6. Settings
        item {
            MenuOptionCard(
                number = "6",
                title = "सेटिंग (Settings)",
                description = "रिकॉर्डिंग बीप, कंपन (Haptics), ऑडियो गुणवत्ता और सुलभता प्राथमिकताएँ",
                icon = Icons.Default.Settings,
                iconBg = Color(0xFF64748B),
                onClick = {
                    HapticAndSoundUtil.announceForAccessibility(context, "सेटिंग खोली गई")
                    viewModel.navigateTo(AppScreen.Settings)
                }
            )
        }

        // 7. Help & Accessibility
        item {
            MenuOptionCard(
                number = "7",
                title = "सहायता और गाइड (Help)",
                description = "TalkBack का उपयोग, वॉल्यूम बटन रिकॉर्डिंग, लंबी फाइलों की प्रोसेसिंग और निर्माता मार्गदर्शिका",
                icon = Icons.Default.HelpOutline,
                iconBg = Color(0xFF06B6D4),
                onClick = {
                    HapticAndSoundUtil.announceForAccessibility(context, "सहायता मार्गदर्शिका खोली गई")
                    viewModel.navigateTo(AppScreen.HelpAccessibility)
                }
            )
        }
    }
}

@Composable
fun MenuOptionCard(
    number: String,
    title: String,
    description: String,
    icon: ImageVector,
    iconBg: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Card(
        modifier = modifier
            .fillMaxWidth()
            .defaultMinSize(minHeight = 76.dp)
            .clickable(
                onClick = {
                    HapticAndSoundUtil.vibrate(context, 30)
                    onClick()
                }
            )
            .semantics {
                this.contentDescription = "$number. $title. $description"
                this.role = Role.Button
            },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(iconBg.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconBg,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
