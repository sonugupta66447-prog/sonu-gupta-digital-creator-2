package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.utils.FileUtil
import com.example.utils.HapticAndSoundUtil
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MainViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VideoEditorMenuScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedVideo by viewModel.selectedVideoFile.collectAsStateWithLifecycle()

    // Camera Video Capture
    var tempCameraVideoFile by remember { mutableStateOf<File?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CaptureVideo()
    ) { success ->
        if (success && tempCameraVideoFile != null && tempCameraVideoFile!!.exists()) {
            viewModel.selectedVideoFile.value = tempCameraVideoFile
            HapticAndSoundUtil.announceForAccessibility(context, "कैमरे से वीडियो रिकॉर्ड होकर सुरक्षित हुआ")
        }
    }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "PickedVideo", "mp4")
            viewModel.selectedVideoFile.value = copied
            HapticAndSoundUtil.announceForAccessibility(context, "वीडियो फाइल चुनी गई")
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Active Selected Video
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (selectedVideo != null) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (selectedVideo != null) "वर्तमान सक्रिय वीडियो: ${selectedVideo?.name}" else "कोई वीडियो नहीं चुना गया है",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    if (selectedVideo != null) {
                        val dur = FileUtil.getMediaDuration(context, selectedVideo!!)
                        Text(
                            text = "अवधि: ${FileUtil.formatDuration(dur)} (${FileUtil.formatDurationHindi(dur)})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = "फ़ाइल आकार: ${FileUtil.formatFileSize(selectedVideo!!.length())}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AccessibleButton(
                            text = "फोन से वीडियो चुनें",
                            icon = Icons.Default.FolderOpen,
                            onClick = { videoPicker.launch("video/*") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "वीडियो टूल सूची (Video Tools)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
            )
        }

        // 1. Camera Video Record
        item {
            AudioToolItem(
                number = "1",
                title = "कैमरे से वीडियो रिकॉर्ड करें",
                desc = "फोन के मुख्य कैमरे से सीधे उच्च गुणवत्ता में वीडियो रिकॉर्ड करें",
                icon = Icons.Default.Videocam,
                onClick = {
                    val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                    val file = File(FileUtil.getAppVideoDir(context), "CameraVideo_$timeStamp.mp4")
                    tempCameraVideoFile = file
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                    cameraLauncher.launch(uri)
                }
            )
        }

        // 2. Video Record with Music
        item {
            AudioToolItem(
                number = "2",
                title = "म्यूजिक के साथ वीडियो रिकॉर्ड करें",
                desc = "बैकग्राउंड म्यूजिक चुनकर कैमरे से वीडियो रिकॉर्ड करें और दोनों को मिक्स करें",
                icon = Icons.Default.MusicVideo,
                onClick = { viewModel.navigateTo(AppScreen.VideoRecordWithMusicTool) }
            )
        }

        // 3. Screen Recorder
        item {
            AudioToolItem(
                number = "3",
                title = "स्क्रीन रिकॉर्डर (Screen Recorder)",
                desc = "फोन की स्क्रीन रिकॉर्ड करने की प्रणाली क्षमता",
                icon = Icons.Default.ScreenShare,
                onClick = {
                    HapticAndSoundUtil.announceForAccessibility(context, "Android स्क्रीन रिकॉर्डिंग सेवा का अनुरोध किया जा रहा है")
                    val mgr = context.getSystemService(android.content.Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
                    if (mgr != null) {
                        try {
                            val intent = mgr.createScreenCaptureIntent()
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            HapticAndSoundUtil.announceForAccessibility(context, "स्क्रीन रिकॉर्डिंग संवाद समर्थित नहीं है या सिस्टम द्वारा अवरुद्ध है")
                        }
                    }
                }
            )
        }

        // 4. Add Video File
        item {
            AudioToolItem(
                number = "4",
                title = "फोन से वीडियो जोड़ें",
                desc = "डिवाइस स्टोरेज से अपनी मनपसंद वीडियो फाइल चुनें",
                icon = Icons.Default.VideoLibrary,
                onClick = { videoPicker.launch("video/*") }
            )
        }

        // 5. Video Trim & Cut
        item {
            AudioToolItem(
                number = "5",
                title = "वीडियो काटें और जोड़ें (Video Trim)",
                desc = "वीडियो की सटीक शुरुआत और समाप्ति चुनकर अनावश्यक भाग हटाएँ",
                icon = Icons.Default.ContentCut,
                onClick = { viewModel.navigateTo(AppScreen.VideoTrimTool) }
            )
        }

        // 6. Video Clips Merger (Veo 3 / Multi-clip)
        item {
            AudioToolItem(
                number = "6",
                title = "वीडियो क्लिप जोड़कर वीडियो बनाएँ",
                desc = "Veo 3 या कैमरे के छोटे क्लिप्स जोड़ें, क्रम बदलें, प्रत्येक का वॉल्यूम नियंत्रित करें और BGM जोड़ें",
                icon = Icons.Default.VideoCall,
                onClick = { viewModel.navigateTo(AppScreen.VideoClipsMergeTool) }
            )
        }

        // 7. Add Music to Video
        item {
            AudioToolItem(
                number = "7",
                title = "वीडियो में म्यूजिक जोड़ें",
                desc = "वीडियो के साथ अपनी पसंद का बैकग्राउंड म्यूजिक या गाना मिक्स करें",
                icon = Icons.Default.LibraryMusic,
                onClick = { viewModel.navigateTo(AppScreen.VideoAddMusicTool) }
            )
        }

        // 8. Add SFX to Video (DEDICATED)
        item {
            AudioToolItem(
                number = "8",
                title = "वीडियो में साउंड इफेक्ट जोड़ें",
                desc = "दरवाजा खुलना, बारिश, हॉरर आदि प्रभाव सही समय बिंदु पर जोड़ें",
                icon = Icons.Default.GraphicEq,
                onClick = { viewModel.navigateTo(AppScreen.VideoAddSfxTool) }
            )
        }

        // 9. Video Volume Control
        item {
            AudioToolItem(
                number = "9",
                title = "वीडियो की मूल आवाज़ नियंत्रित करें",
                desc = "वीडियो की मूल आवाज़ को म्यूट (बंद) करें या वॉल्यूम बदलें",
                icon = Icons.Default.VolumeMute,
                onClick = { viewModel.navigateTo(AppScreen.VideoVolumeControlTool) }
            )
        }

        // 10. Photo Slideshow
        item {
            AudioToolItem(
                number = "10",
                title = "फोटो स्लाइड शो वीडियो बनाएँ (Photo Slideshow)",
                desc = "केवल तस्वीरों से स्लाइड शो तैयार करें, फोटो अवधि तय करें और बैकग्राउंड ऑडियो जोड़ें",
                icon = Icons.Default.AddPhotoAlternate,
                onClick = { viewModel.navigateTo(AppScreen.PhotosToVideoTool) }
            )
        }

        // 11. Audio to Video with Photos
        item {
            AudioToolItem(
                number = "11",
                title = "ऑडियो में फोटो लगाकर वीडियो बनाएँ",
                desc = "पूरी लंबी कहानी (उदा. 34 मिनट) की ऑडियो में सही समय बिंदुओं पर फोटो लगाएँ",
                icon = Icons.Default.PermMedia,
                onClick = { viewModel.navigateTo(AppScreen.AudioWithPhotosVideoTool) }
            )
        }

        // 12. Video Overlay Photos (DEDICATED)
        item {
            AudioToolItem(
                number = "12",
                title = "वीडियो में सही समय पर फोटो लगाएँ",
                desc = "पहले से रिकॉर्ड किए गए वीडियो के खास समय पर फोटो दिखाएँ, मूल ऑडियो सुरक्षित रहेगा",
                icon = Icons.Default.BurstMode,
                onClick = { viewModel.navigateTo(AppScreen.VideoOverlayPhotosTool) }
            )
        }

        // 13. Extract Audio
        item {
            AudioToolItem(
                number = "13",
                title = "वीडियो से ऑडियो निकालें",
                desc = "वीडियो फाइल से पूरा स्पष्ट ऑडियो ट्रैक अलग करें",
                icon = Icons.Default.Audiotrack,
                onClick = { viewModel.navigateTo(AppScreen.AudioExtractFromVideoTool) }
            )
        }

        // 14. Video Quality & Settings
        item {
            AudioToolItem(
                number = "14",
                title = "वीडियो की गुणवत्ता और सेव करने की सेटिंग",
                desc = "वीडियो रेजोल्यूशन (720p/1080p), फ्रेम दर और बिटरेट प्राथमिकताएँ",
                icon = Icons.Default.HighQuality,
                onClick = { viewModel.navigateTo(AppScreen.Settings) }
            )
        }

        // 15. My Video Projects
        item {
            AudioToolItem(
                number = "15",
                title = "मेरे वीडियो प्रोजेक्ट",
                desc = "सुरक्षित रखे गए संपादन योग्य वीडियो प्रोजेक्ट्स देखें और खोलें",
                icon = Icons.Default.FolderSpecial,
                onClick = { viewModel.navigateTo(AppScreen.MyProjects) }
            )
        }
    }
}

@Composable
fun VideoTrimToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val videoFile by viewModel.selectedVideoFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var startMs by remember { mutableLongStateOf(0L) }
    var totalDur by remember(videoFile) {
        mutableLongStateOf(if (videoFile != null) FileUtil.getMediaDuration(context, videoFile!!) else 0L)
    }
    var endMs by remember(totalDur) { mutableLongStateOf(totalDur) }
    var trimmedResult by remember { mutableStateOf<File?>(null) }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "ToTrimVideo", "mp4")
            viewModel.selectedVideoFile.value = copied
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            AccessibleButton(
                text = if (videoFile != null) "दूसरा वीडियो चुनें" else "फोन से वीडियो चुनें",
                icon = Icons.Default.FolderOpen,
                onClick = { videoPicker.launch("video/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (videoFile != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "मूल वीडियो: ${videoFile?.name}", fontWeight = FontWeight.Bold)
                        Text(text = "कुल अवधि: ${FileUtil.formatDurationHindi(totalDur)}")
                        Text(text = "फ़ाइल आकार: ${FileUtil.formatFileSize(videoFile!!.length())}")
                    }
                }
            }

            item {
                AccurateTimePickerField(
                    title = "कटिंग की शुरुआत (Start Time)",
                    currentMs = startMs,
                    maxMs = totalDur,
                    onTimeChange = { startMs = it }
                )
            }

            item {
                AccurateTimePickerField(
                    title = "कटिंग की समाप्ति (End Time)",
                    currentMs = endMs,
                    maxMs = totalDur,
                    onTimeChange = { endMs = it }
                )
            }

            item {
                RealProgressBarCard(
                    taskName = "वीडियो ट्रिमिंग जारी है",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            item {
                AccessibleButton(
                    text = "वीडियो काटें और सेव करें",
                    icon = Icons.Default.ContentCut,
                    onClick = {
                        viewModel.executeVideoTrim(startMs, endMs) { res ->
                            trimmedResult = res
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing && endMs > startMs
                )
            }

            if (trimmedResult != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "कटा हुआ नया वीडियो तैयार है!",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(text = "फाइल नाम: ${trimmedResult?.name}")
                            Text(text = "आकार: ${FileUtil.formatFileSize(trimmedResult!!.length())}")
                            Text(text = "अवधि: ${FileUtil.formatDurationHindi(FileUtil.getMediaDuration(context, trimmedResult!!))}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VideoAddMusicToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val videoFile by viewModel.selectedVideoFile.collectAsStateWithLifecycle()
    val audioFile by viewModel.selectedAudioFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()
    var isRepeatEnabled by remember { mutableStateOf(true) }
    var repeatUntilEnd by remember { mutableStateOf(true) }
    var repeatCount by remember { mutableIntStateOf(1) }
    var outputVideo by remember { mutableStateOf<File?>(null) }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "VideoForMusic", "mp4")
            viewModel.selectedVideoFile.value = copied
            HapticAndSoundUtil.announceForAccessibility(context, "वीडियो चुना गया: ${copied?.name}")
        }
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "MusicForVideo", "wav")
            viewModel.selectedAudioFile.value = copied
            HapticAndSoundUtil.announceForAccessibility(context, "म्यूजिक चुना गया: ${copied?.name}")
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "वीडियो में बैकग्राउंड म्यूजिक जोड़ें",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "वीडियो में बैकग्राउंड म्यूजिक जोड़ें। पूरी वीडियो तक म्यूजिक दोहराने (Loop) का विकल्प उपलब्ध है।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            AccessibleButton(
                text = if (videoFile != null) "1. वीडियो: ${videoFile?.name}" else "1. फोन से वीडियो चुनें",
                icon = Icons.Default.Movie,
                onClick = { videoPicker.launch("video/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            AccessibleButton(
                text = if (audioFile != null) "2. म्यूजिक: ${audioFile?.name}" else "2. फोन से म्यूजिक चुनें",
                icon = Icons.Default.MusicNote,
                onClick = { audioPicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (videoFile != null && audioFile != null) {
            item {
                AudioPlayerCard(
                    audioFile = audioFile,
                    title = "बैकग्राउंड म्यूजिक सुनें"
                )
            }

            // Universal Repeat Section (Part 2 & Part 4.3)
            item {
                RepeatControlSection(
                    mediaTitle = "इस म्यूजिक",
                    isRepeatEnabled = isRepeatEnabled,
                    onRepeatToggle = { isRepeatEnabled = it },
                    repeatUntilEnd = repeatUntilEnd,
                    onRepeatUntilEndChange = { repeatUntilEnd = it },
                    repeatCount = repeatCount,
                    onRepeatCountChange = { repeatCount = it }
                )
            }

            item {
                RealProgressBarCard(
                    taskName = "वीडियो में म्यूजिक जोड़ना",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            item {
                AccessibleButton(
                    text = "वीडियो में म्यूजिक जोड़ें और सेव करें",
                    icon = Icons.Default.LibraryAddCheck,
                    onClick = {
                        viewModel.executeAddMusicToVideo { res ->
                            outputVideo = res
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing
                )
            }

            if (outputVideo != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(text = "म्यूजिक युक्त वीडियो तैयार है!", fontWeight = FontWeight.Bold)
                            Text(text = "फाइल नाम: ${outputVideo?.name}")
                            Text(text = "स्थान: ${outputVideo?.absolutePath}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PhotosToVideoToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val photosList by viewModel.selectedPhotosList.collectAsStateWithLifecycle()
    val audioFile by viewModel.selectedAudioFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var photoSecs by remember { mutableIntStateOf(6) } // 6 sec per photo
    var generatedVideo by remember { mutableStateOf<File?>(null) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            val copiedList = mutableListOf<File>()
            uris.forEachIndexed { i, uri ->
                val f = FileUtil.copyUriToInternalFile(context, uri, "PhotoSlide_$i", "jpg")
                if (f != null) copiedList.add(f)
            }
            viewModel.selectedPhotosList.value = copiedList
            HapticAndSoundUtil.announceForAccessibility(context, "${copiedList.size} फोटो चुनी गईं")
        }
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "SlideshowAudio", "wav")
            viewModel.selectedAudioFile.value = copied
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "फोटो स्लाइड शो वीडियो बनाएँ",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "केवल तस्वीरों से सुंदर स्लाइड शो वीडियो तैयार करें, प्रत्येक फोटो की अवधि तय करें और बैकग्राउंड म्यूजिक या अपनी आवाज़ जोड़ें।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            AccessibleButton(
                text = if (photosList.isNotEmpty()) "${photosList.size} फोटो चुनी गईं (+ और जोड़ें)" else "+ फोन से फोटो चुनें",
                icon = Icons.Default.AddPhotoAlternate,
                onClick = { photoPicker.launch("image/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        itemsIndexed(photosList) { idx, photo ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "${idx + 1}.", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = photo.name, modifier = Modifier.weight(1f), maxLines = 1)

                    if (idx > 0) {
                        IconButton(onClick = {
                            val list = photosList.toMutableList()
                            val item = list.removeAt(idx)
                            list.add(idx - 1, item)
                            viewModel.selectedPhotosList.value = list
                        }) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = "${photo.name} ऊपर ले जाएँ")
                        }
                    }

                    if (idx < photosList.size - 1) {
                        IconButton(onClick = {
                            val list = photosList.toMutableList()
                            val item = list.removeAt(idx)
                            list.add(idx + 1, item)
                            viewModel.selectedPhotosList.value = list
                        }) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = "${photo.name} नीचे ले जाएँ")
                        }
                    }

                    IconButton(onClick = {
                        val list = photosList.toMutableList()
                        list.removeAt(idx)
                        viewModel.selectedPhotosList.value = list
                    }) {
                        Icon(Icons.Default.Delete, contentDescription = "${photo.name} हटाएँ", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }

        item {
            AccessibleButton(
                text = if (audioFile != null) "ऑडियो: ${audioFile?.name}" else "+ बैकग्राउंड ऑडियो/गाना जोड़ें",
                icon = Icons.Default.Audiotrack,
                onClick = { audioPicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (audioFile != null) {
            item {
                AudioPlayerCard(
                    audioFile = audioFile,
                    title = "बैकग्राउंड म्यूजिक सुनें"
                )
            }
        }

        if (photosList.isNotEmpty()) {
            item {
                Text(text = "प्रत्येक फोटो कितने सेकंड चले: $photoSecs सेकंड", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = photoSecs.toFloat(),
                    onValueChange = { photoSecs = it.toInt() },
                    valueRange = 2f..20f,
                    modifier = Modifier.semantics { contentDescription = "प्रत्येक फोटो की अवधि $photoSecs सेकंड" }
                )
                Text(
                    text = "अनुमानित कुल वीडियो अवधि: ${photosList.size * photoSecs} सेकंड",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "• फोटो पर रिपीट लागू नहीं होता है (फोटो अपनी निर्धारित अवधि तक ही दिखाई देती है)।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                RealProgressBarCard(
                    taskName = "फोटो से वीडियो तैयार हो रहा है",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            item {
                AccessibleButton(
                    text = "वीडियो बनाएँ और सुरक्षित करें",
                    icon = Icons.Default.MovieCreation,
                    onClick = {
                        viewModel.executePhotosToVideo(
                            photos = photosList,
                            audio = audioFile,
                            photoDurationMs = photoSecs * 1000L
                        ) { res ->
                            generatedVideo = res
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing
                )
            }

            if (generatedVideo != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(text = "तैयार वीडियो सेव हुआ!", fontWeight = FontWeight.Bold)
                            Text(text = "फाइल: ${generatedVideo?.name}")
                            Text(text = "आकार: ${FileUtil.formatFileSize(generatedVideo!!.length())}")
                        }
                    }
                }
            }
        }
    }
}
