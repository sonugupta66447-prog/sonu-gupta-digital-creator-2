package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.utils.AudioEngine
import com.example.utils.FileUtil
import com.example.utils.HapticAndSoundUtil
import com.example.viewmodel.MainViewModel
import java.io.File

@Composable
fun AudioMergeToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val filesList by viewModel.mergeAudioList.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()
    var mergedResult by remember { mutableStateOf<File?>(null) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "ToMerge", "wav")
            if (copied != null) {
                val current = filesList.toMutableList()
                current.add(copied)
                viewModel.mergeAudioList.value = current
                HapticAndSoundUtil.announceForAccessibility(context, "${copied.name} सूची में जोड़ा गया")
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "ऑडियो फाइलें जोड़ें (Merge Audios)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "कई ऑडियो फाइलें एक क्रम में जोड़ें। नीचे दी गई सूची से क्रम बदलें या हटाएँ।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            AccessibleButton(
                text = "+ सूची में ऑडियो जोड़ें",
                icon = Icons.Default.Add,
                onClick = { filePicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        itemsIndexed(filesList) { idx, file ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${idx + 1}.",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = file.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(
                            text = FileUtil.formatDurationHindi(FileUtil.getMediaDuration(context, file)),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    // Move Up
                    if (idx > 0) {
                        IconButton(
                            onClick = {
                                val list = filesList.toMutableList()
                                val item = list.removeAt(idx)
                                list.add(idx - 1, item)
                                viewModel.mergeAudioList.value = list
                                HapticAndSoundUtil.announceForAccessibility(context, "${file.name} ऊपर ले जाया गया")
                            },
                            modifier = Modifier.semantics { contentDescription = "${file.name} को ऊपर ले जाएँ" }
                        ) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = null)
                        }
                    }

                    // Move Down
                    if (idx < filesList.size - 1) {
                        IconButton(
                            onClick = {
                                val list = filesList.toMutableList()
                                val item = list.removeAt(idx)
                                list.add(idx + 1, item)
                                viewModel.mergeAudioList.value = list
                                HapticAndSoundUtil.announceForAccessibility(context, "${file.name} नीचे ले जाया गया")
                            },
                            modifier = Modifier.semantics { contentDescription = "${file.name} को नीचे ले जाएँ" }
                        ) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = null)
                        }
                    }

                    // Remove
                    IconButton(
                        onClick = {
                            val list = filesList.toMutableList()
                            list.removeAt(idx)
                            viewModel.mergeAudioList.value = list
                            HapticAndSoundUtil.announceForAccessibility(context, "${file.name} हटाया गया")
                        },
                        modifier = Modifier.semantics { contentDescription = "${file.name} सूची से हटाएँ" }
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }

        if (filesList.size >= 2) {
            item {
                RealProgressBarCard(
                    taskName = "ऑडियो जोड़ना जारी है",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            item {
                AccessibleButton(
                    text = "सभी ${filesList.size} ऑडियो जोड़ें और सेव करें",
                    icon = Icons.Default.CallMerge,
                    onClick = {
                        viewModel.executeAudioMerge(filesList) { res ->
                            mergedResult = res
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing
                )
            }

            if (mergedResult != null) {
                item {
                    AudioPlayerCard(
                        audioFile = mergedResult,
                        title = "जुड़ा हुआ ऑडियो सुनें"
                    )
                }
            }
        }
    }
}

@Composable
fun AudioSoundEffectsToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val mainAudio by viewModel.selectedAudioFile.collectAsStateWithLifecycle()
    val sfxFile by viewModel.secondaryAudioFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var offsetMs by remember { mutableLongStateOf(2000L) }
    var sfxVol by remember { mutableFloatStateOf(1.0f) }
    var isRepeatEnabled by remember { mutableStateOf(false) }
    var repeatUntilEnd by remember { mutableStateOf(false) }
    var repeatCount by remember { mutableIntStateOf(1) }
    var intervalSec by remember { mutableIntStateOf(1) }
    var resultFile by remember { mutableStateOf<File?>(null) }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "MainAudio", "wav")
            viewModel.selectedAudioFile.value = copied
        }
    }

    val sfxPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "CustomSFX", "wav")
            viewModel.secondaryAudioFile.value = copied
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "साउंड इफेक्ट जोड़ें (Sound Effects)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "कहानी या पॉडकास्ट के किसी खास समय पर घंटी, हवा, कदमों या अन्य ध्वनि जोड़ें।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            AccessibleButton(
                text = if (mainAudio != null) "मुख्य ऑडियो: ${mainAudio?.name}" else "1. मुख्य ऑडियो चुनें",
                icon = Icons.Default.Audiotrack,
                onClick = { audioPicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Built-in presets or choose file
        item {
            Text(
                text = "2. साउंड इफेक्ट चुनें (प्रीसेट या फ़ोन से):",
                fontWeight = FontWeight.SemiBold
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val sfxDir = File(context.filesDir, "sfx_presets")
                val bell = File(sfxDir, "घंटी (Temple Bell).wav")
                val whoosh = File(sfxDir, "नाटकीय प्रभाव (Whoosh).wav")

                OutlinedButton(
                    onClick = {
                        viewModel.secondaryAudioFile.value = bell
                        HapticAndSoundUtil.announceForAccessibility(context, "घंटी इफेक्ट चुना गया")
                    },
                    modifier = Modifier.weight(1f).semantics { contentDescription = "घंटी साउंड इफेक्ट चुनें" }
                ) {
                    Text("घंटी (Bell)")
                }

                OutlinedButton(
                    onClick = {
                        viewModel.secondaryAudioFile.value = whoosh
                        HapticAndSoundUtil.announceForAccessibility(context, "हुश इफेक्ट चुना गया")
                    },
                    modifier = Modifier.weight(1f).semantics { contentDescription = "नाटकीय हुश साउंड इफेक्ट चुनें" }
                ) {
                    Text("हुश (Whoosh)")
                }

                OutlinedButton(
                    onClick = { sfxPicker.launch("audio/*") },
                    modifier = Modifier.weight(1f).semantics { contentDescription = "फोन से कस्टम साउंड इफेक्ट चुनें" }
                ) {
                    Text("फ़ोन से...")
                }
            }
        }

        if (sfxFile != null) {
            item {
                Text(
                    text = "चयनित इफेक्ट: ${sfxFile?.name}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        if (mainAudio != null && sfxFile != null) {
            val totalDur = FileUtil.getMediaDuration(context, mainAudio!!)

            item {
                AccurateTimePickerField(
                    title = "इफेक्ट किस समय शुरू हो (Start Offset)",
                    currentMs = offsetMs,
                    maxMs = totalDur,
                    onTimeChange = { offsetMs = it }
                )
            }

            item {
                Text(text = "इफेक्ट का वॉल्यूम: ${(sfxVol * 100).toInt()}%", fontWeight = FontWeight.SemiBold)
                Slider(
                    value = sfxVol,
                    onValueChange = { sfxVol = it },
                    valueRange = 0.1f..1.5f,
                    modifier = Modifier.semantics { contentDescription = "इफेक्ट वॉल्यूम ${(sfxVol * 100).toInt()} प्रतिशत" }
                )
            }

            // Universal Repeat Section (Part 2)
            item {
                RepeatControlSection(
                    mediaTitle = "इस साउंड इफेक्ट",
                    isRepeatEnabled = isRepeatEnabled,
                    onRepeatToggle = { isRepeatEnabled = it },
                    repeatUntilEnd = repeatUntilEnd,
                    onRepeatUntilEndChange = { repeatUntilEnd = it },
                    repeatCount = repeatCount,
                    onRepeatCountChange = { repeatCount = it },
                    intervalSeconds = intervalSec,
                    onIntervalChange = { intervalSec = it }
                )
            }

            item {
                RealProgressBarCard(
                    taskName = "साउंड इफेक्ट मिक्सिंग",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            item {
                AccessibleButton(
                    text = "इफेक्ट जोड़ें और सेव करें",
                    icon = Icons.Default.CheckCircle,
                    onClick = {
                        viewModel.executeApplySoundEffect(
                            offsetMs = offsetMs,
                            durationMs = 0L,
                            sfxVolume = sfxVol,
                            repeatSfx = isRepeatEnabled,
                            repeatCount = repeatCount,
                            repeatUntilEnd = repeatUntilEnd,
                            repeatIntervalMs = intervalSec * 1000L
                        ) { res -> resultFile = res }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing
                )
            }

            if (resultFile != null) {
                item {
                    AudioPlayerCard(
                        audioFile = resultFile,
                        title = "इफेक्ट युक्त नया ऑडियो सुनें"
                    )
                }
            }
        }
    }
}

@Composable
fun AudioNoiseReductionToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val audioFile by viewModel.selectedAudioFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var sensitivity by remember { mutableFloatStateOf(600f) }
    var cleanedResult by remember { mutableStateOf<File?>(null) }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "ToCleanNoise", "wav")
            viewModel.selectedAudioFile.value = copied
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            AccessibleButton(
                text = if (audioFile != null) "ऑडियो: ${audioFile?.name}" else "फोन से ऑडियो चुनें",
                icon = Icons.Default.FolderOpen,
                onClick = { audioPicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (audioFile != null) {
            item {
                AudioPlayerCard(
                    audioFile = audioFile,
                    title = "मूल ऑडियो सुनें (Original)"
                )
            }

            item {
                Text(
                    text = "शोर हटाने की संवेदनशीलता (Threshold): ${sensitivity.toInt()}",
                    fontWeight = FontWeight.SemiBold
                )
                Slider(
                    value = sensitivity,
                    onValueChange = { sensitivity = it },
                    valueRange = 200f..2000f,
                    modifier = Modifier.semantics { contentDescription = "शोर संवेदनशीलता ${sensitivity.toInt()}" }
                )
            }

            item {
                RealProgressBarCard(
                    taskName = "शोर कम किया जा रहा है",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            item {
                AccessibleButton(
                    text = "शोर साफ़ करें और नया ऑडियो सेव करें",
                    icon = Icons.Default.CleaningServices,
                    onClick = {
                        viewModel.executeVoiceEffect(
                            effect = AudioEngine.VoiceEffect.NOISE_GATE,
                            intensity = 1.0f,
                            noiseThreshold = sensitivity
                        ) { res -> cleanedResult = res }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing
                )
            }

            if (cleanedResult != null) {
                item {
                    AudioPlayerCard(
                        audioFile = cleanedResult,
                        title = "साफ़ की गई आवाज़ सुनें (Cleaned)"
                    )
                }
            }
        }
    }
}

@Composable
fun AudioExtractFromVideoToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val videoFile by viewModel.selectedVideoFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()
    var extractedAudioResult by remember { mutableStateOf<File?>(null) }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "VideoToExtract", "mp4")
            viewModel.selectedVideoFile.value = copied
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "वीडियो से ऑडियो निकालें (Audio Extractor)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "अपने फोन से कोई भी वीडियो चुनें। ऐप उसकी पूरी ऑडियो स्ट्रीम निकालकर M4A/AAC फाइल के रूप में सेव करेगा।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            AccessibleButton(
                text = if (videoFile != null) "वीडियो: ${videoFile?.name}" else "फोन से वीडियो चुनें",
                icon = Icons.Default.VideoLibrary,
                onClick = { videoPicker.launch("video/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (videoFile != null) {
            val dur = FileUtil.getMediaDuration(context, videoFile!!)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "वीडियो: ${videoFile?.name}", fontWeight = FontWeight.Bold)
                        Text(text = "अवधि: ${FileUtil.formatDurationHindi(dur)}")
                        Text(text = "आकार: ${FileUtil.formatFileSize(videoFile!!.length())}")
                    }
                }
            }

            item {
                RealProgressBarCard(
                    taskName = "वीडियो से ऑडियो निकालना",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            item {
                AccessibleButton(
                    text = "पूरा ऑडियो निकालें और सेव करें",
                    icon = Icons.Default.Audiotrack,
                    onClick = {
                        viewModel.executeExtractAudioFromVideo { res ->
                            extractedAudioResult = res
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing
                )
            }

            if (extractedAudioResult != null) {
                item {
                    AudioPlayerCard(
                        audioFile = extractedAudioResult,
                        title = "निकाली गई ऑडियो सुनें"
                    )
                }
            }
        }
    }
}
