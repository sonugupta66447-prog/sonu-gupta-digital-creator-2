package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.utils.FileUtil
import com.example.utils.HapticAndSoundUtil
import com.example.viewmodel.MainViewModel
import java.io.File

@Composable
fun NewProjectScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val projectTitle by viewModel.currentProjectTitle.collectAsStateWithLifecycle()
    val clips by viewModel.currentProjectClips.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var showTitleDialog by remember { mutableStateOf(false) }
    var editedTitle by remember { mutableStateOf(projectTitle) }
    var exportedResult by remember { mutableStateOf<File?>(null) }

    // Media pickers
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        uris.forEachIndexed { idx, uri ->
            val f = FileUtil.copyUriToInternalFile(context, uri, "ProjectPhoto_$idx", "jpg")
            if (f != null) {
                viewModel.addClipToCurrentProject("PHOTO", f, "फोटो #${clips.size + 1}", 6000L)
            }
        }
        HapticAndSoundUtil.announceForAccessibility(context, "${uris.size} फोटो प्रोजेक्ट में जोड़ी गईं")
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val f = FileUtil.copyUriToInternalFile(context, uri, "ProjectAudio", "wav")
            if (f != null) {
                val dur = FileUtil.getMediaDuration(context, f)
                viewModel.addClipToCurrentProject("AUDIO_VOICE", f, f.name, if (dur > 0) dur else 10000L)
                HapticAndSoundUtil.announceForAccessibility(context, "ऑडियो प्रोजेक्ट में जुड़ा: ${f.name}")
            }
        }
    }

    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val f = FileUtil.copyUriToInternalFile(context, uri, "ProjectMusic", "wav")
            if (f != null) {
                val dur = FileUtil.getMediaDuration(context, f)
                viewModel.addClipToCurrentProject("AUDIO_MUSIC", f, "म्यूजिक: ${f.name}", if (dur > 0) dur else 30000L)
                HapticAndSoundUtil.announceForAccessibility(context, "म्यूजिक प्रोजेक्ट में जुड़ा")
            }
        }
    }

    val totalDurationMs = clips.filter { it.clipType == "PHOTO" }.sumOf { it.durationMs }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Project Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = projectTitle,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = {
                                editedTitle = projectTitle
                                showTitleDialog = true
                            },
                            modifier = Modifier.semantics { contentDescription = "प्रोजेक्ट का नाम बदलें" }
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "कुल मीडिया क्लिप: ${clips.size} | कुल अवधि: ${FileUtil.formatDurationHindi(totalDurationMs)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                    )
                }
            }
        }

        // Add Media Section
        item {
            Text(
                text = "प्रोजेक्ट में मीडिया जोड़ें:",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { photoPicker.launch("image/*") },
                    modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).semantics { contentDescription = "+ फोटो जोड़ें" }
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("फोटो")
                }

                OutlinedButton(
                    onClick = { audioPicker.launch("audio/*") },
                    modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).semantics { contentDescription = "+ आवाज़ या ऑडियो जोड़ें" }
                ) {
                    Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("आवाज़")
                }

                OutlinedButton(
                    onClick = { musicPicker.launch("audio/*") },
                    modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).semantics { contentDescription = "+ बैकग्राउंड म्यूजिक जोड़ें" }
                ) {
                    Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("म्यूजिक")
                }
            }
        }

        // Clips List
        if (clips.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Box(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "अभी प्रोजेक्ट खाली है। ऊपर दिए गए बटनों से फोटो या ऑडियो जोड़ें।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            item {
                Text(
                    text = "टाइमलाइन क्लिप्स सूची (TalkBack सुलभ क्रम नियंत्रण):",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )
            }

            itemsIndexed(clips) { idx, clip ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (clip.clipType) {
                                            "PHOTO" -> Color(0xFF3B82F6)
                                            "AUDIO_VOICE" -> Color(0xFFEF4444)
                                            "AUDIO_MUSIC" -> Color(0xFF10B981)
                                            else -> Color(0xFF8B5CF6)
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${idx + 1}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = clip.title,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "प्रकार: ${clip.clipType} | अवधि: ${clip.durationMs / 1000}s (${FileUtil.formatDurationHindi(clip.durationMs)})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // Move Up
                            if (idx > 0) {
                                IconButton(
                                    onClick = {
                                        viewModel.moveClip(idx, -1)
                                        HapticAndSoundUtil.announceForAccessibility(context, "${clip.title} ऊपर ले जाया गया")
                                    },
                                    modifier = Modifier.semantics { contentDescription = "${clip.title} को ऊपर ले जाएँ" }
                                ) {
                                    Icon(Icons.Default.ArrowUpward, contentDescription = null)
                                }
                            }

                            // Move Down
                            if (idx < clips.size - 1) {
                                IconButton(
                                    onClick = {
                                        viewModel.moveClip(idx, 1)
                                        HapticAndSoundUtil.announceForAccessibility(context, "${clip.title} नीचे ले जाया गया")
                                    },
                                    modifier = Modifier.semantics { contentDescription = "${clip.title} को नीचे ले जाएँ" }
                                ) {
                                    Icon(Icons.Default.ArrowDownward, contentDescription = null)
                                }
                            }

                            // Delete
                            IconButton(
                                onClick = {
                                    viewModel.removeClip(idx)
                                    HapticAndSoundUtil.announceForAccessibility(context, "${clip.title} हटाया गया")
                                },
                                modifier = Modifier.semantics { contentDescription = "${clip.title} प्रोजेक्ट से हटाएँ" }
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            }
                        }

                        // Duration Slider for photos
                        if (clip.clipType == "PHOTO") {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = "अवधि: ${clip.durationMs / 1000}s", style = MaterialTheme.typography.bodySmall)
                                Slider(
                                    value = (clip.durationMs / 1000).toFloat(),
                                    onValueChange = { s -> viewModel.updateClipDuration(idx, s.toLong() * 1000L) },
                                    valueRange = 2f..20f,
                                    modifier = Modifier.weight(1f).semantics { contentDescription = "${clip.title} की अवधि ${clip.durationMs / 1000} सेकंड" }
                                )
                            }
                        }
                    }
                }
            }

            item {
                RealProgressBarCard(
                    taskName = "प्रोजेक्ट एक्सपोर्ट जारी है",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            // Export Actions
            item {
                AccessibleButton(
                    text = "संपूर्ण प्रोजेक्ट एक्सपोर्ट करें (तैयार वीडियो सेव करें)",
                    icon = Icons.Default.SaveAlt,
                    onClick = {
                        viewModel.exportCurrentProjectAsMedia { res ->
                            exportedResult = res
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing && clips.isNotEmpty()
                )
            }

            if (exportedResult != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(text = "प्रोजेक्ट सफलतापूर्वक एक्सपोर्ट हुआ!", fontWeight = FontWeight.Bold)
                            Text(text = "फ़ाइल: ${exportedResult?.name}")
                            Text(text = "आकार: ${FileUtil.formatFileSize(exportedResult!!.length())}")
                        }
                    }
                }
            }
        }
    }

    if (showTitleDialog) {
        AlertDialog(
            onDismissRequest = { showTitleDialog = false },
            title = { Text("प्रोजेक्ट का नाम बदलें") },
            text = {
                OutlinedTextField(
                    value = editedTitle,
                    onValueChange = { editedTitle = it },
                    label = { Text("नया नाम दर्ज करें") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.currentProjectTitle.value = editedTitle
                        showTitleDialog = false
                    }
                ) {
                    Text("सेव करें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTitleDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}
