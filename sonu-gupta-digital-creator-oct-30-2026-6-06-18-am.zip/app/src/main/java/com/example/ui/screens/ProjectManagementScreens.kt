package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ProjectEntity
import com.example.data.model.SavedFileEntity
import com.example.ui.components.AccessibleButton
import com.example.ui.components.AudioPlayerCard
import com.example.utils.FileUtil
import com.example.utils.HapticAndSoundUtil
import com.example.viewmodel.MainViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MyProjectsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val projects by viewModel.allProjects.collectAsStateWithLifecycle(initialValue = emptyList())

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "मेरे प्रोजेक्ट (My Projects)",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "सुरक्षित रखे गए संपादन योग्य प्रोजेक्ट्स। किसी भी प्रोजेक्ट पर क्लिक करके उसे दोबारा खोलें।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (projects.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Box(modifier = Modifier.padding(32.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "अभी कोई सहेजा गया प्रोजेक्ट नहीं है। मुख्य मेनू से 'नया प्रोजेक्ट' चुनें।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(projects) { project ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            HapticAndSoundUtil.announceForAccessibility(context, "${project.title} प्रोजेक्ट खोला गया")
                            viewModel.loadProject(project)
                        }
                        .semantics {
                            contentDescription = "${project.title}, प्रकार ${project.projectType}, कुल अवधि ${FileUtil.formatDurationHindi(project.totalDurationMs)}। खोलने के लिए दो बार टैप करें।"
                            role = Role.Button
                        },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Folder,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = project.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            val dateStr = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(project.updatedAt))
                            Text(
                                text = "संशोधित: $dateStr | अवधि: ${FileUtil.formatDuration(project.totalDurationMs)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        IconButton(
                            onClick = {
                                viewModel.deleteProject(project)
                                HapticAndSoundUtil.announceForAccessibility(context, "${project.title} हटाया गया")
                            },
                            modifier = Modifier.semantics { contentDescription = "${project.title} प्रोजेक्ट हटाएँ" }
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SavedFilesScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val savedFiles by viewModel.allSavedFiles.collectAsStateWithLifecycle(initialValue = emptyList())
    var activePlayingFile by remember { mutableStateOf<File?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "सेव की गई फाइलें (Saved Files)",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "आपके द्वारा तैयार की गई सभी वास्तविक ऑडियो और वीडियो फाइलें। यहाँ से सुनें और शेयर करें।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Active Player Card
        if (activePlayingFile != null && activePlayingFile!!.exists()) {
            item {
                AudioPlayerCard(
                    audioFile = activePlayingFile,
                    title = "सुनें: ${activePlayingFile?.name}"
                )
            }
        }

        if (savedFiles.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Box(modifier = Modifier.padding(32.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "अभी कोई तैयार फाइल उपलब्ध नहीं है। कोई भी ऑडियो रिकॉर्ड या एडिट करके सेव करें।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(savedFiles) { item ->
                val f = File(item.filePath)
                val exists = f.exists()

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (item.mediaType == "VIDEO") Icons.Default.Movie else Icons.Default.Audiotrack,
                                contentDescription = null,
                                tint = if (item.mediaType == "VIDEO") Color(0xFF3B82F6) else Color(0xFFEF4444)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.fileName,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "प्रारूप: ${item.format} | आकार: ${FileUtil.formatFileSize(item.fileSizeBytes)} | अवधि: ${FileUtil.formatDurationHindi(item.durationMs)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (exists) {
                                // Play Button
                                TextButton(
                                    onClick = {
                                        activePlayingFile = f
                                        HapticAndSoundUtil.announceForAccessibility(context, "${item.fileName} चलाया जा रहा है")
                                    },
                                    modifier = Modifier.semantics { contentDescription = "${item.fileName} को चलाएँ" }
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("चलाएँ")
                                }

                                // Share Button
                                TextButton(
                                    onClick = {
                                        try {
                                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = if (item.mediaType == "VIDEO") "video/*" else "audio/*"
                                                putExtra(Intent.EXTRA_STREAM, uri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "फाइल शेयर करें"))
                                        } catch (e: Exception) {
                                            HapticAndSoundUtil.announceForAccessibility(context, "शेयर करने में समस्या आई")
                                        }
                                    },
                                    modifier = Modifier.semantics { contentDescription = "${item.fileName} अन्य ऐप्स में शेयर करें" }
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("शेयर")
                                }
                            }

                            // Delete
                            IconButton(
                                onClick = {
                                    viewModel.deleteSavedFile(item)
                                    if (activePlayingFile?.absolutePath == f.absolutePath) {
                                        activePlayingFile = null
                                    }
                                    HapticAndSoundUtil.announceForAccessibility(context, "${item.fileName} हटा दी गई")
                                },
                                modifier = Modifier.semantics { contentDescription = "${item.fileName} हटाएँ" }
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val beepEnabled by viewModel.beepOnRecordEnabled.collectAsStateWithLifecycle()
    val hapticEnabled by viewModel.hapticEnabled.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "सेटिंग (Settings & Preferences)",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "रिकॉर्डिंग बीप संकेत (Start/Stop Beep)", fontWeight = FontWeight.Bold)
                            Text(
                                text = "रिकॉर्डिंग शुरू होने पर उच्च स्वर बीप और रुकने पर निम्न स्वर बीप",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = beepEnabled,
                            onCheckedChange = {
                                viewModel.beepOnRecordEnabled.value = it
                                HapticAndSoundUtil.announceForAccessibility(context, if (it) "बीप संकेत चालू" else "बीप संकेत बंद")
                            },
                            modifier = Modifier.semantics { contentDescription = "रिकॉर्डिंग बीप संकेत" }
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "स्पर्श कंपन (Haptic Feedback)", fontWeight = FontWeight.Bold)
                            Text(
                                text = "बटन दबाने और कार्य संपन्न होने पर हल्का कंपन",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = hapticEnabled,
                            onCheckedChange = {
                                viewModel.hapticEnabled.value = it
                                HapticAndSoundUtil.announceForAccessibility(context, if (it) "कंपन चालू" else "कंपन बंद")
                            },
                            modifier = Modifier.semantics { contentDescription = "स्पर्श कंपन प्रतिक्रिया" }
                        )
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "तकनीकी विनिर्देश (Audio Specifications)", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("• प्रारूप: Uncompressed WAV PCM 16-Bit Studio")
                    Text("• नमूना दर (Sample Rate): 44.1 kHz (CD Studio Quality)")
                    Text("• चैनल: Mono (कहानी, पॉडकास्ट एवं स्पष्ट आवाज़ हेतु आदर्श)")
                    Text("• स्थानीय फोन प्रोसेसिंग: 100% ऑन-डिवाइस, सुरक्षित एवं बिना इंटरनेट")
                }
            }
        }
    }
}

@Composable
fun HelpAccessibilityScreen(
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "सोनू गुप्ता डिजिटल क्रिएटर - सहायता एवं सुलभता गाइड",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        item {
            HelpCard(
                title = "1. नेत्रहीन उपयोगकर्ताओं और TalkBack के लिए सुलभता",
                content = "इस ऐप का प्रत्येक बटन, स्लाइडर और नियंत्रण TalkBack के साथ पूर्णतः संगत है। बटन पर नाम, वर्तमान स्थिति और परिणाम स्पष्ट रूप से बोले जाते हैं। टाइमलाइन स्लाइडर के अलावा 5s, 10s, 1m, 5m के निश्चित बटन और मिनट/सेकंड मैन्युअल इनपुट उपलब्ध हैं ताकि आपको स्लाइडर खींचने की परेशानी न हो।"
            )
        }

        item {
            HelpCard(
                title = "2. रिकॉर्डिंग और बीप संकेत",
                content = "रिकॉर्डिंग शुरू करते ही 1050Hz का स्पष्ट बीप बजेगा और समाप्त होने पर 620Hz का स्टॉप बीप बजेगा। इससे आप बिना स्क्रीन देखे भी समझ सकेंगे कि रिकॉर्डिंग कब शुरू और कब बंद हुई।"
            )
        }

        item {
            HelpCard(
                title = "3. बोलते समय बैकग्राउंड म्यूजिक कम करना (Auto-Ducking)",
                content = "यदि आप कहानी या पॉडकास्ट बना रहे हैं, तो 'बोलते समय बैकग्राउंड म्यूजिक की आवाज़ कम करें' टूल का उपयोग करें। जैसे ही आपकी आवाज़ शुरू होगी, बैकग्राउंड म्यूजिक धीमा हो जाएगा और आपके चुप होते ही मधुरता से वापस आ जाएगा।"
            )
        }

        item {
            HelpCard(
                title = "4. लंबी फाइलों की स्थानीय प्रोसेसिंग",
                content = "यह ऐप 20 मिनट, 30 मिनट, 45 मिनट या उससे भी लंबी फाइलों को बिना किसी मनमानी कटौती के सुरक्षित रूप से फोन पर ही प्रोसेस करता है। वास्तविक प्रतिशत प्रगति दिखाई और सुनाई देती है।"
            )
        }

        item {
            HelpCard(
                title = "5. सुरक्षित प्रोजेक्ट और एक्सपोर्ट",
                content = "आपके बनाए गए सभी प्रोजेक्ट स्थानीय डेटाबेस में सुरक्षित रहते हैं। आप जब चाहें उन्हें दोबारा खोल सकते हैं, क्रम बदल सकते हैं या नई क्लिप्स जोड़ सकते हैं।"
            )
        }
    }
}

@Composable
fun HelpCard(title: String, content: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = content, style = MaterialTheme.typography.bodyMedium, lineHeight = 20.sp)
        }
    }
}
