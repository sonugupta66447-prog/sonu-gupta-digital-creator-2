package com.example.ui.screens

import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.utils.AudioEngine
import com.example.utils.FileUtil
import com.example.utils.HapticAndSoundUtil
import com.example.viewmodel.MainViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * टूल: म्यूजिक के साथ ऑडियो रिकॉर्ड करें (Live Audio Recording with Music)
 */
@Composable
fun AudioRecordWithMusicToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isRecording by viewModel.isRecording.collectAsStateWithLifecycle()
    val isPaused by viewModel.isRecordingPaused.collectAsStateWithLifecycle()
    val durationMs by viewModel.recordDurationMs.collectAsStateWithLifecycle()
    val musicFile by viewModel.liveRecordMusic.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var voiceVol by remember { mutableFloatStateOf(1.0f) }
    var musicVol by remember { mutableFloatStateOf(0.4f) }
    var isRepeatEnabled by remember { mutableStateOf(true) }
    var repeatUntilEnd by remember { mutableStateOf(true) }
    var repeatCount by remember { mutableIntStateOf(1) }
    var mixedResult by remember { mutableStateOf<File?>(null) }
    var musicPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "LiveRecMusic", "wav")
            viewModel.liveRecordMusic.value = copied
            HapticAndSoundUtil.announceForAccessibility(context, "बैकग्राउंड म्यूजिक चुना गया: ${copied?.name}")
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                musicPlayer?.stop()
                musicPlayer?.release()
            } catch (_: Exception) {}
            musicPlayer = null
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "म्यूजिक के साथ ऑडियो रिकॉर्ड करें",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "पहले बैकग्राउंड म्यूजिक चुनें, फिर रिकॉर्डिंग शुरू करें और म्यूजिक के साथ अपनी आवाज़ रिकॉर्ड करें।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Music selection
        item {
            AccessibleButton(
                text = if (musicFile != null) "म्यूजिक: ${musicFile?.name}" else "1. फोन से बैकग्राउंड म्यूजिक चुनें",
                icon = Icons.Default.MusicNote,
                onClick = { musicPicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Preset options if no file chosen
        if (musicFile == null) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val sfxDir = File(context.filesDir, "sfx_presets")
                    val melody = File(sfxDir, "मधुर धुन (Ambient Melody).wav")
                    OutlinedButton(
                        onClick = {
                            viewModel.liveRecordMusic.value = melody
                            HapticAndSoundUtil.announceForAccessibility(context, "मधुर धुन प्रीसेट चुना गया")
                        },
                        modifier = Modifier.weight(1f).semantics { contentDescription = "मधुर धुन प्रीसेट म्यूजिक चुनें" }
                    ) {
                        Text("मधुर धुन प्रीसेट")
                    }
                }
            }
        } else {
            item {
                AudioPlayerCard(
                    audioFile = musicFile,
                    title = "म्यूजिक की जाँच करें (Preview)"
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "मुख्य आवाज़ का वॉल्यूम: ${(voiceVol * 100).toInt()}%", fontWeight = FontWeight.SemiBold)
                        Slider(
                            value = voiceVol,
                            onValueChange = { voiceVol = it },
                            valueRange = 0.2f..2.0f,
                            modifier = Modifier.semantics { contentDescription = "मुख्य आवाज़ वॉल्यूम: ${(voiceVol * 100).toInt()} प्रतिशत" }
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(text = "बैकग्राउंड म्यूजिक का वॉल्यूम: ${(musicVol * 100).toInt()}%", fontWeight = FontWeight.SemiBold)
                        Slider(
                            value = musicVol,
                            onValueChange = { musicVol = it },
                            valueRange = 0.05f..1.2f,
                            modifier = Modifier.semantics { contentDescription = "म्यूजिक वॉल्यूम: ${(musicVol * 100).toInt()} प्रतिशत" }
                        )
                    }
                }
            }

            // Universal Repeat Section (Part 2)
            item {
                RepeatControlSection(
                    mediaTitle = "इस बैकग्राउंड म्यूजिक",
                    isRepeatEnabled = isRepeatEnabled,
                    onRepeatToggle = { isRepeatEnabled = it },
                    repeatUntilEnd = repeatUntilEnd,
                    onRepeatUntilEndChange = { repeatUntilEnd = it },
                    repeatCount = repeatCount,
                    onRepeatCountChange = { repeatCount = it }
                )
            }

            // Recording Controls
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isRecording) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = FileUtil.formatDuration(durationMs),
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isRecording) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = if (isRecording) "लाइव रिकॉर्डिंग + म्यूजिक चालू है" else "रिकॉर्डिंग के लिए तैयार",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (!isRecording) {
                        AccessibleButton(
                            text = "म्यूजिक के साथ रिकॉर्ड करें",
                            icon = Icons.Default.FiberManualRecord,
                            onClick = {
                                try {
                                    musicPlayer?.release()
                                    musicPlayer = MediaPlayer().apply {
                                        setDataSource(musicFile!!.absolutePath)
                                        isLooping = isRepeatEnabled
                                        prepare()
                                        start()
                                    }
                                } catch (_: Exception) {}
                                viewModel.startAudioRecording()
                            },
                            containerColor = Color(0xFFEF4444),
                            contentColor = Color.White,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        AccessibleButton(
                            text = "रोकें और मिक्स करें (Stop)",
                            icon = Icons.Default.Stop,
                            onClick = {
                                try {
                                    musicPlayer?.stop()
                                    musicPlayer?.release()
                                } catch (_: Exception) {}
                                musicPlayer = null
                                viewModel.stopAudioRecording()

                                viewModel.activeRecordedFile.value?.let { voiceRecorded ->
                                    viewModel.executeLiveRecordWithMusicMix(
                                        recordedVoice = voiceRecorded,
                                        musicFile = musicFile!!,
                                        voiceVol = voiceVol,
                                        musicVol = musicVol
                                    ) { res ->
                                        mixedResult = res
                                    }
                                }
                            },
                            containerColor = Color(0xFFEF4444),
                            contentColor = Color.White,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            item {
                RealProgressBarCard(
                    taskName = "म्यूजिक और आवाज़ मिक्सिंग",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            if (mixedResult != null) {
                item {
                    AudioPlayerCard(
                        audioFile = mixedResult,
                        title = "तैयार रिकॉर्डिंग सुनें (Mixed Output)"
                    )
                }
            }
        }
    }
}

/**
 * टूल: ऑडियो का वॉल्यूम नियंत्रित करें (Gain Control)
 */
@Composable
fun AudioGainControlToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val audioFile by viewModel.selectedAudioFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var volumeFactor by remember { mutableFloatStateOf(1.0f) }
    var adjustedResult by remember { mutableStateOf<File?>(null) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "ToVolume", "wav")
            viewModel.selectedAudioFile.value = copied
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            AccessibleButton(
                text = if (audioFile != null) "ऑडियो: ${audioFile?.name}" else "फोन से ऑडियो चुनें",
                icon = Icons.Default.FolderOpen,
                onClick = { filePicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (audioFile != null) {
            item {
                AudioPlayerCard(
                    audioFile = audioFile,
                    title = "मूल ऑडियो (${audioFile?.name})"
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "नया वॉल्यूम स्तर: ${(volumeFactor * 100).toInt()}%",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Slider(
                            value = volumeFactor,
                            onValueChange = { volumeFactor = it },
                            valueRange = 0.1f..2.5f,
                            modifier = Modifier.semantics { contentDescription = "वॉल्यूम स्तर: ${(volumeFactor * 100).toInt()} प्रतिशत" }
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("10% (धीमा)", style = MaterialTheme.typography.bodySmall)
                            Text("100% (सामान्य)", style = MaterialTheme.typography.bodySmall)
                            Text("250% (तेज बूस्ट)", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            item {
                RealProgressBarCard(
                    taskName = "वॉल्यूम परिवर्तन जारी है",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            item {
                AccessibleButton(
                    text = "वॉल्यूम बदलें और नया ऑडियो सेव करें",
                    icon = Icons.Default.VolumeUp,
                    onClick = {
                        viewModel.executeAudioGainControl(volumeFactor) { res ->
                            adjustedResult = res
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing
                )
            }

            if (adjustedResult != null) {
                item {
                    AudioPlayerCard(
                        audioFile = adjustedResult,
                        title = "संशोधित वॉल्यूम वाला ऑडियो सुनें"
                    )
                }
            }
        }
    }
}

/**
 * टूल: ऑडियो की शुरुआत, बीच या अंत काटें (Middle Cut Tool)
 */
@Composable
fun AudioTrimStartEndToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val audioFile by viewModel.selectedAudioFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var cutStartMs by remember { mutableLongStateOf(0L) }
    var totalDur by remember(audioFile) {
        mutableLongStateOf(if (audioFile != null) FileUtil.getMediaDuration(context, audioFile!!) else 0L)
    }
    var cutEndMs by remember(totalDur) { mutableLongStateOf(minOf(totalDur, 10000L)) }
    var cutResult by remember { mutableStateOf<File?>(null) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "ToCutMiddle", "wav")
            viewModel.selectedAudioFile.value = copied
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "ऑडियो की शुरुआत, बीच या अंत काटें",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "ऑडियो के बीच का कोई अनावश्यक हिस्सा (खांसी, रुकावट या गलती) हटाएँ। बाकी दोनों हिस्से जुड़ जाएँगे।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            AccessibleButton(
                text = if (audioFile != null) "ऑडियो: ${audioFile?.name}" else "फोन से ऑडियो चुनें",
                icon = Icons.Default.FolderOpen,
                onClick = { filePicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (audioFile != null) {
            item {
                AudioPlayerCard(
                    audioFile = audioFile,
                    title = "मूल ऑडियो (${audioFile?.name})"
                )
            }

            item {
                AccurateTimePickerField(
                    title = "हटाए जाने वाले हिस्से की शुरुआत (Start of cut)",
                    currentMs = cutStartMs,
                    maxMs = totalDur,
                    onTimeChange = { cutStartMs = it }
                )
            }

            item {
                AccurateTimePickerField(
                    title = "हटाए जाने वाले हिस्से की समाप्ति (End of cut)",
                    currentMs = cutEndMs,
                    maxMs = totalDur,
                    onTimeChange = { cutEndMs = it }
                )
            }

            item {
                RealProgressBarCard(
                    taskName = "बीच का हिस्सा काटा जा रहा है",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            item {
                AccessibleButton(
                    text = "चुना हुआ हिस्सा हटाएँ और बाकी जोड़ें",
                    icon = Icons.Default.ContentCut,
                    onClick = {
                        viewModel.executeAudioCutMiddle(cutStartMs, cutEndMs) { res ->
                            cutResult = res
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing && cutEndMs > cutStartMs
                )
            }

            if (cutResult != null) {
                item {
                    AudioPlayerCard(
                        audioFile = cutResult,
                        title = "कटिंग के बाद का नया ऑडियो सुनें"
                    )
                }
            }
        }
    }
}

/**
 * टूल 11: ऑडियो में सही समय पर फोटो लगाकर वीडियो बनाएँ (Audio to Video with Photos — DEDICATED TOOL)
 */
@Composable
fun AudioWithPhotosVideoToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val audioFile by viewModel.selectedAudioFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var timedPhotos by remember { mutableStateOf<List<com.example.utils.TimedPhotoData>>(emptyList()) }
    var currentPlaybackMs by remember { mutableLongStateOf(0L) }
    var outputVideo by remember { mutableStateOf<File?>(null) }
    var showTimeDialog by remember { mutableStateOf<com.example.utils.TimedPhotoData?>(null) }
    var singlePhotoWholeStory by remember { mutableStateOf(false) }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "MasterStoryAudio", "wav")
            viewModel.selectedAudioFile.value = copied
            HapticAndSoundUtil.announceForAccessibility(context, "मुख्य कहानी ऑडियो चुनी गई")
        }
    }

    val photoPickerCurrentTime = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && audioFile != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "StoryPhoto_${System.currentTimeMillis() % 1000}", "jpg")
            if (copied != null) {
                val totalDur = FileUtil.getMediaDuration(context, audioFile!!)
                val start = currentPlaybackMs
                val end = if (singlePhotoWholeStory) totalDur else minOf(totalDur, currentPlaybackMs + 10000L)
                val newPhoto = com.example.utils.TimedPhotoData(
                    file = copied,
                    startMs = start,
                    endMs = end,
                    label = "फोटो ${timedPhotos.size + 1}"
                )
                timedPhotos = timedPhotos + newPhoto
                HapticAndSoundUtil.announceForAccessibility(
                    context,
                    "${newPhoto.label} समय ${FileUtil.formatDurationHindi(start)} पर जोड़ी गई"
                )
            }
        }
    }

    val manualPhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && audioFile != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "StoryPhoto_${System.currentTimeMillis() % 1000}", "jpg")
            if (copied != null) {
                val totalDur = FileUtil.getMediaDuration(context, audioFile!!)
                val newPhoto = com.example.utils.TimedPhotoData(
                    file = copied,
                    startMs = 0L,
                    endMs = if (singlePhotoWholeStory) totalDur else minOf(totalDur, 10000L),
                    label = "फोटो ${timedPhotos.size + 1}"
                )
                timedPhotos = timedPhotos + newPhoto
                showTimeDialog = newPhoto
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "ऑडियो में सही समय पर फोटो लगाकर वीडियो बनाएँ",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "पूरी लंबी कहानी (उदा. 34 मिनट) या पॉडकास्ट की ऑडियो के अलग-अलग समय पर फोटो जोड़ें (जैसे 02:30 चायवाला, 04:15 चाय बनाना, 06:40 चाय पीना, 15:00 डरावनी घटना)। मुख्य ऑडियो की पूरी अवधि वीडियो में सुरक्षित रहेगी।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            AccessibleButton(
                text = if (audioFile != null) "मुख्य ऑडियो: ${audioFile?.name}" else "1. फोन से मुख्य कहानी ऑडियो चुनें",
                icon = Icons.Default.Audiotrack,
                onClick = { audioPicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (audioFile != null) {
            val totalDur = FileUtil.getMediaDuration(context, audioFile!!)

            item {
                AudioPlayerCard(
                    audioFile = audioFile,
                    title = "कहानी ऑडियो सुनें और समय बिंदु चुनें",
                    onPositionChanged = { pos -> currentPlaybackMs = pos }
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "कहानी की कुल अवधि: ${FileUtil.formatDuration(totalDur)} (${FileUtil.formatDurationHindi(totalDur)})",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = "वर्तमान स्थिति: ${FileUtil.formatDuration(currentPlaybackMs)} (${FileUtil.formatDurationHindi(currentPlaybackMs)})",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = singlePhotoWholeStory,
                            onCheckedChange = { checked ->
                                singlePhotoWholeStory = checked
                                if (checked && timedPhotos.isNotEmpty()) {
                                    timedPhotos = timedPhotos.mapIndexed { idx, p ->
                                        if (idx == 0) p.copy(startMs = 0L, endMs = totalDur) else p
                                    }
                                }
                            },
                            modifier = Modifier.semantics { contentDescription = "एक ही फोटो को पूरी कहानी (00:00 से समाप्ति तक) में दिखाएँ" }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "एक ही फोटो पूरी कहानी (00:00 से अंत) तक दिखाएँ",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AccessibleButton(
                        text = "वर्तमान समय पर फोटो जोड़ें",
                        icon = Icons.Default.AddPhotoAlternate,
                        onClick = { photoPickerCurrentTime.launch("image/*") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(
                        onClick = { manualPhotoPicker.launch("image/*") },
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 52.dp)
                            .semantics { contentDescription = "फोटो जोड़ें और समय दर्ज करें" }
                    ) {
                        Text("+ समय दर्ज करें", fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            if (timedPhotos.isNotEmpty()) {
                item {
                    Text(
                        text = "कहानी के अनुसार फोटो सूची (${timedPhotos.size}):",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                itemsIndexed(timedPhotos) { idx, p ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "${idx + 1}.", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = p.label.ifBlank { p.file.name }, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "${FileUtil.formatDuration(p.startMs)} से ${FileUtil.formatDuration(p.endMs)} (अवधि: ${FileUtil.formatDurationHindi(p.endMs - p.startMs)})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            if (idx > 0) {
                                IconButton(onClick = {
                                    val list = timedPhotos.toMutableList()
                                    val item = list.removeAt(idx)
                                    list.add(idx - 1, item)
                                    timedPhotos = list
                                }) {
                                    Icon(Icons.Default.ArrowUpward, contentDescription = "${p.label} ऊपर ले जाएँ")
                                }
                            }

                            if (idx < timedPhotos.size - 1) {
                                IconButton(onClick = {
                                    val list = timedPhotos.toMutableList()
                                    val item = list.removeAt(idx)
                                    list.add(idx + 1, item)
                                    timedPhotos = list
                                }) {
                                    Icon(Icons.Default.ArrowDownward, contentDescription = "${p.label} नीचे ले जाएँ")
                                }
                            }

                            IconButton(onClick = { showTimeDialog = p }) {
                                Icon(Icons.Default.Edit, contentDescription = "${p.label} का समय बदलें")
                            }

                            IconButton(onClick = {
                                timedPhotos = timedPhotos.filter { it.id != p.id }
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "${p.label} हटाएँ", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }

                item {
                    RealProgressBarCard(
                        taskName = "ऑडियो के अनुसार संपूर्ण कहानी वीडियो तैयार हो रहा है",
                        progressPercent = progress,
                        isProcessing = isProcessing
                    )
                }

                item {
                    AccessibleButton(
                        text = "पूरा वीडियो बनाएँ (MP4 सेव करें)",
                        icon = Icons.Default.MovieCreation,
                        onClick = {
                            viewModel.executeAudioWithTimedPhotos(audioFile!!, timedPhotos) { res ->
                                outputVideo = res
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isProcessing
                    )
                }

                if (outputVideo != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(text = "संपूर्ण कहानी वीडियो तैयार हो गया!", fontWeight = FontWeight.Bold)
                                Text(text = "फ़ाइल नाम: ${outputVideo?.name}")
                                Text(text = "अवधि: ${FileUtil.formatDurationHindi(FileUtil.getMediaDuration(context, outputVideo!!))}")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showTimeDialog != null) {
        val target = showTimeDialog!!
        val maxDur = if (audioFile != null) FileUtil.getMediaDuration(context, audioFile!!) else 3600000L
        var start by remember(target) { mutableLongStateOf(target.startMs) }
        var end by remember(target) { mutableLongStateOf(target.endMs) }
        var labelText by remember(target) { mutableStateOf(target.label) }

        AlertDialog(
            onDismissRequest = { showTimeDialog = null },
            title = { Text(text = "फोटो का समय निर्धारित करें", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = labelText,
                        onValueChange = { labelText = it },
                        label = { Text("फोटो का शीर्षक (उदा. चायवाला)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    AccurateTimePickerField(
                        title = "शुरुआत का समय (Start Time)",
                        currentMs = start,
                        maxMs = maxDur,
                        onTimeChange = { start = it }
                    )
                    AccurateTimePickerField(
                        title = "समाप्ति का समय (End Time)",
                        currentMs = end,
                        maxMs = maxDur,
                        onTimeChange = { end = it }
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val updated = timedPhotos.map {
                        if (it.id == target.id) it.copy(startMs = start, endMs = maxOf(start + 1000L, end), label = labelText) else it
                    }
                    timedPhotos = updated
                    showTimeDialog = null
                    HapticAndSoundUtil.announceForAccessibility(context, "समय सुरक्षित हुआ")
                }) {
                    Text("सहेजें")
                }
            },
            dismissButton = {
                TextButton(onClick = { showTimeDialog = null }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}

/**
 * टूल 12: वीडियो क्लिप जोड़कर वीडियो बनाएँ (Video Clips Merger / Creator — DEDICATED TOOL)
 */
@Composable
fun VideoClipsMergeToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var clipConfigs by remember { mutableStateOf<List<com.example.utils.VideoClipConfig>>(emptyList()) }
    var bgMusicFile by remember { mutableStateOf<File?>(null) }
    var bgMusicVol by remember { mutableFloatStateOf(0.4f) }
    var mergedResult by remember { mutableStateOf<File?>(null) }
    var editingClip by remember { mutableStateOf<com.example.utils.VideoClipConfig?>(null) }

    val clipPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "ClipToJoin_${System.currentTimeMillis() % 1000}", "mp4")
            if (copied != null) {
                val dur = FileUtil.getMediaDuration(context, copied)
                val newConfig = com.example.utils.VideoClipConfig(
                    file = copied,
                    startTrimMs = 0L,
                    endTrimMs = dur,
                    volume = 1.0f,
                    label = "क्लिप ${clipConfigs.size + 1}"
                )
                clipConfigs = clipConfigs + newConfig
                HapticAndSoundUtil.announceForAccessibility(context, "${copied.name} क्लिप सूची में जोड़ी गई")
            }
        }
    }

    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "MergeBgMusic", "wav")
            bgMusicFile = copied
            HapticAndSoundUtil.announceForAccessibility(context, "बैकग्राउंड म्यूजिक चुना गया")
        }
    }

    // Compute total combined duration taking clip repeat count into account
    val totalDurationMs = clipConfigs.sumOf { cfg ->
        val full = FileUtil.getMediaDuration(context, cfg.file)
        val end = if (cfg.endTrimMs > 0) cfg.endTrimMs else full
        val dur = maxOf(0L, end - cfg.startTrimMs)
        val rep = if (cfg.isRepeatEnabled) cfg.repeatCount else 1
        dur * rep
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "वीडियो क्लिप जोड़कर वीडियो बनाएँ",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Google Flow Veo 3 या कैमरे से बनाए गए छोटे-छोटे वीडियो क्लिप्स को अपने मनचाहे क्रम में जोड़ें। प्रत्येक क्लिप का मूल वॉल्यूम (0% म्यूट से 200%) अलग से नियंत्रित करें, कटिंग करें और बैकग्राउंड म्यूजिक जोड़ें।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            AccessibleButton(
                text = "+ फोन से वीडियो क्लिप जोड़ें",
                icon = Icons.Default.Add,
                onClick = { clipPicker.launch("video/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (clipConfigs.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "क्लिप संख्या: ${clipConfigs.size} | कुल अवधि: ${FileUtil.formatDuration(totalDurationMs)} (${FileUtil.formatDurationHindi(totalDurationMs)})",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }

            itemsIndexed(clipConfigs) { idx, cfg ->
                val fullDur = FileUtil.getMediaDuration(context, cfg.file)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "${idx + 1}.", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = cfg.label.ifBlank { cfg.file.name }, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                Text(
                                    text = "अवधि: ${FileUtil.formatDuration(fullDur)} | वॉल्यूम: ${(cfg.volume * 100).toInt()}% ${if (cfg.volume == 0f) "(म्यूट)" else ""}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }

                            if (idx > 0) {
                                IconButton(onClick = {
                                    val list = clipConfigs.toMutableList()
                                    val item = list.removeAt(idx)
                                    list.add(idx - 1, item)
                                    clipConfigs = list
                                }) {
                                    Icon(Icons.Default.ArrowUpward, contentDescription = "${cfg.label} ऊपर ले जाएँ")
                                }
                            }

                            if (idx < clipConfigs.size - 1) {
                                IconButton(onClick = {
                                    val list = clipConfigs.toMutableList()
                                    val item = list.removeAt(idx)
                                    list.add(idx + 1, item)
                                    clipConfigs = list
                                }) {
                                    Icon(Icons.Default.ArrowDownward, contentDescription = "${cfg.label} नीचे ले जाएँ")
                                }
                            }

                            IconButton(onClick = { editingClip = cfg }) {
                                Icon(Icons.Default.Tune, contentDescription = "${cfg.label} की सेटिंग बदलें")
                            }

                            IconButton(onClick = {
                                clipConfigs = clipConfigs.filter { it.id != cfg.id }
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "${cfg.label} हटाएँ", tint = MaterialTheme.colorScheme.error)
                            }
                        }

                        // Direct Volume Slider for this clip
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                        ) {
                            Text(
                                text = "वॉल्यूम: ${(cfg.volume * 100).toInt()}%",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.width(80.dp)
                            )
                            Slider(
                                value = cfg.volume,
                                onValueChange = { newVol ->
                                    clipConfigs = clipConfigs.map { if (it.id == cfg.id) it.copy(volume = newVol) else it }
                                },
                                valueRange = 0f..2f,
                                modifier = Modifier.weight(1f).semantics {
                                    contentDescription = "${cfg.label} का वॉल्यूम ${(cfg.volume * 100).toInt()} प्रतिशत"
                                }
                            )
                            TextButton(
                                onClick = {
                                    val targetVol = if (cfg.volume == 0f) 1.0f else 0f
                                    clipConfigs = clipConfigs.map { if (it.id == cfg.id) it.copy(volume = targetVol) else it }
                                }
                            ) {
                                Text(if (cfg.volume == 0f) "अनम्यूट" else "म्यूट")
                            }
                        }

                        // Universal Repeat Control for this clip (Part 2 & Part 4.6)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp)
                        ) {
                            Checkbox(
                                checked = cfg.isRepeatEnabled,
                                onCheckedChange = { checked ->
                                    clipConfigs = clipConfigs.map { if (it.id == cfg.id) it.copy(isRepeatEnabled = checked) else it }
                                    HapticAndSoundUtil.announceForAccessibility(
                                        context,
                                        if (checked) "${cfg.label} रिपीट चालू" else "${cfg.label} रिपीट बंद"
                                    )
                                },
                                modifier = Modifier.semantics { contentDescription = "${cfg.label} को रिपीट करें" }
                            )
                            Text(
                                text = "इस वीडियो क्लिप को रिपीट करें",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (cfg.isRepeatEnabled) {
                                Spacer(modifier = Modifier.width(8.dp))
                                OutlinedButton(
                                    onClick = {
                                        if (cfg.repeatCount > 1) {
                                            clipConfigs = clipConfigs.map { if (it.id == cfg.id) it.copy(repeatCount = it.repeatCount - 1) else it }
                                        }
                                    },
                                    enabled = cfg.repeatCount > 1,
                                    modifier = Modifier.defaultMinSize(minHeight = 44.dp)
                                ) {
                                    Text("-1")
                                }
                                Text(
                                    text = "${cfg.repeatCount} बार",
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp)
                                )
                                OutlinedButton(
                                    onClick = {
                                        if (cfg.repeatCount < 20) {
                                            clipConfigs = clipConfigs.map { if (it.id == cfg.id) it.copy(repeatCount = it.repeatCount + 1) else it }
                                        }
                                    },
                                    modifier = Modifier.defaultMinSize(minHeight = 44.dp)
                                ) {
                                    Text("+1")
                                }
                            }
                        }
                    }
                }
            }

            // Optional Background Music Section
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (bgMusicFile != null) "बैकग्राउंड म्यूजिक: ${bgMusicFile?.name}" else "बैकग्राउंड म्यूजिक जोड़ें (ऐच्छिक)",
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { musicPicker.launch("audio/*") },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (bgMusicFile != null) "म्यूजिक बदलें" else "म्यूजिक चुनें")
                            }
                            if (bgMusicFile != null) {
                                TextButton(onClick = { bgMusicFile = null }) {
                                    Text("हटाएँ", color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }

                        if (bgMusicFile != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = "म्यूजिक वॉल्यूम: ${(bgMusicVol * 100).toInt()}%", style = MaterialTheme.typography.bodySmall)
                            Slider(
                                value = bgMusicVol,
                                onValueChange = { bgMusicVol = it },
                                valueRange = 0.05f..1.0f,
                                modifier = Modifier.semantics { contentDescription = "बैकग्राउंड म्यूजिक वॉल्यूम: ${(bgMusicVol * 100).toInt()} प्रतिशत" }
                            )

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "पूरी वीडियो में म्यूजिक स्वतः रिपीट (Loop) होगा",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            if (clipConfigs.size >= 2) {
                item {
                    RealProgressBarCard(
                        taskName = "वीडियो क्लिप्स जोड़ी जा रही हैं",
                        progressPercent = progress,
                        isProcessing = isProcessing
                    )
                }

                item {
                    AccessibleButton(
                        text = "सभी ${clipConfigs.size} क्लिप जोड़ें और सेव करें",
                        icon = Icons.Default.CallMerge,
                        onClick = {
                            viewModel.executeVideoClipsMergeWithAudio(clipConfigs, bgMusicFile, bgMusicVol) { res ->
                                mergedResult = res
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isProcessing
                    )
                }

                if (mergedResult != null) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(text = "जुड़ा हुआ वीडियो तैयार है!", fontWeight = FontWeight.Bold)
                                Text(text = "फ़ाइल: ${mergedResult?.name}")
                                Text(text = "अवधि: ${FileUtil.formatDurationHindi(FileUtil.getMediaDuration(context, mergedResult!!))}")
                            }
                        }
                    }
                }
            }
        }
    }

    // Clip settings dialog (Trim & Label)
    if (editingClip != null) {
        val target = editingClip!!
        val fullDur = FileUtil.getMediaDuration(context, target.file)
        var trimStart by remember(target) { mutableLongStateOf(target.startTrimMs) }
        var trimEnd by remember(target) { mutableLongStateOf(if (target.endTrimMs > 0) target.endTrimMs else fullDur) }
        var clipLabel by remember(target) { mutableStateOf(target.label) }

        AlertDialog(
            onDismissRequest = { editingClip = null },
            title = { Text("क्लिप की कटिंग एवं विवरण", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = clipLabel,
                        onValueChange = { clipLabel = it },
                        label = { Text("क्लिप का नाम / विवरण") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    AccurateTimePickerField(
                        title = "क्लिप की शुरुआत काटें (Trim Start)",
                        currentMs = trimStart,
                        maxMs = fullDur,
                        onTimeChange = { trimStart = it }
                    )
                    AccurateTimePickerField(
                        title = "क्लिप की समाप्ति काटें (Trim End)",
                        currentMs = trimEnd,
                        maxMs = fullDur,
                        onTimeChange = { trimEnd = it }
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    clipConfigs = clipConfigs.map {
                        if (it.id == target.id) it.copy(startTrimMs = trimStart, endTrimMs = trimEnd, label = clipLabel) else it
                    }
                    editingClip = null
                    HapticAndSoundUtil.announceForAccessibility(context, "क्लिप सेटिंग सुरक्षित हुई")
                }) {
                    Text("सहेजें")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingClip = null }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}

/**
 * टूल: वीडियो की मूल आवाज़ नियंत्रित करें (Video Volume Control Tool)
 */
@Composable
fun VideoVolumeControlToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val videoFile by viewModel.selectedVideoFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var muteAudio by remember { mutableStateOf(false) }
    var outputResult by remember { mutableStateOf<File?>(null) }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "ToVolumeVideo", "mp4")
            viewModel.selectedVideoFile.value = copied
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            AccessibleButton(
                text = if (videoFile != null) "वीडियो: ${videoFile?.name}" else "फोन से वीडियो चुनें",
                icon = Icons.Default.FolderOpen,
                onClick = { videoPicker.launch("video/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (videoFile != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "वीडियो: ${videoFile?.name}", fontWeight = FontWeight.Bold)
                        Text(text = "अवधि: ${FileUtil.formatDurationHindi(FileUtil.getMediaDuration(context, videoFile!!))}")
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = muteAudio,
                            onCheckedChange = { muteAudio = it },
                            modifier = Modifier.semantics { contentDescription = "वीडियो की मूल आवाज़ पूरी तरह म्यूट (बंद) करें" }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "वीडियो की मूल आवाज़ म्यूट (बंद) करें", fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            item {
                RealProgressBarCard(
                    taskName = "वीडियो आवाज़ नियंत्रण",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            item {
                AccessibleButton(
                    text = "आवाज़ सेटिंग लागू करें और नया वीडियो सेव करें",
                    icon = Icons.Default.Check,
                    onClick = {
                        viewModel.executeVideoVolumeControl(videoFile!!, muteAudio) { res ->
                            outputResult = res
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing
                )
            }

            if (outputResult != null) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(text = "संशोधित वीडियो सेव हुआ!", fontWeight = FontWeight.Bold)
                            Text(text = "फ़ाइल: ${outputResult?.name}")
                        }
                    }
                }
            }
        }
    }
}
