package com.example.ui.screens

import android.Manifest
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.utils.AudioEngine
import com.example.utils.FileUtil
import com.example.utils.HapticAndSoundUtil
import com.example.viewmodel.MainViewModel
import java.io.File

@Composable
fun AudioRecorderToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isRecording by viewModel.isRecording.collectAsStateWithLifecycle()
    val isPaused by viewModel.isRecordingPaused.collectAsStateWithLifecycle()
    val durationMs by viewModel.recordDurationMs.collectAsStateWithLifecycle()
    val recordedFile by viewModel.activeRecordedFile.collectAsStateWithLifecycle()
    val amplitude by AudioEngine.currentAmplitude.collectAsStateWithLifecycle()

    var customFileName by remember { mutableStateOf("") }
    var hasPermission by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasPermission = granted
        if (granted) {
            HapticAndSoundUtil.announceForAccessibility(context, "माइक्रोफोन अनुमति स्वीकृत हुई")
        } else {
            HapticAndSoundUtil.announceForAccessibility(context, "माइक्रोफोन अनुमति अस्वीकृत हुई")
        }
    }

    LaunchedEffect(Unit) {
        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isRecording) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics {
                        liveRegion = LiveRegionMode.Polite
                        contentDescription = if (isRecording) {
                            if (isPaused) "रिकॉर्डिंग रुकी हुई है, अवधि ${FileUtil.formatDurationHindi(durationMs)}"
                            else "लाइव रिकॉर्डिंग जारी है, वर्तमान अवधि ${FileUtil.formatDurationHindi(durationMs)}"
                        } else "ऑडियो रिकॉर्डर तैयार है"
                    }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(
                                if (isRecording) {
                                    if (isPaused) Color(0xFFF59E0B) else Color(0xFFEF4444)
                                } else MaterialTheme.colorScheme.primary
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isRecording) Icons.Default.Mic else Icons.Default.MicNone,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = FileUtil.formatDuration(durationMs),
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isRecording) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onPrimaryContainer
                    )

                    Text(
                        text = FileUtil.formatDurationHindi(durationMs),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )

                    // Amplitude wave bar
                    if (isRecording && !isPaused) {
                        Spacer(modifier = Modifier.height(14.dp))
                        LinearProgressIndicator(
                            progress = { amplitude },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = Color(0xFFEF4444),
                            trackColor = Color.White.copy(alpha = 0.3f)
                        )
                    }
                }
            }
        }

        // Control Buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!isRecording) {
                    AccessibleButton(
                        text = "रिकॉर्डिंग शुरू करें",
                        icon = Icons.Default.FiberManualRecord,
                        onClick = {
                            viewModel.startAudioRecording()
                        },
                        containerColor = Color(0xFFEF4444),
                        contentColor = Color.White,
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    if (isPaused) {
                        AccessibleButton(
                            text = "जारी रखें (Resume)",
                            icon = Icons.Default.PlayArrow,
                            onClick = { viewModel.resumeAudioRecording() },
                            containerColor = Color(0xFF10B981),
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        AccessibleButton(
                            text = "रोकें (Pause)",
                            icon = Icons.Default.Pause,
                            onClick = { viewModel.pauseAudioRecording() },
                            containerColor = Color(0xFFF59E0B),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    AccessibleButton(
                        text = "समाप्त करें (Save)",
                        icon = Icons.Default.Stop,
                        onClick = {
                            viewModel.stopAudioRecording(customFileName)
                        },
                        containerColor = Color(0xFFEF4444),
                        contentColor = Color.White,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Naming option
        item {
            OutlinedTextField(
                value = customFileName,
                onValueChange = { customFileName = it },
                label = { Text("रिकॉर्डिंग का नाम दर्ज करें (वैकल्पिक)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics { contentDescription = "रिकॉर्डिंग फाइल का नाम दर्ज करें" }
            )
        }

        // Recorded File Preview Player
        if (!isRecording && recordedFile != null && recordedFile!!.exists()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "सहेजी गई रिकॉर्डिंग: ${recordedFile?.name}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        AudioPlayerCard(
                            audioFile = recordedFile,
                            title = "रिकॉर्डिंग सुनें"
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AudioTrimToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val audioFile by viewModel.selectedAudioFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()
    val taskName by viewModel.taskName.collectAsStateWithLifecycle()
    val statusText by viewModel.processingStatus.collectAsStateWithLifecycle()

    var startMs by remember { mutableLongStateOf(0L) }
    var totalDur by remember(audioFile) {
        mutableLongStateOf(if (audioFile != null) FileUtil.getMediaDuration(context, audioFile!!) else 0L)
    }
    var endMs by remember(totalDur) { mutableLongStateOf(totalDur) }
    var trimmedResult by remember { mutableStateOf<File?>(null) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "ToTrim", "wav")
            if (copied != null) {
                viewModel.selectedAudioFile.value = copied
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            AccessibleButton(
                text = if (audioFile != null) "दूसरी ऑडियो फ़ाइल चुनें" else "फ़ोन से ऑडियो चुनें",
                icon = Icons.Default.FolderOpen,
                onClick = { filePicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (audioFile != null) {
            item {
                AudioPlayerCard(
                    audioFile = audioFile,
                    title = "मूल ऑडियो (${audioFile?.name})"
                )
            }

            item {
                AccurateTimePickerField(
                    title = "कटिंग की शुरुआत (Start Time)",
                    currentMs = startMs,
                    maxMs = totalDur,
                    onTimeChange = { startMs = it }
                )
            }

            item {
                AccurateTimePickerField(
                    title = "कटिंग की समाप्ति (End Time)",
                    currentMs = endMs,
                    maxMs = totalDur,
                    onTimeChange = { endMs = it }
                )
            }

            item {
                RealProgressBarCard(
                    taskName = taskName,
                    progressPercent = progress,
                    isProcessing = isProcessing,
                    statusText = statusText,
                    onCancel = { viewModel.cancelCurrentTask() }
                )
            }

            item {
                AccessibleButton(
                    text = "ऑडियो काटें और सेव करें",
                    icon = Icons.Default.ContentCut,
                    onClick = {
                        viewModel.executeAudioTrim(startMs, endMs) { result ->
                            trimmedResult = result
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing && endMs > startMs
                )
            }

            if (trimmedResult != null) {
                item {
                    AudioPlayerCard(
                        audioFile = trimmedResult,
                        title = "कटा हुआ नया ऑडियो सुनें"
                    )
                }
            }
        }
    }
}

@Composable
fun AudioMixMusicToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val voiceFile by viewModel.selectedAudioFile.collectAsStateWithLifecycle()
    val musicFile by viewModel.secondaryAudioFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()
    val taskName by viewModel.taskName.collectAsStateWithLifecycle()

    var voiceVol by remember { mutableFloatStateOf(1.0f) }
    var musicVol by remember { mutableFloatStateOf(0.4f) }
    var musicStartMs by remember { mutableLongStateOf(0L) }
    var musicDurationMs by remember { mutableLongStateOf(0L) }
    var fadeInSec by remember { mutableIntStateOf(2) }
    var fadeOutSec by remember { mutableIntStateOf(2) }
    var isRepeatEnabled by remember { mutableStateOf(false) }
    var repeatUntilEnd by remember { mutableStateOf(true) }
    var repeatCount by remember { mutableIntStateOf(1) }
    var repeatIntervalSec by remember { mutableIntStateOf(0) }
    var mixedResult by remember { mutableStateOf<File?>(null) }

    val voicePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "Voice", "wav")
            viewModel.selectedAudioFile.value = copied
            HapticAndSoundUtil.announceForAccessibility(context, "मुख्य आवाज़ चुनी गई: ${copied?.name}")
        }
    }

    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "Music", "wav")
            viewModel.secondaryAudioFile.value = copied
            HapticAndSoundUtil.announceForAccessibility(context, "बैकग्राउंड म्यूजिक चुना गया: ${copied?.name}")
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "रिकॉर्ड की गई ऑडियो में म्यूजिक जोड़ें",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "अपनी रिकॉर्ड की हुई कहानी, पॉडकास्ट या दूसरी ऑडियो में बैकग्राउंड म्यूजिक जोड़ें। म्यूजिक की आवाज़ और अवधि अपनी जरूरत के अनुसार तय करें और तैयार ऑडियो को सेव करें।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Voice Picker
        item {
            AccessibleButton(
                text = if (voiceFile != null) "1. मुख्य आवाज़: ${voiceFile?.name}" else "1. मुख्य आवाज़ चुनें",
                icon = Icons.Default.Mic,
                onClick = { voicePicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Music Picker
        item {
            AccessibleButton(
                text = if (musicFile != null) "2. म्यूजिक फाइल: ${musicFile?.name}" else "2. फोन से म्यूजिक फाइल चुनें",
                icon = Icons.Default.MusicNote,
                onClick = { musicPicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (voiceFile != null && musicFile != null) {
            val voiceDur = FileUtil.getMediaDuration(context, voiceFile!!)

            item {
                AudioPlayerCard(
                    audioFile = voiceFile,
                    title = "मुख्य आवाज़ सुनें"
                )
            }

            item {
                AudioPlayerCard(
                    audioFile = musicFile,
                    title = "बैकग्राउंड म्यूजिक सुनें"
                )
            }

            // Accurate Timing Controls
            item {
                AccurateTimePickerField(
                    title = "म्यूजिक शुरू होने का समय (घंटे:मिनट:सेकंड)",
                    currentMs = musicStartMs,
                    maxMs = voiceDur,
                    onTimeChange = { musicStartMs = it }
                )
            }

            item {
                AccurateTimePickerField(
                    title = "म्यूजिक की अवधि (घंटे:मिनट:सेकंड — 0 रखें यदि पूरी ऑडियो तक चलाना हो)",
                    currentMs = musicDurationMs,
                    maxMs = voiceDur,
                    onTimeChange = { musicDurationMs = it }
                )
            }

            // Volume Controls & Fades
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "मुख्य आवाज़ का वॉल्यूम: ${(voiceVol * 100).toInt()}%",
                            fontWeight = FontWeight.SemiBold
                        )
                        Slider(
                            value = voiceVol,
                            onValueChange = { voiceVol = it },
                            valueRange = 0f..2f,
                            modifier = Modifier.semantics { contentDescription = "मुख्य आवाज़ वॉल्यूम: ${(voiceVol * 100).toInt()} प्रतिशत" }
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "बैकग्राउंड म्यूजिक का वॉल्यूम: ${(musicVol * 100).toInt()}%",
                            fontWeight = FontWeight.SemiBold
                        )
                        Slider(
                            value = musicVol,
                            onValueChange = { musicVol = it },
                            valueRange = 0f..2f,
                            modifier = Modifier.semantics { contentDescription = "बैकग्राउंड म्यूजिक वॉल्यूम: ${(musicVol * 100).toInt()} प्रतिशत" }
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "फेड-इन: $fadeInSec सेकंड", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                Slider(
                                    value = fadeInSec.toFloat(),
                                    onValueChange = { fadeInSec = it.toInt() },
                                    valueRange = 0f..10f,
                                    steps = 9,
                                    modifier = Modifier.semantics { contentDescription = "फेड इन $fadeInSec सेकंड" }
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = "फेड-आउट: $fadeOutSec सेकंड", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                Slider(
                                    value = fadeOutSec.toFloat(),
                                    onValueChange = { fadeOutSec = it.toInt() },
                                    valueRange = 0f..10f,
                                    steps = 9,
                                    modifier = Modifier.semantics { contentDescription = "फेड आउट $fadeOutSec सेकंड" }
                                )
                            }
                        }
                    }
                }
            }

            // Universal Repeat Section (Part 2)
            item {
                RepeatControlSection(
                    mediaTitle = "इस बैकग्राउंड म्यूजिक",
                    isRepeatEnabled = isRepeatEnabled,
                    onRepeatToggle = { isRepeatEnabled = it },
                    repeatUntilEnd = repeatUntilEnd,
                    onRepeatUntilEndChange = { repeatUntilEnd = it },
                    repeatCount = repeatCount,
                    onRepeatCountChange = { repeatCount = it },
                    intervalSeconds = repeatIntervalSec,
                    onIntervalChange = { repeatIntervalSec = it }
                )
            }

            item {
                RealProgressBarCard(
                    taskName = taskName,
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            item {
                AccessibleButton(
                    text = "म्यूजिक मिक्स करें और सेव करें",
                    icon = Icons.Default.LibraryAddCheck,
                    onClick = {
                        viewModel.executeMixVoiceMusic(
                            voiceVol = voiceVol,
                            musicVol = musicVol,
                            musicStartMs = musicStartMs,
                            musicDurationMs = musicDurationMs,
                            loop = isRepeatEnabled,
                            fadeInMs = fadeInSec * 1000L,
                            fadeOutMs = fadeOutSec * 1000L,
                            repeatCount = repeatCount,
                            repeatUntilEnd = repeatUntilEnd
                        ) { res -> mixedResult = res }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing
                )
            }

            if (mixedResult != null) {
                item {
                    AudioPlayerCard(
                        audioFile = mixedResult,
                        title = "मिक्स किया हुआ नया ऑडियो सुनें"
                    )
                }
            }
        }
    }
}

@Composable
fun AudioAutoDuckingToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val voiceFile by viewModel.selectedAudioFile.collectAsStateWithLifecycle()
    val musicFile by viewModel.secondaryAudioFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var voiceVol by remember { mutableFloatStateOf(1.0f) }
    var musicVol by remember { mutableFloatStateOf(0.7f) }
    var duckLevel by remember { mutableFloatStateOf(20f) } // drops to 20%
    var sensitivity by remember { mutableFloatStateOf(40f) }
    var isRepeatEnabled by remember { mutableStateOf(true) }
    var repeatUntilEnd by remember { mutableStateOf(true) }
    var repeatCount by remember { mutableIntStateOf(1) }
    var duckedResult by remember { mutableStateOf<File?>(null) }

    val voicePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "VoiceDucking", "wav")
            viewModel.selectedAudioFile.value = copied
            HapticAndSoundUtil.announceForAccessibility(context, "मुख्य आवाज़ चुनी गई: ${copied?.name}")
        }
    }

    val musicPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "MusicDucking", "wav")
            viewModel.secondaryAudioFile.value = copied
            HapticAndSoundUtil.announceForAccessibility(context, "बैकग्राउंड म्यूजिक चुना गया: ${copied?.name}")
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "बोलते समय म्यूजिक की आवाज़ कम करें (Auto-Ducking)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "जैसे ही आप बोलना शुरू करेंगे, बैकग्राउंड म्यूजिक अपने आप धीमा हो जाएगा और बोलना बंद करने पर सामान्य हो जाएगा।",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            AccessibleButton(
                text = if (voiceFile != null) "1. आवाज़: ${voiceFile?.name}" else "1. मुख्य आवाज़ चुनें",
                icon = Icons.Default.Mic,
                onClick = { voicePicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            AccessibleButton(
                text = if (musicFile != null) "2. म्यूजिक: ${musicFile?.name}" else "2. बैकग्राउंड म्यूजिक चुनें",
                icon = Icons.Default.MusicNote,
                onClick = { musicPicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (voiceFile != null && musicFile != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "बोलते समय म्यूजिक कितना धीमा हो: ${duckLevel.toInt()}%",
                            fontWeight = FontWeight.SemiBold
                        )
                        Slider(
                            value = duckLevel,
                            onValueChange = { duckLevel = it },
                            valueRange = 5f..60f,
                            modifier = Modifier.semantics { contentDescription = "डकिंग स्तर: ${duckLevel.toInt()} प्रतिशत" }
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "आवाज़ पहचानने की संवेदनशीलता: ${sensitivity.toInt()}%",
                            fontWeight = FontWeight.SemiBold
                        )
                        Slider(
                            value = sensitivity,
                            onValueChange = { sensitivity = it },
                            valueRange = 10f..90f,
                            modifier = Modifier.semantics { contentDescription = "संवेदनशीलता: ${sensitivity.toInt()} प्रतिशत" }
                        )
                    }
                }
            }

            // Universal Repeat Section (Part 2)
            item {
                RepeatControlSection(
                    mediaTitle = "इस बैकग्राउंड म्यूजिक",
                    isRepeatEnabled = isRepeatEnabled,
                    onRepeatToggle = { isRepeatEnabled = it },
                    repeatUntilEnd = repeatUntilEnd,
                    onRepeatUntilEndChange = { repeatUntilEnd = it },
                    repeatCount = repeatCount,
                    onRepeatCountChange = { repeatCount = it }
                )
            }

            item {
                RealProgressBarCard(
                    taskName = "ऑटो-डकिंग प्रोसेसिंग",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            item {
                AccessibleButton(
                    text = "ऑटो-डकिंग लागू करें और सेव करें",
                    icon = Icons.Default.VolumeDown,
                    onClick = {
                        viewModel.executeAutoDucking(
                            voiceVol = voiceVol,
                            musicVol = musicVol,
                            duckLevelPercent = duckLevel,
                            sensitivityPercent = sensitivity,
                            loopMusic = isRepeatEnabled,
                            repeatCount = repeatCount,
                            repeatUntilEnd = repeatUntilEnd
                        ) { res -> duckedResult = res }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing
                )
            }

            if (duckedResult != null) {
                item {
                    AudioPlayerCard(
                        audioFile = duckedResult,
                        title = "ऑटो-डक किया हुआ ऑडियो सुनें"
                    )
                }
            }
        }
    }
}

@Composable
fun AudioVoiceModulationToolScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val audioFile by viewModel.selectedAudioFile.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progress by viewModel.progressPercent.collectAsStateWithLifecycle()

    var selectedEffect by remember { mutableStateOf(AudioEngine.VoiceEffect.ECHO) }
    var intensity by remember { mutableFloatStateOf(1.0f) }
    var echoDelayMs by remember { mutableIntStateOf(240) }
    var modulatedResult by remember { mutableStateOf<File?>(null) }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val copied = FileUtil.copyUriToInternalFile(context, uri, "VoiceFx", "wav")
            viewModel.selectedAudioFile.value = copied
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            AccessibleButton(
                text = if (audioFile != null) "ऑडियो: ${audioFile?.name}" else "फोन से ऑडियो चुनें",
                icon = Icons.Default.FolderOpen,
                onClick = { audioPicker.launch("audio/*") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (audioFile != null) {
            item {
                Text(
                    text = "आवाज़ का प्रभाव चुनें:",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            // Effects radio buttons
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        EffectOptionRow(
                            title = "गूँज और इको (Echo & Reverb)",
                            selected = selectedEffect == AudioEngine.VoiceEffect.ECHO,
                            onClick = { selectedEffect = AudioEngine.VoiceEffect.ECHO }
                        )
                        EffectOptionRow(
                            title = "बच्चों जैसी आवाज़ (Child / Cartoon)",
                            selected = selectedEffect == AudioEngine.VoiceEffect.CHILD,
                            onClick = { selectedEffect = AudioEngine.VoiceEffect.CHILD }
                        )
                        EffectOptionRow(
                            title = "भारी आवाज़ (Deep / Bass)",
                            selected = selectedEffect == AudioEngine.VoiceEffect.DEEP,
                            onClick = { selectedEffect = AudioEngine.VoiceEffect.DEEP }
                        )
                        EffectOptionRow(
                            title = "रोबोटिक आवाज़ (Robot Modulator)",
                            selected = selectedEffect == AudioEngine.VoiceEffect.ROBOT,
                            onClick = { selectedEffect = AudioEngine.VoiceEffect.ROBOT }
                        )
                    }
                }
            }

            if (selectedEffect == AudioEngine.VoiceEffect.ECHO) {
                item {
                    Text(text = "इको विलंब (Delay): $echoDelayMs मिलीसेकंड", fontWeight = FontWeight.SemiBold)
                    Slider(
                        value = echoDelayMs.toFloat(),
                        onValueChange = { echoDelayMs = it.toInt() },
                        valueRange = 80f..500f,
                        modifier = Modifier.semantics { contentDescription = "इको विलंब $echoDelayMs मिलीसेकंड" }
                    )
                }
            }

            item {
                RealProgressBarCard(
                    taskName = "आवाज़ रूपांतरण",
                    progressPercent = progress,
                    isProcessing = isProcessing
                )
            }

            item {
                AccessibleButton(
                    text = "प्रभाव लागू करें और सेव करें",
                    icon = Icons.Default.AutoFixHigh,
                    onClick = {
                        viewModel.executeVoiceEffect(
                            effect = selectedEffect,
                            intensity = intensity,
                            echoDelayMs = echoDelayMs
                        ) { res -> modulatedResult = res }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isProcessing
                )
            }

            if (modulatedResult != null) {
                item {
                    AudioPlayerCard(
                        audioFile = modulatedResult,
                        title = "रूपांतरित नई आवाज़ सुनें"
                    )
                }
            }
        }
    }
}

@Composable
fun EffectOptionRow(
    title: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp)
            .semantics {
                this.contentDescription = "$title, ${if (selected) "चयनित" else "अचयनित"}"
                this.role = Role.RadioButton
            }
    ) {
        RadioButton(
            selected = selected,
            onClick = null
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
