package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.utils.FileUtil
import com.example.utils.HapticAndSoundUtil

@Composable
fun AccessibleButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    talkBackLabel: String = text,
    containerColor: Color = MaterialTheme.colorScheme.primary,
    contentColor: Color = MaterialTheme.colorScheme.onPrimary,
    enabled: Boolean = true
) {
    val context = LocalContext.current
    Button(
        onClick = {
            HapticAndSoundUtil.vibrate(context, 35)
            onClick()
        },
        modifier = modifier
            .defaultMinSize(minHeight = 52.dp)
            .semantics {
                contentDescription = talkBackLabel
                role = Role.Button
            },
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = containerColor.copy(alpha = 0.4f),
            disabledContentColor = contentColor.copy(alpha = 0.5f)
        ),
        shape = RoundedCornerShape(12.dp),
        enabled = enabled
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp
                )
            )
        }
    }
}

@Composable
fun QuickSeekControls(
    currentMs: Long,
    totalDurationMs: Long,
    onSeekTo: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            .padding(12.dp)
    ) {
        Text(
            text = "सटीक आगे-पीछे जाएँ (Quick Seek)",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Backward Buttons
            OutlinedButton(
                onClick = {
                    val target = maxOf(0L, currentMs - 5000L)
                    HapticAndSoundUtil.vibrate(context, 25)
                    HapticAndSoundUtil.announceForAccessibility(context, "5 सेकंड पीछे गए, वर्तमान स्थिति ${FileUtil.formatDurationHindi(target)}")
                    onSeekTo(target)
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 4.dp)
                    .defaultMinSize(minHeight = 48.dp)
                    .semantics { contentDescription = "5 सेकंड पीछे जाएँ" }
            ) {
                Text("-5s", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = {
                    val target = maxOf(0L, currentMs - 10000L)
                    HapticAndSoundUtil.vibrate(context, 25)
                    HapticAndSoundUtil.announceForAccessibility(context, "10 सेकंड पीछे गए")
                    onSeekTo(target)
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 2.dp)
                    .defaultMinSize(minHeight = 48.dp)
                    .semantics { contentDescription = "10 सेकंड पीछे जाएँ" }
            ) {
                Text("-10s", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = {
                    val target = minOf(totalDurationMs, currentMs + 10000L)
                    HapticAndSoundUtil.vibrate(context, 25)
                    HapticAndSoundUtil.announceForAccessibility(context, "10 सेकंड आगे गए")
                    onSeekTo(target)
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 2.dp)
                    .defaultMinSize(minHeight = 48.dp)
                    .semantics { contentDescription = "10 सेकंड आगे जाएँ" }
            ) {
                Text("+10s", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = {
                    val target = minOf(totalDurationMs, currentMs + 5000L)
                    HapticAndSoundUtil.vibrate(context, 25)
                    HapticAndSoundUtil.announceForAccessibility(context, "5 सेकंड आगे गए, वर्तमान स्थिति ${FileUtil.formatDurationHindi(target)}")
                    onSeekTo(target)
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 4.dp)
                    .defaultMinSize(minHeight = 48.dp)
                    .semantics { contentDescription = "5 सेकंड आगे जाएँ" }
            ) {
                Text("+5s", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            OutlinedButton(
                onClick = {
                    val target = maxOf(0L, currentMs - 60000L)
                    HapticAndSoundUtil.vibrate(context, 30)
                    HapticAndSoundUtil.announceForAccessibility(context, "1 मिनट पीछे गए")
                    onSeekTo(target)
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 4.dp)
                    .defaultMinSize(minHeight = 48.dp)
                    .semantics { contentDescription = "1 मिनट पीछे जाएँ" }
            ) {
                Text("-1m", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = {
                    val target = maxOf(0L, currentMs - 300000L)
                    HapticAndSoundUtil.vibrate(context, 30)
                    HapticAndSoundUtil.announceForAccessibility(context, "5 मिनट पीछे गए")
                    onSeekTo(target)
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 2.dp)
                    .defaultMinSize(minHeight = 48.dp)
                    .semantics { contentDescription = "5 मिनट पीछे जाएँ" }
            ) {
                Text("-5m", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = {
                    val target = minOf(totalDurationMs, currentMs + 60000L)
                    HapticAndSoundUtil.vibrate(context, 30)
                    HapticAndSoundUtil.announceForAccessibility(context, "1 मिनट आगे गए")
                    onSeekTo(target)
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 2.dp)
                    .defaultMinSize(minHeight = 48.dp)
                    .semantics { contentDescription = "1 मिनट आगे जाएँ" }
            ) {
                Text("+1m", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = {
                    val target = minOf(totalDurationMs, currentMs + 300000L)
                    HapticAndSoundUtil.vibrate(context, 30)
                    HapticAndSoundUtil.announceForAccessibility(context, "5 मिनट आगे गए")
                    onSeekTo(target)
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 4.dp)
                    .defaultMinSize(minHeight = 48.dp)
                    .semantics { contentDescription = "5 मिनट आगे जाएँ" }
            ) {
                Text("+5m", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun RealProgressBarCard(
    taskName: String,
    progressPercent: Int,
    isProcessing: Boolean,
    statusText: String = "",
    onCancel: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    if (!isProcessing) return

    val context = LocalContext.current
    var lastAnnouncedProgress by remember { mutableIntStateOf(-1) }

    LaunchedEffect(progressPercent) {
        // Announce every 20% to avoid TalkBack chatter spam
        if (progressPercent % 20 == 0 && progressPercent != lastAnnouncedProgress) {
            lastAnnouncedProgress = progressPercent
            HapticAndSoundUtil.announceForAccessibility(context, "$taskName, प्रगति $progressPercent प्रतिशत")
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .semantics {
                liveRegion = LiveRegionMode.Polite
                contentDescription = "$taskName चल रहा है, वर्तमान प्रगति $progressPercent प्रतिशत। $statusText"
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    strokeWidth = 3.dp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = taskName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "$progressPercent%",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            LinearProgressIndicator(
                progress = { progressPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (statusText.isNotBlank()) statusText else "स्थानीय फोन पर प्रोसेसिंग जारी है...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )

                if (onCancel != null) {
                    TextButton(
                        onClick = onCancel,
                        modifier = Modifier.semantics { contentDescription = "कार्य रद्द करें" }
                    ) {
                        Text("रद्द करें", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
fun AccurateTimePickerField(
    title: String,
    currentMs: Long,
    maxMs: Long,
    onTimeChange: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val totalSeconds = (currentMs / 1000L).coerceAtLeast(0L)
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L

    var hrInput by remember(hours) { mutableStateOf(hours.toString()) }
    var minInput by remember(minutes) { mutableStateOf(minutes.toString()) }
    var secInput by remember(seconds) { mutableStateOf(seconds.toString()) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "वर्तमान सेट समय: ${FileUtil.formatDuration(currentMs)} (${FileUtil.formatDurationHindi(currentMs)})",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Direct Hour, Minute, Second input
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = hrInput,
                    onValueChange = { str ->
                        hrInput = str.filter { it.isDigit() }
                        val h = hrInput.toLongOrNull() ?: 0L
                        val m = minInput.toLongOrNull() ?: 0L
                        val s = secInput.toLongOrNull() ?: 0L
                        val newTotal = (h * 3600L + m * 60L + s) * 1000L
                        val clamped = if (maxMs > 0) newTotal.coerceIn(0L, maxMs) else newTotal
                        onTimeChange(clamped)
                    },
                    label = { Text("घंटे") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .semantics { contentDescription = "$title के लिए घंटे दर्ज करें" }
                )

                OutlinedTextField(
                    value = minInput,
                    onValueChange = { str ->
                        minInput = str.filter { it.isDigit() }
                        val h = hrInput.toLongOrNull() ?: 0L
                        val m = minInput.toLongOrNull() ?: 0L
                        val s = secInput.toLongOrNull() ?: 0L
                        val newTotal = (h * 3600L + m * 60L + s) * 1000L
                        val clamped = if (maxMs > 0) newTotal.coerceIn(0L, maxMs) else newTotal
                        onTimeChange(clamped)
                    },
                    label = { Text("मिनट") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .semantics { contentDescription = "$title के लिए मिनट दर्ज करें" }
                )

                OutlinedTextField(
                    value = secInput,
                    onValueChange = { str ->
                        secInput = str.filter { it.isDigit() }
                        val h = hrInput.toLongOrNull() ?: 0L
                        val m = minInput.toLongOrNull() ?: 0L
                        val s = secInput.toLongOrNull() ?: 0L
                        val newTotal = (h * 3600L + m * 60L + s) * 1000L
                        val clamped = if (maxMs > 0) newTotal.coerceIn(0L, maxMs) else newTotal
                        onTimeChange(clamped)
                    },
                    label = { Text("सेकंड") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .semantics { contentDescription = "$title के लिए सेकंड दर्ज करें" }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Stepper Buttons for accessible adjusting
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val newTime = (currentMs - 5000L).coerceAtLeast(0L)
                        HapticAndSoundUtil.vibrate(context, 20)
                        HapticAndSoundUtil.announceForAccessibility(context, "5 सेकंड कम किए गए, नया समय ${FileUtil.formatDurationHindi(newTime)}")
                        onTimeChange(newTime)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .semantics { contentDescription = "5 सेकंड घटाएँ" }
                ) {
                    Text("-5s", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        val newTime = (currentMs - 1000L).coerceAtLeast(0L)
                        HapticAndSoundUtil.vibrate(context, 20)
                        HapticAndSoundUtil.announceForAccessibility(context, "1 सेकंड कम किया गया, नया समय ${FileUtil.formatDurationHindi(newTime)}")
                        onTimeChange(newTime)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .semantics { contentDescription = "1 सेकंड घटाएँ" }
                ) {
                    Text("-1s", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        val target = currentMs + 1000L
                        val newTime = if (maxMs > 0) target.coerceIn(0L, maxMs) else target
                        HapticAndSoundUtil.vibrate(context, 20)
                        HapticAndSoundUtil.announceForAccessibility(context, "1 सेकंड बढ़ाया गया, नया समय ${FileUtil.formatDurationHindi(newTime)}")
                        onTimeChange(newTime)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .semantics { contentDescription = "1 सेकंड बढ़ाएँ" }
                ) {
                    Text("+1s", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = {
                        val target = currentMs + 5000L
                        val newTime = if (maxMs > 0) target.coerceIn(0L, maxMs) else target
                        HapticAndSoundUtil.vibrate(context, 20)
                        HapticAndSoundUtil.announceForAccessibility(context, "5 सेकंड बढ़ाए गए, नया समय ${FileUtil.formatDurationHindi(newTime)}")
                        onTimeChange(newTime)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .defaultMinSize(minHeight = 48.dp)
                        .semantics { contentDescription = "5 सेकंड बढ़ाएँ" }
                ) {
                    Text("+5s", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Universal Repeat Control for Added Audio, Music, Sound Effects, and Video Clips.
 * Note: Per user rule, this is NOT to be used for Photos.
 */
@Composable
fun RepeatControlSection(
    mediaTitle: String, // e.g. "इस म्यूजिक", "इस साउंड इफेक्ट", "इस वीडियो क्लिप"
    isRepeatEnabled: Boolean,
    onRepeatToggle: (Boolean) -> Unit,
    repeatUntilEnd: Boolean,
    onRepeatUntilEndChange: (Boolean) -> Unit,
    repeatCount: Int,
    onRepeatCountChange: (Int) -> Unit,
    intervalSeconds: Int = 0,
    onIntervalChange: ((Int) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isRepeatEnabled) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        val next = !isRepeatEnabled
                        onRepeatToggle(next)
                        HapticAndSoundUtil.vibrate(context, 25)
                        HapticAndSoundUtil.announceForAccessibility(
                            context,
                            if (next) "$mediaTitle को रिपीट करना चालू किया गया" else "$mediaTitle को रिपीट करना बंद किया गया"
                        )
                    }
                    .semantics {
                        role = Role.Checkbox
                        contentDescription = "$mediaTitle को रिपीट करें, वर्तमान में ${if (isRepeatEnabled) "चालू" else "बंद"}"
                    }
            ) {
                Checkbox(
                    checked = isRepeatEnabled,
                    onCheckedChange = { onRepeatToggle(it) }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "$mediaTitle को रिपीट करें (Repeat / Loop)",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (isRepeatEnabled) "रिपीट चालू है" else "एक बार बजेगा (रिपीट बंद है)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (isRepeatEnabled) {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "रिपीट का प्रकार चुनें:",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary
                )

                // Option 1: Loop until end of main content
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onRepeatUntilEndChange(true)
                            HapticAndSoundUtil.announceForAccessibility(context, "पूरी मुख्य सामग्री समाप्त होने तक रिपीट चुना गया")
                        }
                        .padding(vertical = 4.dp)
                        .semantics {
                            role = Role.RadioButton
                            contentDescription = "पूरी मुख्य सामग्री समाप्त होने तक रिपीट करें"
                        }
                ) {
                    RadioButton(
                        selected = repeatUntilEnd,
                        onClick = { onRepeatUntilEndChange(true) }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "पूरी मुख्य सामग्री समाप्त होने तक रिपीट करें (Loop until end)",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                // Option 2: Repeat specific count
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onRepeatUntilEndChange(false)
                            HapticAndSoundUtil.announceForAccessibility(context, "निर्धारित संख्या में रिपीट चुना गया, वर्तमान संख्या $repeatCount बार")
                        }
                        .padding(vertical = 4.dp)
                        .semantics {
                            role = Role.RadioButton
                            contentDescription = "रिपीट की संख्या निर्धारित करें, वर्तमान संख्या $repeatCount बार"
                        }
                ) {
                    RadioButton(
                        selected = !repeatUntilEnd,
                        onClick = { onRepeatUntilEndChange(false) }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "रिपीट की संख्या तय करें ($repeatCount बार)",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                // If specific count is selected, show stepper
                if (!repeatUntilEnd) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 36.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (repeatCount > 1) {
                                    val newCount = repeatCount - 1
                                    onRepeatCountChange(newCount)
                                    HapticAndSoundUtil.vibrate(context, 20)
                                    HapticAndSoundUtil.announceForAccessibility(context, "रिपीट संख्या घटाकर $newCount बार की गई")
                                }
                            },
                            enabled = repeatCount > 1,
                            modifier = Modifier
                                .defaultMinSize(minHeight = 48.dp)
                                .semantics { contentDescription = "रिपीट संख्या 1 घटाएँ" }
                        ) {
                            Text("-1", fontWeight = FontWeight.Bold)
                        }

                        Text(
                            text = "$repeatCount बार",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        OutlinedButton(
                            onClick = {
                                if (repeatCount < 50) {
                                    val newCount = repeatCount + 1
                                    onRepeatCountChange(newCount)
                                    HapticAndSoundUtil.vibrate(context, 20)
                                    HapticAndSoundUtil.announceForAccessibility(context, "रिपीट संख्या बढ़ाकर $newCount बार की गई")
                                }
                            },
                            enabled = repeatCount < 50,
                            modifier = Modifier
                                .defaultMinSize(minHeight = 48.dp)
                                .semantics { contentDescription = "रिपीट संख्या 1 बढ़ाएँ" }
                        ) {
                            Text("+1", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Optional interval between repeats
                if (onIntervalChange != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "रिपीट के बीच अंतराल: $intervalSeconds सेकंड",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Slider(
                        value = intervalSeconds.toFloat(),
                        onValueChange = { onIntervalChange(it.toInt()) },
                        valueRange = 0f..10f,
                        steps = 9,
                        modifier = Modifier.semantics {
                            contentDescription = "रिपीट के बीच अंतराल $intervalSeconds सेकंड सेट करें"
                        }
                    )
                }
            }
        }
    }
}

/**
 * Freeze / Pause Main Video Option Card during SFX / Clips overlay.
 * Part 4.4 and Part 4.7
 */
@Composable
fun VideoFreezeOptionCard(
    pauseMainVideo: Boolean,
    onPauseMainVideoChange: (Boolean) -> Unit,
    mainVideoDurationMs: Long,
    addedContentDurationMs: Long,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val totalEstimatedDurationMs = if (pauseMainVideo) {
        mainVideoDurationMs + addedContentDurationMs
    } else {
        maxOf(mainVideoDurationMs, addedContentDurationMs)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (pauseMainVideo) MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "क्या आप अतिरिक्त सामग्री चलने के दौरान मुख्य वीडियो को रोकना चाहते हैं?",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Option: No (Play simultaneously)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        onPauseMainVideoChange(false)
                        HapticAndSoundUtil.vibrate(context, 20)
                        HapticAndSoundUtil.announceForAccessibility(context, "मुख्य वीडियो चलता रहने दें चुना गया")
                    }
                    .padding(vertical = 4.dp)
                    .semantics {
                        role = Role.RadioButton
                        contentDescription = "नहीं, मुख्य वीडियो चलता रहने दें (साथ-साथ बजेगा)"
                    }
            ) {
                RadioButton(
                    selected = !pauseMainVideo,
                    onClick = { onPauseMainVideoChange(false) }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "नहीं, मुख्य वीडियो चलता रहने दें",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "साउंड इफेक्ट या क्लिप के साथ-साथ मुख्य वीडियो भी चलता रहेगा",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Option: Yes (Freeze main video)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        onPauseMainVideoChange(true)
                        HapticAndSoundUtil.vibrate(context, 20)
                        HapticAndSoundUtil.announceForAccessibility(context, "हाँ, मुख्य वीडियो रोकें चुना गया। कुल अवधि बढ़ जाएगी")
                    }
                    .padding(vertical = 4.dp)
                    .semantics {
                        role = Role.RadioButton
                        contentDescription = "हाँ, मुख्य वीडियो रोकें (अतिरिक्त सामग्री खत्म होने के बाद आगे बढ़ेगा)"
                    }
            ) {
                RadioButton(
                    selected = pauseMainVideo,
                    onClick = { onPauseMainVideoChange(true) }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "हाँ, मुख्य वीडियो रोकें (Pause Main Video)",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "साउंड इफेक्ट या क्लिप खत्म होने के बाद मुख्य वीडियो आगे बढ़ेगा",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "अनुमानित कुल वीडियो अवधि: ${FileUtil.formatDuration(totalEstimatedDurationMs)} (${FileUtil.formatDurationHindi(totalEstimatedDurationMs)})",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (pauseMainVideo) {
                Text(
                    text = "(मुख्य वीडियो रोकने से अवधि में ${FileUtil.formatDurationHindi(addedContentDurationMs)} की वृद्धि हुई)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

