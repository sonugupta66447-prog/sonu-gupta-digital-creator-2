package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.data.model.MediaClipEntity
import com.example.data.model.ProjectEntity
import com.example.data.model.SavedFileEntity
import com.example.utils.AudioEngine
import com.example.utils.FileUtil
import com.example.utils.HapticAndSoundUtil
import com.example.utils.VideoEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.sin
import kotlin.random.Random

sealed class AppScreen {
    object MainMenu : AppScreen()
    object AudioEditorMenu : AppScreen()
    object VideoEditorMenu : AppScreen()
    object NewProjectWorkspace : AppScreen()
    object MyProjects : AppScreen()
    object SavedFiles : AppScreen()
    object Settings : AppScreen()
    object HelpAccessibility : AppScreen()

    // Audio Sub-tools
    object AudioRecorderTool : AppScreen()
    object AudioRecordWithMusicTool : AppScreen()
    object AudioTrimTool : AppScreen()
    object AudioTrimStartEndTool : AppScreen()
    object AudioMergeTool : AppScreen()
    object AudioMixMusicTool : AppScreen()
    object AudioAutoDuckingTool : AppScreen()
    object AudioSoundEffectsTool : AppScreen()
    object AudioGainControlTool : AppScreen()
    object AudioVoiceModulationTool : AppScreen()
    object AudioNoiseReductionTool : AppScreen()
    object AudioExtractFromVideoTool : AppScreen()
    object AudioToVideoTool : AppScreen()

    // Video Sub-tools
    object VideoTrimTool : AppScreen()
    object VideoRecordWithMusicTool : AppScreen()
    object VideoMergeTool : AppScreen()
    object VideoAddMusicTool : AppScreen()
    object VideoAddSfxTool : AppScreen()
    object VideoVolumeControlTool : AppScreen()
    object PhotoSlideshowTool : AppScreen()
    object AudioWithPhotosVideoTool : AppScreen()
    object VideoOverlayPhotosTool : AppScreen()
    object VideoClipsMergeTool : AppScreen()
    object PhotosToVideoTool : AppScreen()
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = Room.databaseBuilder(
        application,
        AppDatabase::class.java,
        "sonu_gupta_creator_db"
    ).build()

    val projectDao = db.projectDao()

    // Navigation state
    val currentScreen = MutableStateFlow<AppScreen>(AppScreen.MainMenu)
    private val screenStack = mutableListOf<AppScreen>()

    // Global Processing State
    val isProcessing = MutableStateFlow(false)
    val taskName = MutableStateFlow("")
    val progressPercent = MutableStateFlow(0)
    val processingStatus = MutableStateFlow("")
    private var currentJob: Job? = null

    // Audio Recording
    val isRecording = MutableStateFlow(false)
    val isRecordingPaused = MutableStateFlow(false)
    val recordDurationMs = MutableStateFlow(0L)
    val activeRecordedFile = MutableStateFlow<File?>(null)

    // Current Workspaces Selected Files
    val selectedAudioFile = MutableStateFlow<File?>(null)
    val secondaryAudioFile = MutableStateFlow<File?>(null) // Music or SFX
    val selectedVideoFile = MutableStateFlow<File?>(null)
    val selectedPhotosList = MutableStateFlow<List<File>>(emptyList())
    val timedPhotosList = MutableStateFlow<List<com.example.utils.TimedPhotoData>>(emptyList())
    val mergeAudioList = MutableStateFlow<List<File>>(emptyList())
    val videoClipsList = MutableStateFlow<List<File>>(emptyList())
    val videoClipsConfigList = MutableStateFlow<List<com.example.utils.VideoClipConfig>>(emptyList())
    val liveRecordMusic = MutableStateFlow<File?>(null)

    // Active Project in "New Project" workspace
    val currentProjectId = MutableStateFlow<String?>(null)
    val currentProjectTitle = MutableStateFlow("नया प्रोजेक्ट")
    val currentProjectClips = MutableStateFlow<List<MediaClipEntity>>(emptyList())

    // Saved files flow
    val allSavedFiles = projectDao.getAllSavedFiles()
    val allProjects = projectDao.getAllProjects()

    // Settings
    val beepOnRecordEnabled = MutableStateFlow(true)
    val hapticEnabled = MutableStateFlow(true)
    val defaultPhotoDurationMs = MutableStateFlow(6000L) // 6 seconds

    init {
        ensureSamplePresetsExist()
    }

    fun navigateTo(screen: AppScreen) {
        screenStack.add(currentScreen.value)
        currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        return if (screenStack.isNotEmpty()) {
            val prev = screenStack.removeAt(screenStack.size - 1)
            currentScreen.value = prev
            true
        } else if (currentScreen.value != AppScreen.MainMenu) {
            currentScreen.value = AppScreen.MainMenu
            true
        } else {
            false
        }
    }

    // Audio Recording
    fun startAudioRecording() {
        val context = getApplication<Application>()
        if (beepOnRecordEnabled.value) {
            HapticAndSoundUtil.playRecordStartBeep()
        }
        if (hapticEnabled.value) {
            HapticAndSoundUtil.vibrate(context, 50)
        }
        HapticAndSoundUtil.announceForAccessibility(context, "रिकॉर्डिंग शुरू हुई")

        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val dir = FileUtil.getAppAudioDir(context)
        val file = File(dir, "VoiceRecord_$timeStamp.wav")
        activeRecordedFile.value = file

        AudioEngine.startRecording(file) { dur ->
            recordDurationMs.value = dur
        }
        isRecording.value = true
        isRecordingPaused.value = false
    }

    fun pauseAudioRecording() {
        val context = getApplication<Application>()
        AudioEngine.pauseRecording()
        isRecordingPaused.value = true
        HapticAndSoundUtil.announceForAccessibility(context, "रिकॉर्डिंग रोकी गई")
    }

    fun resumeAudioRecording() {
        val context = getApplication<Application>()
        AudioEngine.resumeRecording()
        isRecordingPaused.value = false
        HapticAndSoundUtil.announceForAccessibility(context, "रिकॉर्डिंग जारी है")
    }

    fun stopAudioRecording(customName: String = "") {
        val context = getApplication<Application>()
        AudioEngine.stopRecording()
        isRecording.value = false
        isRecordingPaused.value = false

        if (beepOnRecordEnabled.value) {
            HapticAndSoundUtil.playRecordStopBeep()
        }
        if (hapticEnabled.value) {
            HapticAndSoundUtil.vibrate(context, 60)
        }

        activeRecordedFile.value?.let { file ->
            val finalFile = if (customName.isNotBlank()) {
                val renamed = File(file.parentFile, "${customName.trim()}.wav")
                file.renameTo(renamed)
                renamed
            } else {
                file
            }
            activeRecordedFile.value = finalFile
            selectedAudioFile.value = finalFile

            // Register in SavedFiles
            viewModelScope.launch(Dispatchers.IO) {
                val dur = FileUtil.getMediaDuration(context, finalFile)
                projectDao.insertSavedFile(
                    SavedFileEntity(
                        id = UUID.randomUUID().toString(),
                        fileName = finalFile.name,
                        filePath = finalFile.absolutePath,
                        mediaType = "AUDIO",
                        format = "WAV",
                        durationMs = dur,
                        fileSizeBytes = finalFile.length()
                    )
                )
            }
            HapticAndSoundUtil.announceForAccessibility(context, "रिकॉर्डिंग सेव हुई, अवधि ${FileUtil.formatDurationHindi(recordDurationMs.value)}")
        }
    }

    // Process: Audio Trim
    fun executeAudioTrim(startMs: Long, endMs: Long, onDone: (File?) -> Unit) {
        val src = selectedAudioFile.value ?: return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "Trimmed_${src.nameWithoutExtension}_$timeStamp.wav")

        isProcessing.value = true
        taskName.value = "ऑडियो कटिंग (Audio Trimming)"
        progressPercent.value = 0
        processingStatus.value = "चयनित हिस्सा काटा जा रहा है..."

        currentJob = viewModelScope.launch {
            val success = AudioEngine.trimWav(src, out, startMs, endMs) { p ->
                progressPercent.value = p
            }
            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "AUDIO", "WAV")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "ऑडियो सफलतापूर्वक काटा गया")
                onDone(out)
            } else {
                HapticAndSoundUtil.announceForAccessibility(context, "कटिंग प्रक्रिया असफल रही")
                onDone(null)
            }
        }
    }

    // Process: Merge Audios
    fun executeAudioMerge(files: List<File>, onDone: (File?) -> Unit) {
        if (files.size < 2) return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "Merged_Audio_$timeStamp.wav")

        isProcessing.value = true
        taskName.value = "ऑडियो जोड़ना (Audio Merge)"
        progressPercent.value = 0
        processingStatus.value = "${files.size} फाइलें जोड़ी जा रही हैं..."

        currentJob = viewModelScope.launch {
            val success = AudioEngine.mergeWavs(files, out) { p ->
                progressPercent.value = p
            }
            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "AUDIO", "WAV")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "सभी ऑडियो फाइलें जुड़ गईं")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Process: Mix Voice with Music ("रिकॉर्ड की गई ऑडियो में म्यूजिक जोड़ें")
    fun executeMixVoiceMusic(
        voiceVol: Float,
        musicVol: Float,
        musicStartMs: Long,
        musicDurationMs: Long,
        loop: Boolean,
        fadeInMs: Long = 1500L,
        fadeOutMs: Long = 1500L,
        repeatCount: Int = 1,
        repeatUntilEnd: Boolean = true,
        onDone: (File?) -> Unit
    ) {
        val voice = selectedAudioFile.value ?: return
        val music = secondaryAudioFile.value ?: return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "Mixed_VoiceMusic_$timeStamp.wav")

        isProcessing.value = true
        taskName.value = "रिकॉर्ड की गई ऑडियो में म्यूजिक जोड़ें"
        progressPercent.value = 0
        processingStatus.value = "बैकग्राउंड म्यूजिक और आवाज़ मिक्स हो रही है..."

        currentJob = viewModelScope.launch {
            val success = AudioEngine.mixVoiceWithMusic(
                voiceFile = voice,
                musicFile = music,
                outputFile = out,
                voiceVolume = voiceVol,
                musicVolume = musicVol,
                musicStartMs = musicStartMs,
                musicDurationMs = musicDurationMs,
                fadeInMs = fadeInMs,
                fadeOutMs = fadeOutMs,
                loopMusic = loop,
                repeatCount = repeatCount,
                repeatUntilEnd = repeatUntilEnd
            ) { p -> progressPercent.value = p }

            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "AUDIO", "WAV")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "म्यूजिक मिक्सिंग पूरी हुई")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Process: Auto-Ducking
    fun executeAutoDucking(
        voiceVol: Float,
        musicVol: Float,
        duckLevelPercent: Float,
        sensitivityPercent: Float,
        loopMusic: Boolean = true,
        repeatCount: Int = 1,
        repeatUntilEnd: Boolean = true,
        onDone: (File?) -> Unit
    ) {
        val voice = selectedAudioFile.value ?: return
        val music = secondaryAudioFile.value ?: return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "AutoDucked_Music_$timeStamp.wav")

        isProcessing.value = true
        taskName.value = "बोलते समय बैकग्राउंड म्यूजिक की आवाज़ कम करें (Auto-Ducking)"
        progressPercent.value = 0
        processingStatus.value = "आवाज़ की पहचान और म्यूजिक डकिंग जारी है..."

        currentJob = viewModelScope.launch {
            val success = AudioEngine.applyAutoDucking(
                voiceFile = voice,
                musicFile = music,
                outputFile = out,
                voiceVolume = voiceVol,
                musicVolume = musicVol,
                duckLevelPercent = duckLevelPercent,
                sensitivityPercent = sensitivityPercent,
                loopMusic = loopMusic,
                repeatCount = repeatCount,
                repeatUntilEnd = repeatUntilEnd
            ) { p -> progressPercent.value = p }

            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "AUDIO", "WAV")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "ऑटो-डकिंग पूरी हुई")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Process: Sound Effects
    fun executeApplySoundEffect(
        offsetMs: Long,
        durationMs: Long,
        sfxVolume: Float,
        repeatSfx: Boolean = false,
        repeatCount: Int = 1,
        repeatUntilEnd: Boolean = false,
        repeatIntervalMs: Long = 0L,
        onDone: (File?) -> Unit
    ) {
        val main = selectedAudioFile.value ?: return
        val sfx = secondaryAudioFile.value ?: return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "SFX_Overlay_$timeStamp.wav")

        isProcessing.value = true
        taskName.value = "साउंड इफेक्ट जोड़ें"
        progressPercent.value = 0
        processingStatus.value = "साउंड इफेक्ट समय पर जोड़ा जा रहा है..."

        currentJob = viewModelScope.launch {
            val success = AudioEngine.applySoundEffects(
                mainAudio = main,
                sfxFile = sfx,
                outputFile = out,
                offsetMs = offsetMs,
                durationMs = durationMs,
                sfxVolume = sfxVolume,
                repeatSfx = repeatSfx,
                repeatCount = repeatCount,
                repeatUntilEnd = repeatUntilEnd,
                repeatIntervalMs = repeatIntervalMs
            ) { p -> progressPercent.value = p }

            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "AUDIO", "WAV")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "साउंड इफेक्ट सफलतापूर्वक जुड़ा")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Process: Voice Effects / Modulation / Echo / Noise Reduction
    fun executeVoiceEffect(
        effect: AudioEngine.VoiceEffect,
        intensity: Float,
        echoDelayMs: Int = 220,
        echoDecay: Float = 0.45f,
        noiseThreshold: Float = 600f,
        onDone: (File?) -> Unit
    ) {
        val src = selectedAudioFile.value ?: return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "VoiceEffect_${effect.name}_$timeStamp.wav")

        isProcessing.value = true
        taskName.value = when (effect) {
            AudioEngine.VoiceEffect.ECHO -> "आवाज़ की गूँज और इको"
            AudioEngine.VoiceEffect.NOISE_GATE -> "ऑडियो से शोर कम करें"
            else -> "आवाज़ बदलें (${effect.name})"
        }
        progressPercent.value = 0
        processingStatus.value = "ऑडियो फिल्टर लागू किया जा रहा है..."

        currentJob = viewModelScope.launch {
            val success = AudioEngine.applyVoiceEffect(
                inputFile = src,
                outputFile = out,
                effect = effect,
                intensity = intensity,
                echoDelayMs = echoDelayMs,
                echoDecay = echoDecay,
                noiseThreshold = noiseThreshold
            ) { p -> progressPercent.value = p }

            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "AUDIO", "WAV")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "आवाज़ प्रभाव सफलतापूर्वक लागू हुआ")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Process: Extract Audio from Video
    fun executeExtractAudioFromVideo(onDone: (File?) -> Unit) {
        val video = selectedVideoFile.value ?: return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "Extracted_Audio_$timeStamp.m4a")

        isProcessing.value = true
        taskName.value = "वीडियो से ऑडियो निकालें"
        progressPercent.value = 0
        processingStatus.value = "वीडियो से पूरा ऑडियो ट्रैक निकाला जा रहा है..."

        currentJob = viewModelScope.launch {
            val success = AudioEngine.extractAudioFromVideo(video, out) { p ->
                progressPercent.value = p
            }
            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "AUDIO", "M4A")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "वीडियो से ऑडियो सफलतापूर्वक निकला")
                onDone(out)
            } else {
                HapticAndSoundUtil.announceForAccessibility(context, "वीडियो में ऑडियो ट्रैक नहीं मिला या त्रुटि हुई")
                onDone(null)
            }
        }
    }

    // Process: Video Trimming
    fun executeVideoTrim(startMs: Long, endMs: Long, onDone: (File?) -> Unit) {
        val video = selectedVideoFile.value ?: return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "Trimmed_Video_$timeStamp.mp4")

        isProcessing.value = true
        taskName.value = "वीडियो काटें (Video Trimming)"
        progressPercent.value = 0
        processingStatus.value = "वीडियो का चयनित हिस्सा प्रोसेस हो रहा है..."

        currentJob = viewModelScope.launch {
            val success = VideoEngine.trimVideo(video, out, startMs, endMs) { p ->
                progressPercent.value = p
            }
            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "VIDEO", "MP4")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "वीडियो कटिंग पूरी हुई")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Process: Add Music to Video
    fun executeAddMusicToVideo(onDone: (File?) -> Unit) {
        val video = selectedVideoFile.value ?: return
        val music = selectedAudioFile.value ?: return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "VideoWithMusic_$timeStamp.mp4")

        isProcessing.value = true
        taskName.value = "वीडियो में म्यूजिक जोड़ें"
        progressPercent.value = 0
        processingStatus.value = "वीडियो और बैकग्राउंड म्यूजिक मिक्स हो रहे हैं..."

        currentJob = viewModelScope.launch {
            val success = VideoEngine.addMusicToVideo(video, music, out) { p ->
                progressPercent.value = p
            }
            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "VIDEO", "MP4")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "वीडियो में म्यूजिक सफलतापूर्वक जुड़ा")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Process: Photos to Video / Audio to Video Slideshow
    fun executePhotosToVideo(
        photos: List<File>,
        audio: File?,
        photoDurationMs: Long,
        onDone: (File?) -> Unit
    ) {
        if (photos.isEmpty()) return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "PhotoSlideshow_$timeStamp.mp4")

        isProcessing.value = true
        taskName.value = "फोटो और ऑडियो से वीडियो बनाएँ"
        progressPercent.value = 0
        processingStatus.value = "फोटो स्लाइडशो और ऑडियो एन्कोडिंग जारी है..."

        currentJob = viewModelScope.launch {
            val success = VideoEngine.createVideoFromPhotosAndAudio(
                photoFiles = photos,
                audioFile = audio,
                outputFile = out,
                photoDurationMs = photoDurationMs
            ) { p -> progressPercent.value = p }

            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "VIDEO", "MP4")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "वीडियो सफलतापूर्वक तैयार हुआ")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Process: Audio Gain / Volume Control
    fun executeAudioGainControl(volumeFactor: Float, onDone: (File?) -> Unit) {
        val src = selectedAudioFile.value ?: return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "VolAdjusted_${src.nameWithoutExtension}_$timeStamp.wav")

        isProcessing.value = true
        taskName.value = "ऑडियो का वॉल्यूम नियंत्रित करें"
        progressPercent.value = 0
        processingStatus.value = "वॉल्यूम स्तर लागू किया जा रहा है..."

        currentJob = viewModelScope.launch {
            val success = AudioEngine.adjustAudioVolume(src, out, volumeFactor) { p ->
                progressPercent.value = p
            }
            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "AUDIO", "WAV")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "ऑडियो वॉल्यूम सफलतापूर्वक समायोजित हुआ")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Process: Cut Middle of Audio
    fun executeAudioCutMiddle(cutStartMs: Long, cutEndMs: Long, onDone: (File?) -> Unit) {
        val src = selectedAudioFile.value ?: return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "MiddleCut_${src.nameWithoutExtension}_$timeStamp.wav")

        isProcessing.value = true
        taskName.value = "ऑडियो की शुरुआत, बीच या अंत काटें"
        progressPercent.value = 0
        processingStatus.value = "चयनित मध्य भाग हटाया जा रहा है..."

        currentJob = viewModelScope.launch {
            val success = AudioEngine.cutMiddleWav(src, out, cutStartMs, cutEndMs) { p ->
                progressPercent.value = p
            }
            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "AUDIO", "WAV")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "ऑडियो हिस्सा सफलतापूर्वक काटा गया")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Process: Tool 11: ऑडियो में फोटो लगाकर वीडियो बनाएँ
    fun executeAudioWithPhotosVideo(
        audioFile: File,
        photos: List<File>,
        onDone: (File?) -> Unit
    ) {
        if (!audioFile.exists() || photos.isEmpty()) return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "AudioWithPhotos_$timeStamp.mp4")

        isProcessing.value = true
        taskName.value = "ऑडियो में फोटो लगाकर वीडियो बनाएँ"
        progressPercent.value = 0
        processingStatus.value = "ऑडियो की पूरी अवधि के अनुसार फोटो वीडियो तैयार हो रहा है..."

        currentJob = viewModelScope.launch {
            val success = VideoEngine.createVideoForAudioWithPhotos(
                audioFile = audioFile,
                photoFiles = photos,
                outputFile = out
            ) { p -> progressPercent.value = p }

            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "VIDEO", "MP4")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "ऑडियो और फोटो से पूरा वीडियो बन गया")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Process: Tool 12: वीडियो क्लिप जोड़कर वीडियो बनाएँ
    fun executeVideoClipsMerge(videoFiles: List<File>, onDone: (File?) -> Unit) {
        if (videoFiles.isEmpty()) return
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "Merged_VideoClips_$timeStamp.mp4")

        isProcessing.value = true
        taskName.value = "वीडियो क्लिप जोड़कर वीडियो बनाएँ"
        progressPercent.value = 0
        processingStatus.value = "${videoFiles.size} वीडियो क्लिप्स जोड़ी जा रही हैं..."

        currentJob = viewModelScope.launch {
            val success = VideoEngine.concatenateVideoClips(videoFiles, out) { p ->
                progressPercent.value = p
            }
            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "VIDEO", "MP4")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "सभी वीडियो क्लिप्स जुड़कर नया वीडियो बन गया")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Process: Video Volume Control
    fun executeVideoVolumeControl(videoFile: File, muteAudio: Boolean, onDone: (File?) -> Unit) {
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "VideoVol_${videoFile.nameWithoutExtension}_$timeStamp.mp4")

        isProcessing.value = true
        taskName.value = "वीडियो की मूल आवाज़ नियंत्रित करें"
        progressPercent.value = 0
        processingStatus.value = "वीडियो का ऑडियो ट्रैक प्रोसेस हो रहा है..."

        currentJob = viewModelScope.launch {
            val success = VideoEngine.adjustVideoVolume(videoFile, out, muteAudio) { p ->
                progressPercent.value = p
            }
            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "VIDEO", "MP4")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "वीडियो की आवाज़ संशोधित हुई")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Process: Live Record With Music Mix
    fun executeLiveRecordWithMusicMix(
        recordedVoice: File,
        musicFile: File,
        voiceVol: Float,
        musicVol: Float,
        onDone: (File?) -> Unit
    ) {
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(FileUtil.getAppExportsDir(context), "LiveMusicRecord_$timeStamp.wav")

        isProcessing.value = true
        taskName.value = "म्यूजिक के साथ लाइव रिकॉर्डिंग मिक्स"
        progressPercent.value = 0
        processingStatus.value = "लाइव रिकॉर्ड की गई आवाज़ और बैकग्राउंड म्यूजिक मिक्स हो रहे हैं..."

        currentJob = viewModelScope.launch {
            val success = AudioEngine.mixVoiceWithMusic(
                voiceFile = recordedVoice,
                musicFile = musicFile,
                outputFile = out,
                voiceVolume = voiceVol,
                musicVolume = musicVol,
                musicStartMs = 0L,
                musicDurationMs = 0L,
                loopMusic = true
            ) { p -> progressPercent.value = p }

            isProcessing.value = false
            if (success && out.exists()) {
                registerSavedFile(out, "AUDIO", "WAV")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "म्यूजिक के साथ रिकॉर्डिंग सुरक्षित हुई")
                onDone(out)
            } else {
                onDone(null)
            }
        }
    }

    // Cancel active background processing
    fun cancelCurrentTask() {
        currentJob?.cancel()
        currentJob = null
        isProcessing.value = false
        val context = getApplication<Application>()
        HapticAndSoundUtil.announceForAccessibility(context, "कार्य रद्द कर दिया गया")
    }

    // Helper to register file into Room database
    private suspend fun registerSavedFile(file: File, type: String, format: String) {
        val context = getApplication<Application>()
        val dur = FileUtil.getMediaDuration(context, file)
        projectDao.insertSavedFile(
            SavedFileEntity(
                id = UUID.randomUUID().toString(),
                fileName = file.name,
                filePath = file.absolutePath,
                mediaType = type,
                format = format,
                durationMs = dur,
                fileSizeBytes = file.length()
            )
        )
    }

    // Project Builder methods
    fun createNewProject(title: String, type: String = "HYBRID") {
        val newId = UUID.randomUUID().toString()
        currentProjectId.value = newId
        currentProjectTitle.value = title.ifBlank { "नया प्रोजेक्ट" }
        currentProjectClips.value = emptyList()

        viewModelScope.launch(Dispatchers.IO) {
            projectDao.insertProject(
                ProjectEntity(
                    id = newId,
                    title = currentProjectTitle.value,
                    projectType = type
                )
            )
        }
    }

    fun loadProject(project: ProjectEntity) {
        currentProjectId.value = project.id
        currentProjectTitle.value = project.title
        viewModelScope.launch(Dispatchers.IO) {
            val clips = projectDao.getClipsForProjectSync(project.id)
            currentProjectClips.value = clips
            withContext(Dispatchers.Main) {
                navigateTo(AppScreen.NewProjectWorkspace)
            }
        }
    }

    fun addClipToCurrentProject(clipType: String, file: File, title: String, durationMs: Long = 6000L) {
        val pId = currentProjectId.value ?: return
        val current = currentProjectClips.value.toMutableList()
        val newClip = MediaClipEntity(
            id = UUID.randomUUID().toString(),
            projectId = pId,
            clipType = clipType,
            filePath = file.absolutePath,
            title = title,
            orderIndex = current.size,
            durationMs = durationMs
        )
        current.add(newClip)
        currentProjectClips.value = current
        saveProjectClipsToDb()
    }

    fun moveClip(index: Int, direction: Int) {
        val list = currentProjectClips.value.toMutableList()
        val targetIndex = index + direction
        if (targetIndex in 0 until list.size) {
            val item = list.removeAt(index)
            list.add(targetIndex, item)
            // Re-index
            val reindexed = list.mapIndexed { idx, clip -> clip.copy(orderIndex = idx) }
            currentProjectClips.value = reindexed
            saveProjectClipsToDb()
        }
    }

    fun removeClip(index: Int) {
        val list = currentProjectClips.value.toMutableList()
        if (index in 0 until list.size) {
            list.removeAt(index)
            val reindexed = list.mapIndexed { idx, clip -> clip.copy(orderIndex = idx) }
            currentProjectClips.value = reindexed
            saveProjectClipsToDb()
        }
    }

    fun updateClipDuration(index: Int, newDurMs: Long) {
        val list = currentProjectClips.value.toMutableList()
        if (index in 0 until list.size) {
            list[index] = list[index].copy(durationMs = newDurMs, trimEndMs = newDurMs)
            currentProjectClips.value = list
            saveProjectClipsToDb()
        }
    }

    fun updateClipVolume(index: Int, newVol: Float) {
        val list = currentProjectClips.value.toMutableList()
        if (index in 0 until list.size) {
            list[index] = list[index].copy(volume = newVol)
            currentProjectClips.value = list
            saveProjectClipsToDb()
        }
    }

    private fun saveProjectClipsToDb() {
        val pId = currentProjectId.value ?: return
        val clips = currentProjectClips.value
        val totalDur = clips.sumOf { it.durationMs }
        viewModelScope.launch(Dispatchers.IO) {
            projectDao.deleteClipsForProject(pId)
            projectDao.insertClips(clips)
            projectDao.getProjectById(pId)?.let { p ->
                projectDao.updateProject(p.copy(totalDurationMs = totalDur, updatedAt = System.currentTimeMillis()))
            }
        }
    }

    fun exportCurrentProjectAsMedia(onDone: (File?) -> Unit) {
        val clips = currentProjectClips.value
        if (clips.isEmpty()) return

        val photos = clips.filter { it.clipType == "PHOTO" }.map { File(it.filePath) }
        val audioClip = clips.firstOrNull { it.clipType.startsWith("AUDIO") }
        val audioFile = if (audioClip != null) File(audioClip.filePath) else null

        if (photos.isNotEmpty()) {
            executePhotosToVideo(photos, audioFile, defaultPhotoDurationMs.value, onDone)
        } else if (audioFile != null) {
            onDone(audioFile)
        }
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            projectDao.deleteClipsForProject(project.id)
            projectDao.deleteProject(project)
        }
    }

    fun deleteSavedFile(savedFile: SavedFileEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            projectDao.deleteSavedFile(savedFile)
            try {
                val f = File(savedFile.filePath)
                if (f.exists()) f.delete()
            } catch (_: Exception) {}
        }
    }

    // भाग 1 (सुविधा 1): ऑडियो में सही समय पर फोटो लगाकर वीडियो बनाएँ
    fun executeAudioWithTimedPhotos(
        audioFile: File,
        timedPhotos: List<com.example.utils.TimedPhotoData>,
        onComplete: (File?) -> Unit
    ) {
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val outFile = File(FileUtil.getAppVideoDir(context), "StoryVideo_$timeStamp.mp4")

        isProcessing.value = true
        taskName.value = "ऑडियो और फोटो से संपूर्ण कहानी वीडियो तैयार किया जा रहा है"
        progressPercent.value = 0
        processingStatus.value = "कहानी की समय-सीमा अनुसार फोटो और वीडियो रेंडर हो रहा है..."

        currentJob = viewModelScope.launch {
            val success = VideoEngine.createVideoForAudioWithTimedPhotos(
                audioFile = audioFile,
                timedPhotos = timedPhotos,
                outputFile = outFile,
                onProgress = { p -> progressPercent.value = p }
            )

            isProcessing.value = false
            if (success && outFile.exists()) {
                registerSavedFile(outFile, "VIDEO", "MP4")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "संपूर्ण कहानी वीडियो तैयार होकर सेव हुआ")
                onComplete(outFile)
            } else {
                HapticAndSoundUtil.announceForAccessibility(context, "वीडियो बनाने में त्रुटि हुई")
                onComplete(null)
            }
        }
    }

    // भाग 1 (सुविधा 2): वीडियो में सही समय पर फोटो लगाएँ
    fun executeVideoOverlayPhotos(
        videoFile: File,
        timedPhotos: List<com.example.utils.TimedPhotoData>,
        onComplete: (File?) -> Unit
    ) {
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val outFile = File(FileUtil.getAppVideoDir(context), "VideoWithPhotos_$timeStamp.mp4")

        isProcessing.value = true
        taskName.value = "वीडियो में सही समय पर फोटो जोड़ें"
        progressPercent.value = 0
        processingStatus.value = "वीडियो के ऊपर फोटो ओवरले तैयार हो रहा है..."

        currentJob = viewModelScope.launch {
            val success = VideoEngine.overlayPhotosOnVideo(
                videoFile = videoFile,
                timedPhotos = timedPhotos,
                outputFile = outFile,
                onProgress = { p -> progressPercent.value = p }
            )

            isProcessing.value = false
            if (success && outFile.exists()) {
                registerSavedFile(outFile, "VIDEO", "MP4")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "फोटो सहित वीडियो सेव हुआ")
                onComplete(outFile)
            } else {
                HapticAndSoundUtil.announceForAccessibility(context, "वीडियो बनाने में त्रुटि हुई")
                onComplete(null)
            }
        }
    }

    // भाग 3: वीडियो में साउंड इफेक्ट जोड़ें
    fun executeVideoAddSfx(
        videoFile: File,
        sfxFile: File,
        startMs: Long,
        sfxVol: Float,
        onComplete: (File?) -> Unit
    ) {
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val outFile = File(FileUtil.getAppVideoDir(context), "VideoWithSfx_$timeStamp.mp4")

        isProcessing.value = true
        taskName.value = "वीडियो में साउंड इफेक्ट जोड़ें"
        progressPercent.value = 0
        processingStatus.value = "निर्धारित समय पर साउंड इफेक्ट मिक्स हो रहा है..."

        currentJob = viewModelScope.launch {
            val success = VideoEngine.addSfxToVideo(
                videoFile = videoFile,
                sfxFile = sfxFile,
                startMs = startMs,
                sfxVol = sfxVol,
                outputFile = outFile,
                onProgress = { p -> progressPercent.value = p }
            )

            isProcessing.value = false
            if (success && outFile.exists()) {
                registerSavedFile(outFile, "VIDEO", "MP4")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "साउंड इफेक्ट सहित वीडियो सेव हुआ")
                onComplete(outFile)
            } else {
                HapticAndSoundUtil.announceForAccessibility(context, "साउंड इफेक्ट जोड़ने में त्रुटि हुई")
                onComplete(null)
            }
        }
    }

    // भाग 2: वीडियो क्लिप जोड़कर वीडियो बनाएँ (With clip volume and trimming)
    fun executeVideoClipsMergeWithAudio(
        clipConfigs: List<com.example.utils.VideoClipConfig>,
        bgMusic: File?,
        bgMusicVol: Float,
        onComplete: (File?) -> Unit
    ) {
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val outFile = File(FileUtil.getAppVideoDir(context), "JoinedClips_$timeStamp.mp4")

        isProcessing.value = true
        taskName.value = "वीडियो क्लिप जोड़कर वीडियो बनाएँ"
        progressPercent.value = 0
        processingStatus.value = "सभी वीडियो क्लिप्स और वॉल्यूम नियंत्रण प्रोसेस हो रहे हैं..."

        currentJob = viewModelScope.launch {
            val success = VideoEngine.concatenateVideoClipsWithAudioControl(
                clipConfigs = clipConfigs,
                bgMusicFile = bgMusic,
                bgMusicVol = bgMusicVol,
                outputFile = outFile,
                onProgress = { p -> progressPercent.value = p }
            )

            isProcessing.value = false
            if (success && outFile.exists()) {
                registerSavedFile(outFile, "VIDEO", "MP4")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "सभी क्लिप्स जुड़कर नया वीडियो तैयार हुआ")
                onComplete(outFile)
            } else {
                HapticAndSoundUtil.announceForAccessibility(context, "क्लिप्स जोड़ने में त्रुटि हुई")
                onComplete(null)
            }
        }
    }

    // भाग 5: म्यूजिक के साथ लाइव वीडियो रिकॉर्डिंग
    fun executeVideoRecordWithMusic(
        videoFile: File,
        musicFile: File,
        musicVol: Float,
        onComplete: (File?) -> Unit
    ) {
        val context = getApplication<Application>()
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val outFile = File(FileUtil.getAppVideoDir(context), "LiveVideoMusic_$timeStamp.mp4")

        isProcessing.value = true
        taskName.value = "म्यूजिक के साथ लाइव वीडियो रिकॉर्डिंग"
        progressPercent.value = 0
        processingStatus.value = "रिकॉर्ड किए गए वीडियो में बैकग्राउंड म्यूजिक जोड़ा जा रहा है..."

        currentJob = viewModelScope.launch {
            val success = VideoEngine.addMusicToVideo(
                videoFile = videoFile,
                audioFile = musicFile,
                outputFile = outFile,
                onProgress = { p -> progressPercent.value = p }
            )

            isProcessing.value = false
            if (success && outFile.exists()) {
                registerSavedFile(outFile, "VIDEO", "MP4")
                HapticAndSoundUtil.playSuccessChime()
                HapticAndSoundUtil.announceForAccessibility(context, "म्यूजिक के साथ वीडियो तैयार हुआ")
                onComplete(outFile)
            } else {
                HapticAndSoundUtil.announceForAccessibility(context, "म्यूजिक जोड़ने में त्रुटि हुई")
                onComplete(null)
            }
        }
    }

    // Built-in sample presets for instant offline use
    private fun ensureSamplePresetsExist() {
        viewModelScope.launch(Dispatchers.IO) {
            val context = getApplication<Application>()
            val sfxDir = File(context.filesDir, "sfx_presets")
            if (!sfxDir.exists()) sfxDir.mkdirs()

            // 1. Temple Bell
            val bellFile = File(sfxDir, "घंटी (Temple Bell).wav")
            if (!bellFile.exists()) {
                generateSyntheticTone(bellFile, 1200, 2000, isBell = true)
            }

            // 2. Whoosh
            val whooshFile = File(sfxDir, "नाटकीय प्रभाव (Whoosh).wav")
            if (!whooshFile.exists()) {
                generateSyntheticWhoosh(whooshFile, 1800)
            }

            // 3. Ambient Melody
            val musicFile = File(sfxDir, "मधुर धुन (Ambient Melody).wav")
            if (!musicFile.exists()) {
                generateSyntheticMelody(musicFile, 6000)
            }

            // 4. दरवाजा खुलना (Door Open SFX)
            val doorFile = File(sfxDir, "दरवाजा खुलना (Door Creak).wav")
            if (!doorFile.exists()) {
                generateSyntheticDoorCreak(doorFile, 1600)
            }

            // 5. बारिश की आवाज़ (Rain Sound SFX)
            val rainFile = File(sfxDir, "बारिश की आवाज़ (Rain Sound).wav")
            if (!rainFile.exists()) {
                generateSyntheticRain(rainFile, 3000)
            }

            // 6. डरावनी ध्वनि (Horror Sound SFX)
            val horrorFile = File(sfxDir, "डरावनी ध्वनि (Horror Sound).wav")
            if (!horrorFile.exists()) {
                generateSyntheticHorror(horrorFile, 2500)
            }

            // 7. तालियां (Applause SFX)
            val applauseFile = File(sfxDir, "तालियां (Applause).wav")
            if (!applauseFile.exists()) {
                generateSyntheticApplause(applauseFile, 2200)
            }
        }
    }

    private fun generateSyntheticTone(file: File, freq: Int, durationMs: Int, isBell: Boolean) {
        try {
            val sampleRate = 44100
            val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val byteBuf = ByteBuffer.allocate(totalSamples * 2).order(ByteOrder.LITTLE_ENDIAN)

            for (i in 0 until totalSamples) {
                val decay = if (isBell) Math.exp(-i / (sampleRate * 0.4)) else 1.0
                val sampleVal = (sin(2.0 * Math.PI * freq * i / sampleRate) * 26000.0 * decay).toInt().toShort()
                byteBuf.putShort(sampleVal)
            }

            val pcmFile = File(file.parentFile, "temp.pcm")
            FileOutputStream(pcmFile).use { it.write(byteBuf.array()) }
            AudioEngine.pcmToWav(pcmFile, file, sampleRate, 1, 16)
            pcmFile.delete()
        } catch (_: Exception) {}
    }

    private fun generateSyntheticWhoosh(file: File, durationMs: Int) {
        try {
            val sampleRate = 44100
            val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val byteBuf = ByteBuffer.allocate(totalSamples * 2).order(ByteOrder.LITTLE_ENDIAN)

            for (i in 0 until totalSamples) {
                val t = i.toDouble() / totalSamples
                val currentFreq = 150.0 + 700.0 * sin(Math.PI * t)
                val envelope = sin(Math.PI * t)
                val sampleVal = (sin(2.0 * Math.PI * currentFreq * i / sampleRate) * 24000.0 * envelope).toInt().toShort()
                byteBuf.putShort(sampleVal)
            }

            val pcmFile = File(file.parentFile, "temp_whoosh.pcm")
            FileOutputStream(pcmFile).use { it.write(byteBuf.array()) }
            AudioEngine.pcmToWav(pcmFile, file, sampleRate, 1, 16)
            pcmFile.delete()
        } catch (_: Exception) {}
    }

    private fun generateSyntheticMelody(file: File, durationMs: Int) {
        try {
            val sampleRate = 44100
            val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val byteBuf = ByteBuffer.allocate(totalSamples * 2).order(ByteOrder.LITTLE_ENDIAN)

            val notes = intArrayOf(261, 329, 392, 523, 392, 329) // C - E - G - C'
            val noteDuration = sampleRate / 2

            for (i in 0 until totalSamples) {
                val noteIdx = ((i / noteDuration) % notes.size)
                val freq = notes[noteIdx]
                val envelope = 0.5 + 0.5 * sin(Math.PI * (i % noteDuration) / noteDuration)
                val sampleVal = (sin(2.0 * Math.PI * freq * i / sampleRate) * 16000.0 * envelope).toInt().toShort()
                byteBuf.putShort(sampleVal)
            }

            val pcmFile = File(file.parentFile, "temp_melody.pcm")
            FileOutputStream(pcmFile).use { it.write(byteBuf.array()) }
            AudioEngine.pcmToWav(pcmFile, file, sampleRate, 1, 16)
            pcmFile.delete()
        } catch (_: Exception) {}
    }

    private fun generateSyntheticDoorCreak(file: File, durationMs: Int) {
        try {
            val sampleRate = 44100
            val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val byteBuf = ByteBuffer.allocate(totalSamples * 2).order(ByteOrder.LITTLE_ENDIAN)

            for (i in 0 until totalSamples) {
                val t = i.toDouble() / totalSamples
                val jitter = sin(140.0 * Math.PI * t) * 35.0
                val freq = 220.0 + 180.0 * t + jitter
                val sampleVal = (sin(2.0 * Math.PI * freq * i / sampleRate) * 18000.0 * (1.0 - t * 0.3)).toInt().toShort()
                byteBuf.putShort(sampleVal)
            }

            val pcmFile = File(file.parentFile, "temp_door.pcm")
            FileOutputStream(pcmFile).use { it.write(byteBuf.array()) }
            AudioEngine.pcmToWav(pcmFile, file, sampleRate, 1, 16)
            pcmFile.delete()
        } catch (_: Exception) {}
    }

    private fun generateSyntheticRain(file: File, durationMs: Int) {
        try {
            val sampleRate = 44100
            val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val byteBuf = ByteBuffer.allocate(totalSamples * 2).order(ByteOrder.LITTLE_ENDIAN)
            val random = Random(42)

            for (i in 0 until totalSamples) {
                // Pink-ish noise for rain
                val noise = (random.nextFloat() * 2f - 1f) * 11000f
                val mod = 0.8f + 0.2f * sin(2.0 * Math.PI * 0.5 * i / sampleRate).toFloat()
                val sampleVal = (noise * mod).toInt().coerceIn(-32768, 32767).toShort()
                byteBuf.putShort(sampleVal)
            }

            val pcmFile = File(file.parentFile, "temp_rain.pcm")
            FileOutputStream(pcmFile).use { it.write(byteBuf.array()) }
            AudioEngine.pcmToWav(pcmFile, file, sampleRate, 1, 16)
            pcmFile.delete()
        } catch (_: Exception) {}
    }

    private fun generateSyntheticHorror(file: File, durationMs: Int) {
        try {
            val sampleRate = 44100
            val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val byteBuf = ByteBuffer.allocate(totalSamples * 2).order(ByteOrder.LITTLE_ENDIAN)

            for (i in 0 until totalSamples) {
                val t = i.toDouble() / totalSamples
                // Low rumble (65Hz) + eerie dissonance (65Hz + 69Hz beat frequency)
                val s1 = sin(2.0 * Math.PI * 65.0 * i / sampleRate)
                val s2 = sin(2.0 * Math.PI * 69.5 * i / sampleRate)
                val eerie = sin(2.0 * Math.PI * (440.0 + 80.0 * sin(Math.PI * 3.0 * t)) * i / sampleRate) * 0.3
                val sampleVal = ((s1 + s2 + eerie) * 10000.0).toInt().coerceIn(-32768, 32767).toShort()
                byteBuf.putShort(sampleVal)
            }

            val pcmFile = File(file.parentFile, "temp_horror.pcm")
            FileOutputStream(pcmFile).use { it.write(byteBuf.array()) }
            AudioEngine.pcmToWav(pcmFile, file, sampleRate, 1, 16)
            pcmFile.delete()
        } catch (_: Exception) {}
    }

    private fun generateSyntheticApplause(file: File, durationMs: Int) {
        try {
            val sampleRate = 44100
            val totalSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val byteBuf = ByteBuffer.allocate(totalSamples * 2).order(ByteOrder.LITTLE_ENDIAN)
            val random = Random(123)

            for (i in 0 until totalSamples) {
                val clapImpulse = if (random.nextFloat() > 0.985f) 1.0 else 0.1
                val noise = (random.nextFloat() * 2f - 1f) * 16000f * clapImpulse.toFloat()
                val sampleVal = noise.toInt().coerceIn(-32768, 32767).toShort()
                byteBuf.putShort(sampleVal)
            }

            val pcmFile = File(file.parentFile, "temp_applause.pcm")
            FileOutputStream(pcmFile).use { it.write(byteBuf.array()) }
            AudioEngine.pcmToWav(pcmFile, file, sampleRate, 1, 16)
            pcmFile.delete()
        } catch (_: Exception) {}
    }
}
